import { BatchUpdateFoodListReq, CreateFoodReq, FoodFilters, RatingFilters, SortingFood } from '@calo/dashboard-types';

import client from 'lib/client';
import { ToastSuccessMsgs } from 'lib/helpers';

export const createFood = async (values: Omit<CreateFoodReq, 'id'>) => {
	const { data, status } = await client.post('/food', values);
	ToastSuccessMsgs({ status, action: 'Food created successfully' });
	return data;
};

export const batchUpdate = async (payload: BatchUpdateFoodListReq) => {
	const { data, status } = await client.put('/food', payload);
	ToastSuccessMsgs({ status, action: 'Food updated successfully' });
	return data;
};

export const deleteFood = async (id: string) => {
	await client.delete(`/food/${id}`);
};

export const getPackage = async () => {
	const { data: packageList } = await client.get('food-packages', { params: { limit: 1000 } });
	return packageList;
};

export const exportFood = async (sort: SortingFood, filters: FoodFilters) => {
	const { status } = await client.get('food/export', { params: { sort, filters } });
	ToastSuccessMsgs({ status, action: 'The export file will be sent to your email shortly' });
};

export const exportFeedBack = async (filters: RatingFilters) => {
	const { status } = await client.get('ratings/export', { params: { filters } });
	ToastSuccessMsgs({ status, action: 'The exported file sent to your email' });
};

export const selectedFoodData = async (foodID: string) => {
	const { data } = await client.get(`food/${foodID}`);
	return data;
};
