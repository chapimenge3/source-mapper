import { IngredientsFilters, UpdateIngredientReq } from '@calo/dashboard-types';
import client from 'lib/client';
import { ToastSuccessMsgs } from 'lib/helpers';
import { IngredientFormData } from 'lib/interfaces';
import mutation from './mutation';

export const createIngredient = async (values: IngredientFormData) => {
	const { data, status } = await client.post('/ingredients', values);
	ToastSuccessMsgs({ status, action: 'New Ingredient created successfully' });
	mutation(['ingredient', data.id], data);
	return data;
};

export const updateIngredient = async (payload: UpdateIngredientReq & { id: string }) => {
	const { id, ...rest } = payload;
	const { data, status } = await client.put(`/ingredients/${id}`, rest);
	ToastSuccessMsgs({ status, action: 'Ingredient updated successfully' });
	mutation(['ingredient', id], data);
};

export const exportIngredient = async (filters: IngredientsFilters) => {
	const { status } = await client.get('/ingredients/export', { params: { filters } });
	ToastSuccessMsgs({ status, action: 'The exported file sent to your email' });
};

// export const deleteFood = async (id: string) => {
//   await client.delete(`/food/${id}`)
// }
