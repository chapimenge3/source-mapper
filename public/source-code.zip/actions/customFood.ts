import { createCustomFoodReq, UpdateDeliveryFoodComponents } from '@calo/dashboard-types';
import client from 'lib/client';
import { ToastSuccessMsgs } from 'lib/helpers';

export const updateCustomFood = async (payload: UpdateDeliveryFoodComponents & { deliveryId: string; foodId: string }) => {
	const { deliveryId, foodId, ...rest } = payload;
	const { data, status } = await client.put(`/deliveries/${deliveryId}/food/${foodId}/components`, {
		components: rest.components,
		name: rest.name
	});
	ToastSuccessMsgs({ status, action: 'Custom meal updated' });
	return data;
};

export const createCustomFood = async (payload: createCustomFoodReq & { deliveryId: string }) => {
	const { deliveryId, ...rest } = payload;
	const { data, status } = await client.post('food/custom', {
		subscriptionId: rest.subscriptionId,
		deliveryId: deliveryId,
		name: rest.name,
		foodComponentIds: rest.foodComponentIds
	});
	ToastSuccessMsgs({ status, action: 'Custom meal created' });
	return data;
};
