import { loyaltyClient } from 'lib/client';
import { QueryFunction } from 'react-query';

export const checkEligibilityForPoints = async (userId: string, amount: number) => {
	const { data } = await loyaltyClient.get(`/dashboard/eligible/${userId}/${amount}`);
	return data;
};

export const getTotalPoints = async (userId: string) => {
	const { data } = await loyaltyClient.get(`/dashboard/${userId}`);
	return { data };
};

export const getLoyaltyRecord: QueryFunction = async (context) => {
	const { data } = await loyaltyClient.get(context.queryKey.join('/'));

	return data;
};
