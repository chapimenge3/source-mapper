import { CreateFoodComponentReq, SyncFoodComponentReq, UpdateFoodComponentReq } from '@calo/dashboard-types';
import client from 'lib/client';
import { ToastSuccessMsgs } from 'lib/helpers';
import { SyncFoodComponentMPErrors } from 'lib/interfaces';
import mutation from './mutation';

export const createFoodComponent = async (fc: CreateFoodComponentReq) => {
	const { data, status } = await client.post('/food-components', fc);
	ToastSuccessMsgs({ status, action: 'Component created successfully' });
	mutation(['food-components', data.id], data);
	return data;
};

export const updateFoodComponent = async (payload: UpdateFoodComponentReq & { id: string }) => {
	const { id, ...rest } = payload;
	const { data, status } = await client.put(`/food-components/${id}`, rest);
	ToastSuccessMsgs({ status, action: 'Component updated successfully' });
	mutation(['food-components', id], data);
};

export const exportFoodComponent = async (filters: any) => {
	const { status } = await client.get('food-components/export', { params: { filters } });
	ToastSuccessMsgs({ status, action: 'The exported file sent to your email' });
};

export const syncFoodComponent = async (payload: SyncFoodComponentReq & { id: string }) => {
	const { id, ...rest } = payload;
	const { data, status } = await client.put(`/food-components/${id}/sync`, rest);
	return data as { data: SyncFoodComponentMPErrors[]; isSuccess: boolean };
};
