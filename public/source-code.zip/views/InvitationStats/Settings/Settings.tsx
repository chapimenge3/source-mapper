import { InvitationCodeUserStatsFilters } from '@calo/dashboard-types';
import { Country, Kitchen } from '@calo/types';
import { toggleUISettings } from 'actions';
import { Input, QuickView, Select2 } from 'components';
import { getAccessibleCountries, getKitchenOptions } from 'lib';
import { useUserKitchens } from 'lib/hooks';
import { AppState } from 'lib/interfaces';
import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

interface SettingsProps {
	onFilter: (values: InvitationCodeUserStatsFilters) => void;
	filters: InvitationCodeUserStatsFilters;
}

const Settings = ({ filters, onFilter }: SettingsProps) => {
	const { settingsVisible } = useSelector((state: AppState) => ({
		settingsVisible: state.ui.settings
	}));
	const [checked, setChecked] = useState<boolean>(false);

	const userKitchens: string[] = useUserKitchens();
	const dispatch = useDispatch();

	const handleChecked = () => {
		if (checked) {
			onFilter({ ...filters, notUsed: undefined });
			setChecked(false);
		} else {
			onFilter({ ...filters, notUsed: 0 });
			setChecked(true);
		}
	};

	return (
		<QuickView visible={settingsVisible} onClose={() => dispatch(toggleUISettings())}>
			<section className="section">
				<h5 className="title is-5">Filters</h5>
				<Input label="Name" value={filters.name} onChange={(e) => onFilter({ ...filters, name: e.target.value })} debounce />
				<Select2
					label="Country"
					value={filters.country}
					onChange={(data) =>
						onFilter({
							...filters,
							country: data.target.value as Country,
							kitchen: data.target.value
								? Object.values(Kitchen).find((k) => k.includes(data.target.value) && !k.includes('000'))
								: ('' as Kitchen)
						})
					}
					options={getAccessibleCountries(userKitchens).map((c) => ({
						value: c,
						label: Country[c]
					}))}
				/>
				<Select2
					label="Kitchen"
					value={filters.kitchen}
					onChange={(data) => onFilter({ ...filters, kitchen: data.target.value as Kitchen })}
					options={getKitchenOptions(userKitchens, filters.country!)}
					disabled={Object.values(Kitchen).filter((r) => r.includes(filters.country!)).length === 0}
				/>
				<Input
					label="Phone number"
					value={filters.phoneNumber}
					onChange={(e) => onFilter({ ...filters, phoneNumber: e.target.value })}
					debounce
				/>
				<span className="flex flex-row ">
					<input
						type="checkbox"
						className="m-2"
						checked={checked}
						onChange={() => handleChecked()}
						onClick={() => setChecked(!checked)}
					/>
					<label className="label">Need codes</label>
				</span>
			</section>
		</QuickView>
	);
};

export default Settings;
