import { Permission } from '@calo/dashboard-types';
import { Button, Input } from 'components';
import { useUserRoles } from 'lib/hooks';
import { UpdateFoodPackageElementReq } from 'lib/interfaces';
import usePackageElementForm from './usePackageElementForm';

interface PackageElementFormProps {
	onSubmit: (value: UpdateFoodPackageElementReq) => Promise<void>;
	element: UpdateFoodPackageElementReq;
}

const PackageElementForm = ({ onSubmit, element }: PackageElementFormProps) => {
	const { handleSubmit, values, handleChange, handleBlur, isSubmitting, isValid, dirty, setFieldValue } = usePackageElementForm(
		element,
		onSubmit
	);
	const roles = useUserRoles();

	return (
		<form onSubmit={handleSubmit}>
			<div className="field">
				<div className="field-body">
					<Input
						label="Name"
						value={values.name}
						name="name"
						onChange={handleChange}
						onBlur={handleBlur}
						disabled={!roles.includes(Permission.UPDATE_FOOD_PACKAGE_ELEMENT)}
					/>
				</div>
			</div>
			<Input
				label="Cost"
				value={values.cost}
				name="cost"
				min={0}
				type="number"
				step="any"
				onChange={(data: any) => setFieldValue('cost', data.target.value)}
				disabled={!roles.includes(Permission.UPDATE_FOOD_PACKAGE_ELEMENT)}
			/>
			<Input
				label="Size"
				name="size"
				value={values.size}
				onChange={(data: any) => setFieldValue('size', data.target.value)}
				disabled={!roles.includes(Permission.UPDATE_FOOD_PACKAGE_ELEMENT)}
			/>

			{roles.includes(Permission.UPDATE_FOOD_PACKAGE_ELEMENT) && (
				<Button type="submit" primary fluid loading={isSubmitting} disabled={!dirty || !isValid || isSubmitting} content="Save" />
			)}
		</form>
	);
};

export default PackageElementForm;
