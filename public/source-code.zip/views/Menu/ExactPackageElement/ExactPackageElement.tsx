import { useParams } from 'react-router';
import { Link } from 'react-router-dom';

import { getRecord, updateFoodPackageElement } from 'actions';
import { Card } from 'components';
import { resolveCountry } from 'lib';
import { Routes } from 'lib/enums';
import { useMutation, useQuery } from 'react-query';
import PackageElementForm from './PackageElementForm';

const ExactPackageElement = () => {
	const { id } = useParams<{ id: string }>();

	const { data } = useQuery(['food-package-elements', id], getRecord, {
		suspense: true
	});
	const element = data as any;
	const { mutateAsync: updateMutation } = useMutation(updateFoodPackageElement);

	const handleUpdateElement = async (values: any) => {
		await updateMutation({ id, ...values });
	};

	return (
		<>
			<section className="section is-title-bar">
				<div className="level">
					<div className="level-left">
						<div className="level-item">
							<ul>
								<li>
									<Link to={Routes.packageElementList}>Elements</Link>
								</li>
								<li>{element.name}</li>
							</ul>
						</div>
					</div>
					<div className="level-right">
						<p className="font-bold text-xl">
							{element?.brand?.toUpperCase()}-{resolveCountry(element?.country).toUpperCase()}-{element?.kitchen?.toUpperCase()}
						</p>
					</div>
				</div>
			</section>
			<section className="hero is-hero-bar">
				<div className="hero-body">
					<div className="level">
						<div className="level-left">
							<div className="level-item">
								<h1 className="title">{element.name}</h1>
							</div>
						</div>
					</div>
				</div>
			</section>
			<Card title="Info">
				<div className="card-content overflow-visible">
					<PackageElementForm onSubmit={handleUpdateElement} element={element!} />
				</div>
			</Card>
		</>
	);
};

export default ExactPackageElement;
