import { Kitchen } from '@calo/types';
import { Button, Input, Select } from 'components';
import { getAccessibleCountries, selectCountry } from 'lib/helpers';
import { getKitchenOptions } from 'lib/helpers/kitchenUtils';
import { useUserKitchens } from 'lib/hooks';
import { CreateFoodPackageElementReq } from 'lib/interfaces';
import useNewPackageElementForm from './useNewPackageElementForm';
interface NewPackageElementFormProps {
	onSubmit: (value: CreateFoodPackageElementReq) => Promise<void>;
}

const NewPackageElementForm = ({ onSubmit }: NewPackageElementFormProps) => {
	const { handleSubmit, values, handleBlur, isSubmitting, isValid, dirty, setFieldValue, errors } =
		useNewPackageElementForm(onSubmit);

	const userKitchens: Kitchen[] = useUserKitchens();

	return (
		<form onSubmit={handleSubmit}>
			<div className="field">
				<div className="field-body">
					<Input
						label="Name"
						value={values.name}
						name="name"
						onChange={(e) => setFieldValue('name', e.target.value)}
						onBlur={handleBlur}
					/>
				</div>
			</div>
			<Select
				label="Country"
				value={values.country}
				onChange={(data: any) =>
					selectCountry({
						value: data.value,
						kitchens: userKitchens,
						setFieldValue
					})
				}
				options={getAccessibleCountries(userKitchens).map((type) => ({
					value: type,
					label: type
				}))}
			/>
			<Select
				label="Kitchen"
				value={values.kitchen}
				onChange={(data: any) => setFieldValue('kitchen', data.value)}
				options={getKitchenOptions(userKitchens, values.country)}
				error={!!errors.kitchen}
			/>
			<Input
				label="Cost"
				name="cost"
				type="number"
				min={0}
				step="any"
				value={values.cost}
				onChange={(data: any) => setFieldValue('cost', +data.target.value)}
			/>
			<Input label="Size" name="size" value={values.size} onChange={(data: any) => setFieldValue('size', data.target.value)} />
			<Button type="submit" primary fluid loading={isSubmitting} disabled={!dirty || !isValid || isSubmitting} content="Save" />
		</form>
	);
};

export default NewPackageElementForm;
