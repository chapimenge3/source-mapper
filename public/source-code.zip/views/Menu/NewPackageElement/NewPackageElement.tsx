import { createFoodPackageElement } from 'actions';
import { Card } from 'components';
import { Routes } from 'lib/enums';
import { CreateFoodPackageElementReq } from 'lib/interfaces';
import { useMutation } from 'react-query';
import { useHistory } from 'react-router-dom';
import NewPackageElementForm from './NewPackageElementForm';

const NewIngredient = () => {
	const history = useHistory();
	const { mutateAsync: createMutation } = useMutation(createFoodPackageElement);

	const handleNewPackageElement = async (values: CreateFoodPackageElementReq) => {
		const foodPackageElement = await createMutation(values);
		history.replace(Routes.packageElement.replace(':id', foodPackageElement.id));
	};

	return (
		<>
			<section>
				<Card title="Info">
					<div className="card-content overflow-visible">
						<NewPackageElementForm onSubmit={handleNewPackageElement} />
					</div>
				</Card>
			</section>
		</>
	);
};

export default NewIngredient;
