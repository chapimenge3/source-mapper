import { createFoodPackage } from 'actions';
import { Card } from 'components';
import { Routes } from 'lib/enums';
import { CreateFoodPackageReq } from 'lib/interfaces';
import { useMutation } from 'react-query';
import { useHistory } from 'react-router-dom';
import NewPackagesForm from './NewPackagesForm';

const NewFoodPackages = () => {
	const { mutateAsync: createMutation } = useMutation(createFoodPackage);
	const history = useHistory();

	const handleNewPackages = async (values: CreateFoodPackageReq) => {
		const packages = await createMutation(values);
		history.replace(Routes.package.replace(':id', packages.id));
	};

	return (
		<>
			<section>
				<Card title="Information">
					<div className="card-content">
						<NewPackagesForm onSubmit={handleNewPackages} />
					</div>
				</Card>
			</section>
		</>
	);
};

export default NewFoodPackages;
