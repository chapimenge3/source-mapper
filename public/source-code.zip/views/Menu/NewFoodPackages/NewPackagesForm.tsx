import { Kitchen } from '@calo/types';
import { getListWithParams } from 'actions';
import { Button, Input, PackageElementsPicker, Select } from 'components';
import { PackageType } from 'lib/enums';
import { getAccessibleCountries, selectCountry } from 'lib/helpers';
import { getKitchenOptions } from 'lib/helpers/kitchenUtils';
import { useUserKitchens } from 'lib/hooks';
import { CreateFoodPackageReq, FoodPackageElement } from 'lib/interfaces';
import { sumBy } from 'lodash';
import { keyBy, round } from 'lodash-es';
import { useEffect, useMemo } from 'react';
import { useQuery } from 'react-query';
import usePackageForm from './usePackageForm';
interface NewPackageFormProps {
	onSubmit: (value: CreateFoodPackageReq) => Promise<void>;
}

const NewFoodPackages = ({ onSubmit }: NewPackageFormProps) => {
	const { handleSubmit, values, handleChange, handleBlur, isSubmitting, isValid, dirty, setFieldValue, setValues, errors } =
		usePackageForm(onSubmit);

	const { data: packageElementsList } = useQuery<any, Error, { data: any[] }>(
		[
			'food-package-elements',
			{
				limit: 1000,
				filters: { country: values.country, brand: values.brand, kitchen: values.kitchen }
			}
		],
		getListWithParams,
		{
			suspense: true
		}
	);
	const keyed = useMemo(() => keyBy(packageElementsList?.data || [], 'id'), [packageElementsList]);

	useEffect(() => {
		setFieldValue('elements', []);
	}, [values.country, values.brand, values.kitchen]);

	const handleElementsChange = (rows: FoodPackageElement[]) => {
		console.log(rows);
		setValues({
			...values,
			elements: rows
		});
	};

	const userKitchens: Kitchen[] = useUserKitchens();

	return (
		<div>
			<div>
				<div className="field">
					<div className="field-body">
						<Input label="Name" value={values.name} name="name" onChange={handleChange} onBlur={handleBlur} />
					</div>
				</div>

				<div className="card">
					<div>
						<PackageElementsPicker
							onChange={handleElementsChange}
							value={values.elements || []}
							keyed={keyed}
							list={packageElementsList?.data || []}
						/>
					</div>
				</div>

				<Input
					label="Cost"
					value={round(
						sumBy(values.elements, (fk) => keyed[fk.id]?.cost * fk.quantity),
						6
					)}
					name="cost"
					type="number"
					disabled
				/>

				<Select
					label="Country"
					value={values.country}
					onChange={(data: any) =>
						selectCountry({
							value: data.value,
							kitchens: userKitchens,
							setFieldValue
						})
					}
					options={getAccessibleCountries(userKitchens).map((type) => ({
						value: type,
						label: type
					}))}
				/>
				<Select
					label="Kitchen"
					value={values.kitchen}
					onChange={(data: any) => setFieldValue('kitchen', data.value)}
					options={getKitchenOptions(userKitchens, values.country)}
					error={!!errors.kitchen}
				/>

				<Select
					label="Type"
					value={values.type}
					onChange={(data: any) => setFieldValue('type', data.value)}
					options={Object.values(PackageType).map((k) => ({
						value: k,
						label: k
					}))}
				/>
				<Button
					type="submit"
					primary
					loading={isSubmitting}
					disabled={!dirty || !isValid || isSubmitting}
					content="Save"
					onClick={() => handleSubmit()}
				/>
			</div>
		</div>
	);
};

export default NewFoodPackages;
