import { useMutation, useQuery } from 'react-query';
import { useParams } from 'react-router';
import { Link } from 'react-router-dom';

import { FoodPackageElementReq } from '@calo/dashboard-types';
import { getListWithParams, getRecord, updateFoodPackage } from 'actions';
import { resolveCountry } from 'lib';
import { Routes } from 'lib/enums';
import { UpdateFoodPackageReq } from 'lib/interfaces';
import PackageForm from './PackageForm';

const ExactFoodPackage = () => {
	const { id } = useParams<{ id: string }>();
	const { mutateAsync: updateMutation } = useMutation(updateFoodPackage);

	const { data } = useQuery(['food-packages', id], getRecord, {
		suspense: true
	});
	const foodPackages = data as any;

	const { data: packageElementList } = useQuery<any, Error, { data: FoodPackageElementReq[] }>(
		[
			'food-package-elements',
			{
				limit: 1000,
				filters: { country: foodPackages.country, brand: foodPackages.brand, kitchen: foodPackages.kitchen }
			}
		],
		getListWithParams,
		{
			suspense: true
		}
	);

	const handleUpdatePackages = async (values: UpdateFoodPackageReq) => {
		await updateMutation({ id, ...values });
		console.log(values);
	};

	return (
		<>
			<section className="section is-title-bar">
				<div className="level">
					<div className="level-left">
						<div className="level-item">
							<ul>
								<li>
									<Link to={Routes.packagesList}>Food Packages</Link>
								</li>
								<li>{foodPackages!.name}</li>
							</ul>
						</div>
					</div>
					<div className="level-right">
						<p className="font-bold text-xl">
							{foodPackages?.brand?.toUpperCase()}-{resolveCountry(foodPackages?.country).toUpperCase()}-
							{foodPackages?.kitchen?.toUpperCase()}
						</p>
					</div>
				</div>
			</section>
			<section className="hero is-hero-bar">
				<div className="hero-body">
					<div className="level">
						<div className="level-left">
							<div className="level-item">
								<h1 className="title">{foodPackages!.name}</h1>
							</div>
						</div>
					</div>
				</div>
			</section>
			<div className="tile is-ancestor">
				<div className="tile is-parent">
					<div className="w-full">
						<div className="card">
							<header className="card-header bg-black">
								<p className="card-header-title text-white">
									<span className="icon ">
										<i className="mdi mdi-account-multiple"></i>
									</span>
									Information
								</p>
								<a href="#" className="card-header-icon">
									<span className="icon">
										<i className="mdi mdi-reload"></i>
									</span>
								</a>
							</header>
							<div>
								<PackageForm
									onSubmit={handleUpdatePackages}
									packages={foodPackages!}
									packageElements={packageElementList?.data || []}
								/>
							</div>
						</div>
					</div>
				</div>
			</div>
		</>
	);
};

export default ExactFoodPackage;
