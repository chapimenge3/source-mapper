import { useMemo } from 'react';

import { FoodPackageElementReq, Permission } from '@calo/dashboard-types';
import { getImageUploadLink } from 'actions';
import { Button, ImageUploader, Input, PackageElementsPicker, Select } from 'components';
import { PackageType } from 'lib/enums';
import { useUserRoles } from 'lib/hooks';
import { FoodPackage, FoodPackageElement, UpdateFoodPackageReq } from 'lib/interfaces';
import { keyBy, round, sumBy } from 'lodash-es';
import usePackageForm from './usePackageForm';

interface PackageFormProps {
	onSubmit: (value: UpdateFoodPackageReq) => Promise<void>;
	packages: FoodPackage;
	packageElements: FoodPackageElementReq[];
}

const PackageForm = ({ onSubmit, packages, packageElements }: PackageFormProps) => {
	const { handleSubmit, values, handleChange, handleBlur, isSubmitting, isValid, dirty, setFieldValue, setValues } =
		usePackageForm(packages, onSubmit);
	const roles = useUserRoles();

	const keyed = useMemo(() => keyBy(packageElements, 'id'), []);

	const handleElementsChange = (rows: FoodPackageElement[]) => {
		setValues({
			...values,
			elements: rows
		});
	};

	return (
		<>
			<div className="card-content flex flex-row w-full">
				<div className=" w-64 -mt-16">
					<>
						<a href="#" className="card-header-icon">
							<span className="icon">
								<i className="mdi mdi-reload"></i>
							</span>
						</a>
					</>
					<ImageUploader
						key={packages.id}
						uploadLink={() => getImageUploadLink(`/food-package/${packages.id}`)}
						image={`${process.env.REACT_APP_BUCKET_URL}/food-package/${packages.id}/square@1x.jpg`}
						disabled={roles.includes(Permission.UPLOAD_IMAGE)}
					/>
				</div>
				<div className="w-full mt-4">
					<Input
						label="Name"
						value={values.name}
						name="name"
						onChange={handleChange}
						onBlur={handleBlur}
						disabled={!roles.includes(Permission.UPDATE_FOOD_PACKAGE)}
					/>
					<div className="card">
						<PackageElementsPicker
							onChange={handleElementsChange}
							value={values.elements || []}
							keyed={keyed}
							list={packageElements}
						/>
					</div>
					<Select
						label="Type"
						value={values.type}
						onChange={(data: any) => setFieldValue('type', data.value)}
						options={Object.values(PackageType).map((k) => ({
							value: k,
							label: k
						}))}
						isDisabled={!roles.includes(Permission.UPDATE_FOOD_PACKAGE)}
					/>
					<Input
						label="Total Cost"
						value={
							+round(
								sumBy(values.elements, (fk) => keyed[fk.id]?.cost * fk.quantity),
								6
							)
						}
						name="cost"
						type="number"
						min={0}
						step="any"
						disabled
					/>
				</div>
			</div>
			{roles.includes(Permission.UPDATE_FOOD_PACKAGE) && (
				<div className="float-right w-32 flex">
					<Button
						type="submit"
						primary
						fluid
						loading={isSubmitting}
						disabled={!dirty || !isValid || isSubmitting}
						content="Save"
						onClick={() => handleSubmit()}
					/>
				</div>
			)}
		</>
	);
};

export default PackageForm;
