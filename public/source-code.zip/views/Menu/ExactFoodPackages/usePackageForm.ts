import { useFormik } from 'formik';
import { FoodPackage, UpdateFoodPackageReq } from 'lib/interfaces';
import { omit } from 'lodash';

export default (packages: FoodPackage, onSubmit: (values: UpdateFoodPackageReq) => any) =>
	useFormik<UpdateFoodPackageReq>({
		initialValues: {
			...(omit(packages, ['id', 'updatedAt', 'createdAt']) as any)
		},
		validate: (values: UpdateFoodPackageReq) => {
			const errors: any = {};
			if (!values.name) {
				errors.name = true;
			}

			return errors;
		},
		onSubmit: async (values) => {
			console.log(values);
			try {
				await onSubmit(values);
			} catch (error) {
				console.log(error);
			}
		}
	});
