import { useState } from 'react';

import { useQuery } from 'react-query';
import { useHistory, useLocation } from 'react-router';

import { FoodPackageFilters, Permission } from '@calo/dashboard-types';
import { Brand, Kitchen } from '@calo/types';

import { getListWithParams } from 'actions';
import { Button, CaloLoader } from 'components';
import { resolveCountryFromKitchen } from 'lib';
import { Routes } from 'lib/enums';
import { useUserKitchens, useUserRoles } from 'lib/hooks';
import PackagesRow from './PackagesRow';
import Settings from './Settings';

const PackagesList = () => {
	const history = useHistory();
	const roles = useUserRoles();
	const userKitchen = useUserKitchens();
	const location = useLocation();
	const searchParams = new URLSearchParams(location.search);

	const [filters, setFilters] = useState<FoodPackageFilters>({
		country: resolveCountryFromKitchen((userKitchen && userKitchen[0]) || Kitchen.BH1),
		brand: Brand.CALO,
		kitchen: (userKitchen && userKitchen[0]) || Kitchen.BH1,
		...JSON.parse(searchParams.get('filters') || `{}`)
	});

	const { data, isLoading } = useQuery<any, Error, { data: any[] }>(
		['food-packages', { limit: 1000, filters }],
		getListWithParams,
		{
			suspense: false,
			onSuccess: () => {
				searchParams.set('filters', JSON.stringify(filters));
				history.push({
					pathname: location.pathname,
					search: searchParams.toString()
				});
			}
		}
	);
	const packagesList = data?.data as any[];

	return (
		<>
			<section className="section is-title-bar">
				<div className="level">
					<div className="level-left">
						<div className="level-item">
							<ul>
								<li>
									Packaging / {filters.country} / {filters.kitchen}{' '}
								</li>
							</ul>
						</div>
					</div>
					<div className="level-right">
						<div className="level-item">
							{roles.includes(Permission.CREATE_FOOD_PACKAGE) && (
								<Button icon="fas fa-plus" onClick={() => history.push(Routes.newPackage)} />
							)}
						</div>
					</div>
				</div>
			</section>
			<div>
				{isLoading ? (
					<CaloLoader />
				) : (
					<div className="card has-table has-table-container-upper-radius">
						<div className="card-content">
							<div className="table-container">
								<table className="table is-fullwidth is-striped is-hoverable is-sortable">
									<thead>
										<tr className="bg-black">
											<th style={{ color: 'white' }}>Name</th>
											<th style={{ color: 'white' }}>Type</th>
											<th style={{ color: 'white' }}>Elements</th>
											<th style={{ color: 'white' }}>Total Cost</th>
										</tr>
									</thead>
									{packagesList && packagesList.length === 0 ? (
										<span className="absolute w-full text-4xl mt-4 text-center font-bold text-gray-400">NO PACKAGES</span>
									) : (
										<tbody>
											{packagesList?.map((packages) => <PackagesRow key={packages.id} packages={packages} filters={filters} />)}
										</tbody>
									)}
								</table>
							</div>
						</div>
					</div>
				)}
				<Settings onFilter={setFilters} filters={filters} />
			</div>
		</>
	);
};

export default PackagesList;
