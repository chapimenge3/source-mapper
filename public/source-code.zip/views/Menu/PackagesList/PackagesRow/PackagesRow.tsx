import { FoodPackageFilters, Permission } from '@calo/dashboard-types';
import { getListWithParams } from 'actions';
import { Routes } from 'lib/enums';
import { useUserRoles } from 'lib/hooks';
import { round } from 'lodash-es';
import { useQuery } from 'react-query';
import { Link } from 'react-router-dom';

interface PackagesRowProps {
	packages: any;
	filters: FoodPackageFilters;
}
const PackagesRow = ({ packages, filters }: PackagesRowProps) => {
	const roles = useUserRoles();

	const { data } = useQuery<any, Error, { data: any[] }>(
		[
			'food-package-elements',
			{
				limit: 1000,
				filters: { country: filters.country, brand: filters.brand, kitchen: filters.kitchen }
			}
		],
		getListWithParams,
		{
			suspense: true
		}
	);

	const elements = data?.data || [];

	return (
		<tr key={packages.id}>
			<td>
				<div className="flex">
					<span className="mt-2 w-14 h-14">
						<img
							className="object-cover h-full rounded-s-md"
							width={120}
							alt="package img"
							onError={(e: any) => (e.target.src = 'https://via.placeholder.com/120')}
							src={`${process.env.REACT_APP_BUCKET_URL}/food-package/${packages.id}/square@1x.jpg`}
						/>
					</span>
					<span className="ml-2 mt-4 flex">
						{roles.includes(Permission.VIEW_FOOD_PACKAGE) ? (
							<Link to={Routes.package.replace(':id', packages.id)}>{packages.name}</Link>
						) : (
							packages.name
						)}
					</span>
				</div>
			</td>
			<td>{packages.type}</td>
			<td>
				<div key={packages.id} className="w-64">
					{packages.elements.map((r: any) => elements.find((k) => k.id === r.id)?.name).join(', ')}
				</div>
			</td>
			<td>{round(packages.cost, 3)}</td>
		</tr>
	);
};

export default PackagesRow;
