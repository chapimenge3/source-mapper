import { useEffect, useState } from 'react';

import { parseISO, subDays } from 'date-fns';
import { format } from 'date-fns/fp';
import { compact, flatten, flattenDepth, unionBy, uniq } from 'lodash-es';
import { useMutation, useQuery } from 'react-query';
import { RouteComponentProps, generatePath } from 'react-router';
import { useLocation } from 'react-router-dom';
import { toast } from 'react-toastify';

import { CreateMenuReq } from '@calo/dashboard-types';
import { Brand, Country, Kitchen } from '@calo/types';
import { Box, Card, Stack, Typography } from '@mui/material';

import { createMenu, getMenu } from 'actions';
import { caloTheme } from 'assets/images/theme/calo';
import { MenuTable } from 'components';
import { Routes } from 'lib/enums';
import { mealTracking, selectCountry } from 'lib/helpers';
import { useUserKitchens } from 'lib/hooks';
import { Food, Menu, MenuDraft, PopulateMenuReq } from 'lib/interfaces';
import ActionsCard from './ActionsCard';
import FilterCriteriaCard from './FilterCriteriaCard';
import FoodPickerCard from './FoodPickerCard';
import useMenuForm from './useMenuForm';

type NewMenuProps = RouteComponentProps;

const NewMenu = ({ history }: NewMenuProps) => {
	const userKitchens: Kitchen[] = useUserKitchens();
	const location = useLocation() as any;
	const [mealDraftOptions, setMealDraftOptions] = useState<MenuDraft>(mealTracking);
	const [cardOpen, setCardOpen] = useState<string>('');
	const [brand, setBrand] = useState<Brand>(Brand.CALO);
	const [country, setCountry] = useState<Country>(Country.BH);
	const [kitchen, setKitchen] = useState<Kitchen>(Kitchen.BH1);
	const [populateMenuData, setPopulateMenuData] = useState<PopulateMenuReq[]>([]);
	const [replaceFood, setReplaceFood] = useState<{ open: boolean; name: string }>({ open: false, name: '' });
	const [selectedFoods, setSelectedFoods] = useState<Food[]>([]);
	const [duplicateMenuDate, setDuplicateMenuDate] = useState<Date>(subDays(new Date(), 1));
	const {
		data,
		refetch: refetchDuplicateMenu,
		isLoading
	} = useQuery<any, Error, Menu>(
		[`menu/${format('yyyy-MM-dd')(duplicateMenuDate)}`, { brand: brand, kitchen: kitchen || undefined }],
		getMenu,
		{
			enabled: false
		}
	);
	useEffect(() => {
		if (data) {
			setSelectedFoods(flatten(data.food) as Food[]);
			setFieldValue('food', uniq(data.food.map((foodData) => foodData.id)));
			setMealDraftOptions(data.draft || mealDraftOptions);
			setFieldValue('draft', data.draft || mealDraftOptions);
			toast('Menu Duplicated Successfully', { type: 'success' });
		}
	}, [data]);
	const { mutateAsync: createMutation } = useMutation(createMenu);

	const onSubmit = async ({ day, food, country, tags, brand, kitchen }: CreateMenuReq) => {
		await createMutation(
			{
				day,
				food: flatten(Object.values(food)),
				country: country,
				tags: tags,
				brand: brand,
				kitchen: kitchen,
				draft: mealDraftOptions as any
			},
			{
				onSuccess: (data) => {
					const path = generatePath(Routes.menu, { brand: data.brand, kitchen: data.kitchen, id: data.id });
					history.push(path);
				}
			}
		);
	};

	useEffect(() => {
		if (location.state && location?.state.country && location?.state.brand && location?.state.kitchen) {
			setCountry(location.state?.country);
			setBrand(location.state?.brand);
			setKitchen(location.state?.kitchen);
			const state = { ...location.state };
			setFieldValue('country', state.country!);
			setFieldValue('brand', Brand.CALO);
			setFieldValue('kitchen', userKitchens[0]);
			delete state.country;
			delete state.brand;
			history.replace(location.pathname);
		}
	}, []);

	const { values, setFieldValue } = useMenuForm(onSubmit);

	const [populateSearchDate, setPopulateSearchDate] = useState(populateMenuData[0]?.day);

	useEffect(() => {
		setCardOpen(populateSearchDate);
	}, [populateSearchDate]);

	useEffect(() => {
		if (populateMenuData.length > 0) {
			setPopulateSearchDate(populateMenuData[0].day);
		}
	}, [populateMenuData]);

	const handleFoodChanges = (food: Food[], tags: any) => {
		if (populateMenuData.length > 0) {
			const index = populateMenuData.findIndex((data) => data.day === cardOpen);
			if (index >= 0) {
				const addedFoodMenu = { ...populateMenuData[index], food: unionBy(populateMenuData[index].food, food) };
				const modifiedMenu = populateMenuData.map((menu) => (menu.day === addedFoodMenu.day ? addedFoodMenu : menu));
				setPopulateMenuData(modifiedMenu);
			}
		} else {
			setSelectedFoods((old) => unionBy(old, food, 'id'));
			const allFood = uniq([...food.map((f) => f.id), ...values.food]);
			const allTags = uniq(compact(tags?.concat(values.tags)));
			setFieldValue('food', allFood);
			if (allTags.length > 0) {
				setFieldValue('tags', allTags);
			}
		}
	};

	const handleAddFoodTag = (foodName: string, tag: string) => {
		if (populateMenuData.length > 0) {
			const index = populateMenuData.findIndex((data) => data.day === cardOpen);
			if (index >= 0) {
				const removeFoodList = populateMenuData[index].food?.filter((food) => food.name.en === foodName);
				const tags = removeFoodList.map((f) => [{ foodId: f.id, value: [tag as any] }]);
				const allTags = uniq(compact([...flatten(compact(tags)), ...populateMenuData[index].tags!]));
				const selectedMenuRemoveMeal = { ...populateMenuData[index], tags: flattenDepth(compact(allTags)) };
				const modifiedMenu = populateMenuData.map((menu) =>
					menu.day === selectedMenuRemoveMeal.day ? selectedMenuRemoveMeal : menu
				);
				setPopulateMenuData(modifiedMenu);
			}
		} else {
			const foodTagData = selectedFoods.filter((food) => food.name.en === foodName);
			const tags = foodTagData.map((f) => [{ foodId: f.id, value: [tag] }]);
			const oldTagsModified = values.tags?.filter((tag) => tag.foodId !== foodTagData[0].id && tag.value.length > 0);
			const allTags = uniq(compact([...flatten(compact(tags)), ...oldTagsModified!]));
			setFieldValue('tags', flatten(compact(allTags)));
		}
	};

	const handleRemoveFood = (removedIds: string[]) => {
		if (populateMenuData.length > 0) {
			const index = populateMenuData.findIndex((data) => data.day === cardOpen);
			if (index >= 0) {
				const selectedMenuRemoveMeal = {
					...populateMenuData[index],
					food: populateMenuData[index].food.filter((food) => !removedIds.includes(food.id))
				};
				const modifiedMenu = populateMenuData.map((menu) =>
					menu.day === selectedMenuRemoveMeal.day ? selectedMenuRemoveMeal : menu
				);
				setPopulateMenuData(modifiedMenu);
			}
		} else {
			setSelectedFoods(selectedFoods.filter((selectedFood) => !removedIds.includes(selectedFood.id)));
			const foodList = values.food.filter((r) => !removedIds.includes(r));
			const tagList = values.tags && values.tags.filter((r) => r !== null && !removedIds.includes(r.foodId));
			setFieldValue('food', foodList);
			if (values.tags && values.tags.length > 0) {
				setFieldValue('tags', tagList);
			}
		}
	};

	useEffect(() => {
		if (!values.kitchen.includes(values.country)) {
			selectCountry({
				value: values.country,
				kitchens: userKitchens,
				setFieldValue
			});
		}
	}, [values.country]);

	useEffect(() => {
		setFieldValue('food', []);
		setBrand(values.brand);
		setCountry(values.country);
		setKitchen(values.kitchen);
		setSelectedFoods([]);
	}, [values.brand, values.country, values.kitchen]);

	const findCardIndexByDate = () => populateMenuData.findIndex((menu) => menu.day === populateSearchDate);

	useEffect(() => {
		if (populateMenuData && populateMenuData.length > 0) {
			const cardIndex = findCardIndexByDate();
			if (cardIndex >= 0) {
				const cardElement = document.getElementById(`card-${cardIndex - 1}`);
				setTimeout(() => {
					cardElement?.scrollIntoView({ behavior: 'smooth' });
				}, 100);
			} else {
				toast(`No Menu populated for this day ${populateSearchDate}`, { type: 'error', autoClose: 2000 });
			}
		}
	}, [populateSearchDate]);

	const handleFoodIds = () => {
		if (populateMenuData.length > 0) {
			const index = populateMenuData.findIndex((data) => data.day === cardOpen);
			if (index >= 0) {
				const populateMenuFoodIds = populateMenuData[index].food.map((f) => f.id);
				return populateMenuFoodIds as string[];
			}
		} else {
			return values.food;
		}
	};

	return (
		<>
			<ActionsCard
				values={values}
				brand={brand}
				kitchen={kitchen}
				country={country}
				cardOpen={cardOpen}
				populateMenuData={populateMenuData}
				replaceFood={replaceFood}
				selectedFoods={selectedFoods}
				mealDraftOptions={mealDraftOptions}
				setMealDraftOptions={setMealDraftOptions}
				onSubmit={onSubmit}
				duplicateMenuDate={duplicateMenuDate}
				setDuplicateMenuDate={setDuplicateMenuDate}
				refetchDuplicateMenu={refetchDuplicateMenu}
				handleFoodIds={handleFoodIds}
				setFieldValue={setFieldValue}
				setReplaceFood={setReplaceFood}
				setSelectedFoods={setSelectedFoods}
				handleFoodChanges={handleFoodChanges}
				setPopulateMenuData={setPopulateMenuData}
				selectedDate={values.day}
			/>
			<FilterCriteriaCard
				values={values}
				populateMenuData={populateMenuData}
				setFieldValue={setFieldValue}
				setPopulateMenuData={setPopulateMenuData}
			/>
			<FoodPickerCard
				brand={brand}
				country={country}
				kitchen={kitchen}
				populateSearchDate={populateSearchDate}
				handleFoodIds={handleFoodIds}
				handleFoodChanges={handleFoodChanges}
				setPopulateSearchDate={setPopulateSearchDate}
			/>
			{
				<Card
					variant="outlined"
					sx={{
						mb: 2,
						width: 'full',
						border: 'none',
						borderRadius: '8px',
						paddingBottom: '4px',
						[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
							flexDirection: 'column'
						}
					}}
				>
					<Box display={'flex'} flexDirection={'row'} justifyContent={'space-between'} sx={{ ml: 2, mt: 3 }}>
						<Stack display={'flex'} flexDirection={'row'} justifyContent={'space-between'}>
							<Typography
								sx={{
									fontFamily: caloTheme.typography.fontFamily,
									fontWeight: 600,
									fontSize: '20px',
									lineHeight: '24px',
									mr: 3
								}}
							>{`${format('EEEE dd/MM/yyyy')(parseISO(values.day))}`}</Typography>
						</Stack>
					</Box>
					<Box sx={{ ml: 2, mt: 4, minHeight: '20rem' }}>
						<MenuTable
							brand={values.brand}
							kitchen={values.kitchen}
							foodLabel={values.tags}
							selectedDate={values.day}
							foodList={selectedFoods}
							setReplaceFood={setReplaceFood}
							handleAddFoodTag={(v, r) => handleAddFoodTag(v, r)}
							removeFood={(removedIds) => handleRemoveFood(removedIds)}
							draftTrack={mealDraftOptions}
							isMealsLoading={isLoading}
						/>
					</Box>
				</Card>
			}
		</>
	);
};

export default NewMenu;
