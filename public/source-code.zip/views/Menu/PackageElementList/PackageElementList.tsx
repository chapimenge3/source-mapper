import { useState } from 'react';

import { useQuery } from 'react-query';
import { useHistory, useLocation } from 'react-router-dom';

import { FoodPackageElementFilters, Permission } from '@calo/dashboard-types';
import { Brand, Kitchen } from '@calo/types';

import { getListWithParams } from 'actions';
import { Button, CaloLoader } from 'components';
import { resolveCountryFromKitchen } from 'lib';
import { Routes } from 'lib/enums';
import { useUserKitchens, useUserRoles } from 'lib/hooks';
import PackageElementRow from './PackageElementRow';
import Settings from './Settings';

const PackageElementList = () => {
	const roles = useUserRoles();
	const history = useHistory();
	const userKitchen = useUserKitchens();
	const location = useLocation();
	const searchParams = new URLSearchParams(location.search);

	const [filters, setFilters] = useState<FoodPackageElementFilters>({
		country: resolveCountryFromKitchen((userKitchen && userKitchen[0]) || Kitchen.BH1),
		brand: Brand.CALO,
		kitchen: (userKitchen && userKitchen[0]) || Kitchen.BH1,
		...JSON.parse(searchParams.get('filters') || `{}`)
	});
	const { data, isLoading } = useQuery<any, Error, { data: any[] }>(
		[
			'food-package-elements',
			{ limit: 1000, filters: { country: filters.country, brand: filters.brand, kitchen: filters.kitchen } }
		],
		getListWithParams,
		{
			suspense: false,
			onSuccess: () => {
				searchParams.set('filters', JSON.stringify(filters));
				history.push({
					pathname: location.pathname,
					search: searchParams.toString()
				});
			}
		}
	);

	const elements = data?.data || [];

	return (
		<>
			<section className="section is-title-bar">
				<div className="level">
					<div className="level-left">
						<div className="level-item">
							<ul>
								<li>
									Packaging Elements / {filters.country} / {filters.kitchen}
								</li>
							</ul>
						</div>
					</div>
					{roles.includes(Permission.CREATE_FOOD_PACKAGE_ELEMENT) && (
						<div className="level-right">
							<div className="level-item">
								<Button icon="fas fa-plus" onClick={() => history.push(Routes.newPackageElement)} />
							</div>
						</div>
					)}
				</div>
			</section>
			<div>
				{isLoading ? (
					<CaloLoader />
				) : (
					<div className="card has-table has-table-container-upper-radius">
						<div className="card-content">
							<div className="table-container">
								<table className="table is-fullwidth is-striped is-hoverable is-sortable is-fullwidth">
									<thead>
										<tr className="bg-black">
											<th style={{ color: 'white' }}>Name</th>
											<th style={{ color: 'white' }}>Cost</th>
											<th style={{ color: 'white' }}>Size</th>
										</tr>
									</thead>
									{elements && elements.length === 0 ? (
										<span className="absolute w-full text-4xl mt-4 text-center font-bold text-gray-400">NO ELEMENTS</span>
									) : (
										<tbody>
											{elements.map((element) => (
												<PackageElementRow key={element.id} element={element} />
											))}
										</tbody>
									)}
								</table>
							</div>
						</div>
					</div>
				)}
				<Settings onFilter={setFilters} filters={filters} />
			</div>
		</>
	);
};

export default PackageElementList;
