import { Permission } from '@calo/dashboard-types';
import { Link } from 'react-router-dom';

import { Routes } from 'lib/enums';
import { useUserRoles } from 'lib/hooks';

interface PackageElementRowProps {
	element: any;
}

const PackageElementRow = ({ element }: PackageElementRowProps) => {
	const roles = useUserRoles();

	return (
		<tr>
			<td>
				{roles.includes(Permission.VIEW_FOOD_PACKAGE_ELEMENT) ? (
					<Link to={Routes.packageElement.replace(':id', element.id)}>{element.name}</Link>
				) : (
					element.name
				)}
			</td>
			<td>{element.cost}</td>
			<td>{element.size}</td>
		</tr>
	);
};

export default PackageElementRow;
