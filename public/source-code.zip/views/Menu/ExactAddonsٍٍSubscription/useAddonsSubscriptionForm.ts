import { useFormik } from 'formik';
import { UpdateAddonsSubscriptionMenuReq } from '@calo/dashboard-types';
import { Brand, Kitchen } from '@calo/types';

export default (
	addons: any,
	brand: Brand,
	kitchen: Kitchen,
	onSubmit: (values: UpdateAddonsSubscriptionMenuReq) => Promise<void>
) =>
	useFormik<UpdateAddonsSubscriptionMenuReq>({
		enableReinitialize: true,
		initialValues: {
			brand: brand,
			kitchen: kitchen,
			food:
				addons?.food.map((f: any) => ({
					id: f.id,
					priority: +f.priority
				})) || []
		},

		validate: (values: UpdateAddonsSubscriptionMenuReq) => {
			const errors: any = {};

			if (values.food.length === 0) {
				errors.food = true;
			}

			return errors;
		},
		onSubmit: async (values) => {
			try {
				await onSubmit(values);
			} catch (error) {
				console.log(error);
			}
		}
	});
