import { useEffect, useRef, useState } from 'react';

import { parseISO } from 'date-fns';
import { format } from 'date-fns/fp';
import { compact, flatten, unionBy, uniq } from 'lodash-es';
import { useMutation, useQuery } from 'react-query';
import { generatePath, useParams } from 'react-router';
import { toast } from 'react-toastify';

import { Permission, UpdateMenuReq } from '@calo/dashboard-types';
import { Brand, Country, Kitchen, MenuTagValue } from '@calo/types';
import { Box, Button, Card, CircularProgress, Link, Stack, Typography } from '@mui/material';
import Tooltip from '@mui/material/Tooltip';

import { generateMenu, getListWithParams, getRecordWithParams, updateMenu } from 'actions';
import { caloTheme } from 'assets/images/theme/calo';
import { FoodPicker, MenuTable, ModalRef, TrackMealsPopup } from 'components';
import AddMealsByFilterPopup from 'components/AddMealsByFilterPopup';
import Popup from 'components/Popup';
import { useFoodListByFilters } from 'hooks';
import useAddingTopRatedMeals from 'hooks/useAddingTopRatedMeals';
import { mealTracking, resolveCountry } from 'lib';
import { Routes } from 'lib/enums';
import history from 'lib/history';
import { useUserRoles } from 'lib/hooks';
import { Food, Menu, MenuDraft } from 'lib/interfaces';
import useMenuForm from './useMenuForm';

const ExactMenu = () => {
	const { id, country, brand, kitchen } = useParams<{ id: string; country: Country; brand: Brand; kitchen: Kitchen }>();
	const { data } = useQuery([`menu`, id, { brand, kitchen: kitchen || Kitchen.BH1 }], getRecordWithParams, {
		suspense: true
	});
	const menu = data as any;
	const addMealsByFiltersRef = useRef<ModalRef>();
	const [filterName, setFilterName] = useState<string>();
	const [selectedFoods, setSelectedFoods] = useState<Food[]>([]);
	const [replaceFood, setReplaceFood] = useState<{ open: boolean; name: string }>({ open: false, name: '' });
	const [selectedMenuFilters, setSelectedMenuFilters] = useState({
		type: '',
		plan: '',
		protein: '',
		taste: '',
		sandwich: undefined,
		lastUsed: '',
		base: '',
		category: ''
	});
	const [filtersOn, setFiltersOn] = useState<boolean>(false);
	const trackMealsRef = useRef<ModalRef>();
	const [mealDraftOptions, setMealDraftOptions] = useState<MenuDraft>(menu.draft || mealTracking);

	const { data: foodList, isLoading: foodLoading } = useQuery<any, Error, { data: Food[] }>(
		[
			'food',
			{
				filters: {
					name: filterName ? filterName : undefined,
					country,
					brand,
					isDeleted: false,
					kitchen: menu.kitchen || kitchen
				},
				calculatePurchasingCost: true,
				sort: {
					orderBy: 'name',
					orderMode: 'asc'
				},
				page: 0,
				limit: 20
			}
		],
		getListWithParams,
		{
			suspense: false,
			enabled: !!filterName
		}
	);

	const { topRatedMeals, isLoadingTopRated } = useAddingTopRatedMeals({ country, brand, kitchen });

	const { foodListFiltersData, foodFiltersLoading, hasNextPage, fetchNextPage, remove, isLoadingFetchNextPage } =
		useFoodListByFilters({
			selectedMenuFilters,
			country,
			kitchen,
			brand,
			filtersOn
		});

	const { mutateAsync: updateMutation } = useMutation(updateMenu);
	const { mutateAsync: generateMutation } = useMutation(generateMenu);

	const path = generatePath(Routes.menuList, { brand: menu.brand, kitchen: menu.kitchen || kitchen });
	// eslint-disable-next-line @typescript-eslint/no-unused-vars
	const [generatedAt, setGeneratedAt] = useState(menu.generatedAt);
	const [generateLoading, setGenerateLoading] = useState<boolean>(false);

	const onSubmit = async (values: UpdateMenuReq) => {
		await updateMutation(
			{
				...values,
				id,
				mKitchen: menu.kitchen || kitchen,
				mBrand: menu.brand,
				draft: mealDraftOptions as any
			},
			{
				onSuccess: (data) => {
					const path = generatePath(Routes.menu, { brand: data.brand, kitchen: data.kitchen, id: data.id });
					history.push(path);
				}
			}
		);
	};

	const handleGenerateMenu = (values: Menu) => {
		setGenerateLoading(true);
		generateMutation(
			{
				...values,
				id,
				kitchen: menu.kitchen ? menu.kitchen : Kitchen.BH1,
				brand: menu.brand
			},
			{
				onSuccess: () => {
					setGenerateLoading(false);
				},

				onError: (error: any) => {
					setGenerateLoading(false);
					if (error.response.status && error.response.status === 504) {
						toast('It is taking too much time, please report to the engineering team', {
							type: 'error'
						});
					}
				}
			}
		);
	};

	const { values, setFieldValue } = useMenuForm(menu!, onSubmit);
	const roles = useUserRoles();

	useEffect(() => {
		if (menu.food) {
			setSelectedFoods(menu.food);
			setFieldValue(
				'food',
				menu.food.map((r: any) => r.id)
			);
		}
	}, [menu]);

	useEffect(() => {
		if (replaceFood.open && replaceFood.name.length > 0) {
			addMealsByFiltersRef.current?.open();
		} else {
			addMealsByFiltersRef.current?.close();
		}
	}, [replaceFood]);

	const handleFoodChanges = (food: Food[], tags: any) => {
		setSelectedFoods((old) => unionBy(old, food, 'id'));
		const allFood = uniq([...food.map((f) => f.id), ...values.food]);
		const allTags = tags ? uniq(compact([...tags, ...values.tags])) : values.tags;
		setFieldValue('food', allFood);
		setFieldValue('tags', allTags && allTags.length > 0 ? allTags : []);
	};

	const handleAddFoodTag = (foodName: string, tag: string) => {
		const foodTagData = selectedFoods.filter((food) => food.name.en === foodName);
		const tags = foodTagData.map((f) => [{ foodId: f.id, value: [tag] }]);
		const oldTagsModified = values.tags?.filter((tag) => tag.foodId !== foodTagData[0].id && tag.value.length > 0);
		const allTags = uniq(compact([...flatten(compact(tags)), ...oldTagsModified!]));
		setFieldValue('tags', flatten(compact(allTags)));
	};

	const handleRemoveFood = (removedIds: string[]) => {
		setSelectedFoods(selectedFoods.filter((selectedFood) => !removedIds.includes(selectedFood.id)));
		const foodList = values.food?.filter((r) => !removedIds.includes(r));
		const tagList = values.tags && values.tags.filter((r) => r !== null && !removedIds.includes(r.foodId));
		setFieldValue('food', foodList);
		if (values.tags && values.tags.length > 0) {
			setFieldValue('tags', tagList);
		}
	};

	const handleAddTopRatedMeals = async () => {
		if (topRatedMeals && topRatedMeals.some((food) => ['XS', 'S', 'M', 'L'].includes(food.size))) {
			const allFood = topRatedMeals.filter((food) => ['XS', 'S', 'M', 'L'].includes(food.size));
			const tags = allFood.map((f) => [{ foodId: f.id, value: [MenuTagValue.TOP_RATED] }]);
			handleFoodChanges(allFood as any, flatten(tags));
		} else {
			toast(`No top rated meals available for ${values.country}-${values.kitchen}`, { type: 'error', autoClose: 2000 });
		}
	};

	const handleClosePopup = () => {
		remove();
		addMealsByFiltersRef.current?.close();
		setSelectedMenuFilters({
			type: '',
			plan: '',
			protein: '',
			taste: '',
			sandwich: undefined,
			lastUsed: '',
			base: '',
			category: ''
		});
		setFiltersOn(false);
		setReplaceFood({ open: false, name: '' });
	};

	const handleReplaceFood = (selectedFood: Food[]) => {
		const replacedFoodSize = selectedFoods.filter((food) => food.name.en === replaceFood.name);
		setSelectedFoods(selectedFoods.filter((selectedFood) => !replacedFoodSize.map((r) => r.id).includes(selectedFood.id)));
		const allFood = uniq([...selectedFood.map((f) => f.id), ...values.food]);
		setSelectedFoods((old) => unionBy(old, selectedFood, 'id'));
		setFieldValue('food', allFood);
		handleClosePopup();
	};

	return (
		<>
			<Card
				variant="outlined"
				sx={{
					width: 'full',
					border: 'none',
					mb: 2,
					borderRadius: '8px',
					paddingBottom: '4px',
					[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
						flexDirection: 'column'
					}
				}}
			>
				<Box
					display={'flex'}
					flexDirection="row"
					justifyContent={'space-between'}
					sx={{
						padding: 2,
						[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
							display: 'flex',
							flexDirection: 'column',
							justifyContent: 'center'
						}
					}}
					width="100%"
				>
					<Stack
						sx={{
							[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
								display: 'flex',
								flexDirection: 'column',
								justifyContent: 'center'
							}
						}}
					>
						<Typography
							variant="h5"
							sx={{
								my: 'auto',
								fontWeight: 600,
								fontSize: '23px',
								lineHeight: '28px',
								border: 'none',
								fontFamily: caloTheme.typography.fontFamily,
								':hover': {
									border: 'none',
									fontFamily: caloTheme.typography.fontFamily
								}
							}}
						>
							<Link href={path} style={{ textDecoration: 'none' }}>
								Menu
							</Link>{' '}
							/ {menu.id}
						</Typography>
					</Stack>
					<Stack
						sx={{
							width: '70%',
							display: 'flex',
							justifyContent: 'end',
							flexDirection: 'row',
							[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
								width: '100%',
								flexDirection: 'row',
								justifyContent: 'center',
								marginTop: 2
							}
						}}
					>
						<Button
							variant="outlined"
							aria-label="new-subscription-cancel"
							sx={{
								width: 'full',
								height: '51px',
								lineHeight: '17px',
								fontWeight: 600,
								mr: 2,
								fontSize: '14px',
								borderRadius: '8px',
								boxShadow: 'none',
								borderColor: caloTheme.palette.primary500,
								color: caloTheme.palette.primary500,
								'&:hover': {
									boxShadow: 'none',
									borderColor: caloTheme.palette.primary600
								}
							}}
							onClick={() => trackMealsRef.current?.open()}
						>
							Track Meals
						</Button>
						<Button
							variant="outlined"
							aria-label="new-subscription-cancel"
							sx={{
								width: 'full',
								height: '51px',
								lineHeight: '17px',
								fontWeight: 600,
								mr: 2,
								fontSize: '14px',
								borderRadius: '8px',
								boxShadow: 'none',
								borderColor: caloTheme.palette.primary500,
								color: caloTheme.palette.primary500,
								'&:hover': {
									boxShadow: 'none',
									borderColor: caloTheme.palette.primary600
								}
							}}
							onClick={() => addMealsByFiltersRef.current?.open()}
						>
							Add Meals By Filters
						</Button>
						<Tooltip
							title="There are no top rated meals"
							placement="top"
							arrow
							disableHoverListener={
								topRatedMeals ? topRatedMeals.some((food) => ['XS', 'S', 'M', 'L'].includes(food.size)) : false
							}
						>
							<span>
								<Button
									variant="outlined"
									aria-label="new-subscription-cancel"
									sx={{
										height: '51px',
										lineHeight: '17px',
										fontWeight: 600,
										mr: 2,
										fontSize: '14px',
										borderRadius: '8px',
										boxShadow: 'none',
										borderColor: caloTheme.palette.primary500,
										color: caloTheme.palette.primary500,
										'&:hover': {
											boxShadow: 'none',
											borderColor: caloTheme.palette.primary600
										}
									}}
									disabled={
										isLoadingTopRated ||
										!topRatedMeals ||
										topRatedMeals.filter((food) => ['XS', 'S', 'M', 'L'].includes(food.size)).length === 0
									}
									onClick={() => handleAddTopRatedMeals()}
									endIcon={isLoadingTopRated ? <CircularProgress size={20} color="inherit" /> : null}
								>
									Add Top Rated meals
								</Button>
							</span>
						</Tooltip>
						{roles.includes(Permission.GENERATE_DAY_MENU) && (
							<Stack display={'flex'} flexDirection={'column'}>
								<Button
									variant="outlined"
									data-test="menu-exact-generate-button"
									sx={{
										textDecoration: 'none',
										height: '51px',
										lineHeight: '17px',
										fontWeight: 600,
										mr: 2,
										fontSize: '14px',
										borderRadius: '8px',
										boxShadow: 'none',
										backgroundColor: caloTheme.palette.secondaryYellow200,
										borderColor: caloTheme.palette.secondaryYellow200,
										color: caloTheme.palette.secondaryYellow900,
										'&:hover': {
											boxShadow: 'none',
											color: caloTheme.palette.secondaryYellow900,
											borderColor: caloTheme.palette.secondaryYellow300,
											backgroundColor: caloTheme.palette.secondaryYellow300
										}
									}}
									disabled={generateLoading}
									onClick={() => handleGenerateMenu(menu)}
								>
									{menu.generatedAt ? 'Regenerate this day menu' : 'Generate this day menu'}
								</Button>
								{generatedAt && (
									<p className="text-gray-300 text-xs">{`Last generated: ${format('dd-MM-yyyy')(parseISO(generatedAt))}`}</p>
								)}
							</Stack>
						)}

						<Button
							variant="contained"
							data-test="menu-exact-save-button"
							sx={{
								width: '120px',
								height: '51px',
								lineHeight: '17px',
								fontWeight: 600,
								fontSize: '14px',
								borderRadius: '8px',
								backgroundColor: caloTheme.palette.primary500,
								borderColor: caloTheme.palette.primary500,
								boxShadow: 'none',
								color: 'white',
								'&:hover': {
									boxShadow: 'none',
									backgroundColor: caloTheme.palette.primary600,
									borderColor: caloTheme.palette.primary600
								}
							}}
							onClick={() => onSubmit(values)}
							disabled={isLoadingTopRated}
						>
							Save
						</Button>
					</Stack>
				</Box>
			</Card>
			<Card
				variant="outlined"
				sx={{
					mb: 2,
					width: 'full',
					overflow: 'visible',
					border: 'none',
					borderRadius: '8px',
					paddingBottom: '4px',
					[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
						flexDirection: 'column'
					}
				}}
			>
				<Stack
					sx={{
						my: 2,
						display: 'flex',
						flexDirection: 'row',
						[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
							display: 'flex',
							flexDirection: 'column',
							justifyContent: 'center'
						}
					}}
				>
					<Typography
						variant="h5"
						sx={{
							m: 2,
							width: '50%',
							fontWeight: 600,
							fontSize: '23px',
							lineHeight: '28px',
							border: 'none',
							fontFamily: caloTheme.typography.fontFamily,
							':hover': {
								border: 'none',
								fontFamily: caloTheme.typography.fontFamily
							}
						}}
					>
						{menu!.id}
					</Typography>
					<Typography
						variant="h5"
						sx={{
							m: 2,
							width: '50%',
							textAlign: 'end',
							fontWeight: 600,
							fontSize: '23px',
							lineHeight: '28px',
							border: 'none',
							fontFamily: caloTheme.typography.fontFamily,
							':hover': {
								border: 'none',
								fontFamily: caloTheme.typography.fontFamily
							}
						}}
					>
						{values.brand?.toUpperCase()}-{resolveCountry(values?.country).toUpperCase()}-{values?.kitchen?.toUpperCase()}
					</Typography>
				</Stack>
				<Box
					component="form"
					sx={{
						width: 'full',
						mt: 2,
						'& .MuiTextField-root': { m: 2, width: '20%', justifyContent: 'space-between' },
						[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
							flexDirection: 'row',
							width: '96%',
							'& .MuiTextField-root': { my: 2, mx: 1, width: '96%' }
						}
					}}
				>
					<Stack>
						{values.country && values.brand && (
							<Box
								sx={{
									m: 2
								}}
							>
								<label className="label mb-4">Meal</label>
								<FoodPicker
									disabled={false}
									createMenu={false}
									showPopulateDate={false}
									foodLoading={foodLoading}
									value={values.food || []}
									setFilterName={setFilterName}
									populateSearchDate={values.day!}
									setPopulateSearchDate={() => null}
									foodList={(foodList?.data || []).filter((f) => !f.deletedAt)}
									onChange={(food, tags) => handleFoodChanges(food as Food[], tags)}
								/>
							</Box>
						)}
					</Stack>
				</Box>
			</Card>
			<Card>
				<Box sx={{ ml: 2, mt: 4, minHeight: '20rem' }}>
					<MenuTable
						brand={menu.brand}
						kitchen={menu.kitchen}
						selectedDate={menu.id}
						foodLabel={values.tags}
						foodList={selectedFoods}
						setReplaceFood={setReplaceFood}
						handleAddFoodTag={(name, tag) => handleAddFoodTag(name, tag)}
						removeFood={(removed) => handleRemoveFood(removed)}
						draftTrack={mealDraftOptions}
					/>
				</Box>
			</Card>

			<Popup
				maxWidth="desktop"
				title={replaceFood.open ? `Swap Meal ${replaceFood.name}` : 'Update Menu'}
				ref={addMealsByFiltersRef}
				onClose={handleClosePopup}
				info={`${values.brand?.toUpperCase()}-${resolveCountry(values?.country).toUpperCase()}-${values?.kitchen?.toUpperCase()}`}
			>
				<AddMealsByFilterPopup
					values={values}
					filtersOn={filtersOn}
					foodIds={values.food || []}
					replaceFood={replaceFood}
					setFiltersOn={setFiltersOn}
					isLoading={foodFiltersLoading}
					fetchNextPage={fetchNextPage}
					hasNextPage={hasNextPage || false}
					handleClosePopup={handleClosePopup}
					handleReplaceFood={handleReplaceFood}
					selectedMenuFilters={selectedMenuFilters}
					isFetchingNextPage={isLoadingFetchNextPage}
					addMealsByFiltersRef={addMealsByFiltersRef}
					setSelectedMenuFilters={setSelectedMenuFilters}
					handleFoodChanges={(food, tags) => handleFoodChanges(food, tags)}
					foodListFilters={(foodListFiltersData || []).filter((f) => !f.deletedAt)}
				/>
			</Popup>

			<Popup maxWidth="xl" fullWidth title="Track Meals" ref={trackMealsRef} onClose={() => trackMealsRef.current?.close()}>
				<Box sx={{ flexDirection: 'column', width: '100%' }}>
					<Stack display={'flex'} flexDirection={'row'} justifyContent={'space-between'}>
						<TrackMealsPopup mealOptions={mealDraftOptions} setOptions={setMealDraftOptions} trackMealsRef={trackMealsRef} />
					</Stack>
				</Box>
			</Popup>
		</>
	);
};
export default ExactMenu;
