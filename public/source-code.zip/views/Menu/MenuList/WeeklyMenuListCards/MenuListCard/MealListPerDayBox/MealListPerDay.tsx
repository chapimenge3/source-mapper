import { Brand } from '@calo/types';
import { Icon as Iconify } from '@iconify/react';
import CloseOutlinedIcon from '@mui/icons-material/CloseOutlined';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import ShuffleIcon from '@mui/icons-material/Shuffle';
import { Box, IconButton, Stack, Typography } from '@mui/material';
import { caloTheme } from 'assets/images/theme/calo';
import { ModalRef } from 'components';
import MenuMealInfo from 'components/MenuMealInfo';
import { handleCalculateLastTime } from 'components/MenuTable/MenuTable';
import Popup from 'components/Popup';
import { format } from 'date-fns';
import { Menu, MenuFood } from 'lib/interfaces';
import { useEffect, useRef, useState } from 'react';

interface MealListPerDayBoxProps {
	menu: Menu;
	isEditable: boolean;
	setSelectedMenu: (value: Menu) => void;
	recurringFoodNames: string[];
	handleUpdateMenu: any;
	setReplaceFood: (value: { open: boolean; name: string; menuId: string; data?: MenuFood }) => void;
	menuWithFoodCost: { [name: string]: number } | undefined;
}

const MealListPerDayBox = ({
	setSelectedMenu,
	handleUpdateMenu,
	setReplaceFood,
	isEditable,
	menu,
	recurringFoodNames,
	menuWithFoodCost
}: MealListPerDayBoxProps) => {
	const infoMealRef = useRef<ModalRef>();
	const [editMeal, setEditMeal] = useState<string[]>([]);
	const [selectedMeal, setSelectedMeal] = useState<MenuFood | undefined>();

	const renderMealSize = (foodName: string) =>
		menu.food
			.filter((food) => food.name.en === foodName)
			.map((food, index) => (
				<Typography key={index} sx={{ fontWeight: 600, fontSize: '14px', lineHeight: '17px', mt: '3px' }}>
					{`${food.size}${index === menu.food.length - 1 ? '' : '-'}`}
				</Typography>
			));

	const handleSelectMealInfo = (food: MenuFood) => {
		setSelectedMeal(food);
		infoMealRef.current?.open();
	};

	useEffect(() => {
		if (!isEditable) {
			setEditMeal([]);
		}
	}, [isEditable]);

	return (
		<Box
			sx={{
				width: '18%',
				border: '1px solid ' + caloTheme.palette.neutral100,
				borderRadius: '8px',
				display: 'flex',
				flexDirection: 'column',
				py: '8px',
				px: '6px'
			}}
		>
			<Typography
				sx={{
					fontSize: '14px',
					fontWeight: 600,
					alignSelf: 'center',
					marginBottom: '8px'
				}}
			>
				{format(new Date(menu.id), 'eeee dd/MM')}
			</Typography>
			<Stack sx={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
				{menu.food.map((food, index) => {
					return (
						<>
							<Box
								key={`${food.id}-${index}-${menu.id}`}
								sx={{
									py: '10px',
									px: '6px',
									minHeight: '96px',
									display: 'flex',
									flexDirection: 'column',
									justifyContent: 'space-between',
									borderRadius: '4px',
									alignContent: 'center',
									backgroundColor: recurringFoodNames.includes(food.name.en) ? '#FAEEEE' : 'white'
								}}
							>
								<Stack sx={{ flexDirection: 'row', justifyContent: 'space-between' }}>
									<Typography sx={{ fontSize: '14px', marginBottom: '6px' }}>{food.name.en}</Typography>
									{editMeal.includes(food.id) ? (
										<IconButton
											onClick={() => setEditMeal((prev) => prev.filter((f) => f !== food.id))}
											style={{
												cursor: 'pointer',
												backgroundColor: recurringFoodNames.includes(food.name.en) ? '#FAEEEE' : caloTheme.palette.primary100,
												display: isEditable ? 'flex' : 'none',
												marginTop: '-4px',
												width: '32px',
												height: '32px',
												borderRadius: '16px',
												textAlign: 'center',
												padding: '4px'
											}}
										>
											<Iconify width={'32px'} height={'32px'} icon="ic:outline-check" color={caloTheme.palette.neutral900} />
										</IconButton>
									) : (
										<IconButton
											style={{
												cursor: 'pointer',
												backgroundColor: recurringFoodNames.includes(food.name.en) ? '#FAEEEE' : caloTheme.palette.neutral50,
												display: isEditable ? 'flex' : 'none',
												width: '32px',
												height: '32px',
												borderRadius: '16px',
												textAlign: 'center',
												padding: '4px',
												marginTop: '-4px'
											}}
										>
											<Iconify
												icon="lucide:pen"
												width="17px"
												height="17px"
												color={caloTheme.palette.neutral900}
												onClick={() => setEditMeal((prev) => [...prev, food.id])}
											/>
										</IconButton>
									)}
								</Stack>
								<Typography
									sx={{
										display: editMeal.includes(food.id) ? 'none' : 'flex',
										fontSize: '16px',
										mb: editMeal.includes(food.id) ? '8px' : '0px'
									}}
								>
									{menuWithFoodCost ? menuWithFoodCost[food.name.en] : '--'} %
								</Typography>
								<Stack
									key={food.id}
									display={editMeal.includes(food.id) ? 'flex' : 'none'}
									sx={{
										flexDirection: 'row',
										justifyContent: 'space-between',
										alignVertical: 'center',
										pt: '2px',
										mb: '-2px'
									}}
								>
									<InfoOutlinedIcon
										sx={{ cursor: 'pointer', width: '24px', height: '24px' }}
										onClick={() => handleSelectMealInfo(food)}
									/>
									<ShuffleIcon
										sx={{ cursor: 'pointer', width: '24px', height: '24px' }}
										onClick={() => {
											setSelectedMenu(menu);
											setReplaceFood({ open: true, name: food.name.en, menuId: menu.id, data: food });
										}}
									/>
									<CloseOutlinedIcon
										sx={{ cursor: 'pointer', width: '24px', height: '24px' }}
										onClick={() => handleUpdateMenu(food, menu.id)}
									/>
								</Stack>
							</Box>
							{index !== menu.food.length - 1 && (
								<Stack sx={{ width: '100%', height: '1px', backgroundColor: caloTheme.palette.neutral100 }} />
							)}
						</>
					);
				})}
			</Stack>
			<Popup
				maxWidth="lg"
				title="Info"
				ref={infoMealRef}
				onClose={() => {
					infoMealRef.current?.close();
					setSelectedMeal(undefined);
				}}
			>
				<MenuMealInfo
					key={selectedMeal?.id || ''}
					handleCalculateLastTime={(food) => handleCalculateLastTime(food, food.brand || menu.brand)}
					setSelectedMeal={setSelectedMeal}
					handleFoodSizes={renderMealSize}
					infoMealRef={infoMealRef}
					selectedMeal={selectedMeal}
					brand={menu?.brand || Brand.CALO}
				/>
			</Popup>
		</Box>
	);
};

export default MealListPerDayBox;
