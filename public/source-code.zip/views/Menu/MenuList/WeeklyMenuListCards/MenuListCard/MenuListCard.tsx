import { Card, Stack, Typography } from '@mui/material';
import { caloTheme } from 'assets/images/theme/calo';
import { MenuCategory, MenuPopulateType } from 'lib/enums';
import { Menu } from 'lib/interfaces';
import { startsWith } from 'lodash-es';
import { findOccurrencesOfSameFood } from '../../helpers';
import MealListPerDayBox from './MealListPerDayBox';

interface MenuListCardProps {
	filteredMenuList: Menu[];
	isEditable: boolean;
	handleUpdateMenu: any;
	setSelectedMenu: (value: Menu) => void;
	categoryName: MenuCategory;
	setReplaceFood: (value: { open: boolean; name: string; menuId: string }) => void;
	menusWithFoodCostObject: {
		[date: string]: {
			[name: string]: number;
		};
	};
}

const MenuListCard = ({
	setSelectedMenu,
	setReplaceFood,
	handleUpdateMenu,
	isEditable,
	filteredMenuList,
	categoryName,
	menusWithFoodCostObject
}: MenuListCardProps) => {
	const foodOccurrences: { [foodName: string]: number } = findOccurrencesOfSameFood(filteredMenuList);
	const recurringFoodNames = Object.keys(foodOccurrences).filter((foodName) => foodOccurrences[foodName] > 1);

	const formatCategoryName = (category: MenuCategory): string => {
		const mealType = Object.values(MenuPopulateType).find((type) => startsWith(category, type));
		return mealType && mealType !== (category as string) ? `${mealType} - ${category.slice(mealType.length).trim()}` : category;
	};

	return (
		<Card
			variant="outlined"
			sx={{
				width: '100%',
				border: 'none',
				display: 'flex',
				flexDirection: 'column',
				justifyContent: 'space-between',
				mb: 2,
				padding: 2,
				borderRadius: '8px',
				[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
					flexDirection: 'column'
				}
			}}
		>
			<Typography
				sx={{
					backgroundColor: caloTheme.palette.neutral50,
					height: '46px',
					width: '100%',
					display: 'flex',
					alignItems: 'center',
					justifyContent: 'center',
					borderRadius: '5px',
					fontWeight: 600,
					marginBottom: '10px'
				}}
			>
				{formatCategoryName(categoryName)}
			</Typography>
			<Stack sx={{ display: 'flex', flexDirection: 'row', gap: '10px', alignItems: 'flex-start' }}>
				{filteredMenuList?.map((menu) => (
					<MealListPerDayBox
						menu={menu}
						key={menu.id}
						isEditable={isEditable}
						setReplaceFood={setReplaceFood}
						setSelectedMenu={setSelectedMenu}
						handleUpdateMenu={handleUpdateMenu}
						recurringFoodNames={recurringFoodNames}
						menuWithFoodCost={menusWithFoodCostObject[menu.id]}
					/>
				))}
			</Stack>
		</Card>
	);
};

export default MenuListCard;
