import { every, isEmpty } from 'lodash-es';

import { CaloLoader, ModalRef } from 'components';
import AddMealsByFilterPopup from 'components/AddMealsByFilterPopup';
import Popup from 'components/Popup';
import { useFoodListByFilters } from 'hooks';
import { resolveCountry } from 'lib';
import { Food, Menu, MenuFood } from 'lib/interfaces';
import { useEffect, useMemo, useRef, useState } from 'react';
import { MenuListFilters } from '../MenuList';
import { filterMenus, findMenusWithFoodCost } from '../helpers';
import MenuListCard from './MenuListCard';

interface WeekMenuListProps {
	foodList: Food[];
	foodIds: string[];
	isLoading: boolean;
	isEditable: boolean;
	filters: MenuListFilters;
	weeklyMenuList: Menu[] | undefined;
	onMenuUpdate: (updatedMenu: Menu) => void;
	setWeeklyAverageCost: React.Dispatch<React.SetStateAction<number>>;
}

const WeeklyMenuListCards = ({
	onMenuUpdate,
	isEditable,
	filters,
	isLoading,
	foodList,
	foodIds,
	weeklyMenuList,
	setWeeklyAverageCost
}: WeekMenuListProps) => {
	const addMealsByFiltersRef = useRef<ModalRef>();
	const [filtersOn, setFiltersOn] = useState<boolean>(false);
	const [selectedMenu, setSelectedMenu] = useState<Menu | undefined>();
	const [replaceFood, setReplaceFood] = useState<{ open: boolean; name: string; menuId: string; data?: Food }>({
		open: false,
		name: '',
		menuId: ''
	});
	const [selectedMenuFilters, setSelectedMenuFilters] = useState({
		type: '',
		plan: '',
		protein: '',
		taste: '',
		sandwich: undefined,
		lastUsed: '',
		base: '',
		category: ''
	});
	const filteredMenuLists = filterMenus(weeklyMenuList);
	const { foodListFiltersData, foodFiltersLoading, hasNextPage, fetchNextPage, isLoadingFetchNextPage } = useFoodListByFilters({
		selectedMenuFilters,
		country: filters.country,
		kitchen: filters.kitchen,
		brand: filters.brand,
		filtersOn
	});

	const menusWithFoodCostObject = useMemo(() => {
		return findMenusWithFoodCost(foodList, foodIds, weeklyMenuList, filters.kitchen);
	}, [weeklyMenuList?.map((menu) => menu.id).join(','), foodList, foodIds]);

	useEffect(() => {
		if (Object.values(menusWithFoodCostObject).length > 0) {
			const allValues = Object.values(menusWithFoodCostObject).flatMap((menu) => Object.values(menu));
			const sum = allValues.reduce((acc, value) => acc + value, 0);
			const average = sum / allValues.length;
			setWeeklyAverageCost(average);
		}
	}, [Object.keys(menusWithFoodCostObject)]);

	const isFoodEmptyInMenus = (menus: Menu[]) => {
		return every(menus, (menu) => isEmpty(menu.food));
	};

	const handleUpdateMenu = (food: MenuFood, menuId: string) => {
		const updatedMenu = weeklyMenuList?.find((menu) => menu.id === menuId);
		if (!updatedMenu) return;
		const removedIds = updatedMenu!.food.filter((meal) => meal.name.en === food.name.en).map((meal) => meal.id);
		const updatedFoodList = updatedMenu.food.filter((meal) => meal.name.en !== food.name.en);
		const tagList = updatedMenu.tags?.filter((r) => r !== null && !removedIds.includes(r.foodId));
		const newUpdatedMenu = { ...updatedMenu, food: updatedFoodList, tags: tagList || undefined };
		onMenuUpdate(newUpdatedMenu);
	};

	const handleClosePopup = () => {
		addMealsByFiltersRef.current?.close();
		setSelectedMenuFilters({
			type: '',
			plan: '',
			protein: '',
			taste: '',
			sandwich: undefined,
			lastUsed: '',
			base: '',
			category: ''
		});
		setFiltersOn(false);
		setSelectedMenu(undefined);
		setReplaceFood({ open: false, name: '', menuId: '' });
	};

	useEffect(() => {
		if (!weeklyMenuList) return;
		if (replaceFood.open && replaceFood.name.length > 0) {
			addMealsByFiltersRef.current?.open();
		} else {
			addMealsByFiltersRef.current?.close();
			setSelectedMenu(undefined);
		}
	}, [replaceFood]);

	const handleReplaceFood = (selectedFood: MenuFood[]) => {
		if (!selectedMenu || !weeklyMenuList) return;
		const updatedMenu = weeklyMenuList.find((menu) => menu.id === selectedMenu.id);
		const replacedFoodSize = updatedMenu!.food.filter((food) => food.name.en !== replaceFood.name);
		const updatedMenuData = {
			...updatedMenu,
			food: replacedFoodSize ? [...replacedFoodSize, ...selectedFood] : [...selectedFood]
		};
		onMenuUpdate(updatedMenuData as any);
		handleClosePopup();
	};

	if (isLoading) {
		return <CaloLoader />;
	}

	return (
		<>
			{filteredMenuLists.map(
				({ category, filteredMenuList }) =>
					!isFoodEmptyInMenus(filteredMenuList) && (
						<MenuListCard
							key={category}
							isEditable={isEditable}
							categoryName={category}
							setReplaceFood={setReplaceFood}
							setSelectedMenu={setSelectedMenu}
							handleUpdateMenu={handleUpdateMenu}
							filteredMenuList={filteredMenuList}
							menusWithFoodCostObject={menusWithFoodCostObject}
						/>
					)
			)}
			<Popup
				maxWidth="desktop"
				title={replaceFood.open ? `Swap Meal ${replaceFood.name}` : 'Update Menu'}
				ref={addMealsByFiltersRef}
				onClose={() => handleClosePopup()}
				info={`${selectedMenu && selectedMenu?.brand.toUpperCase()}-${resolveCountry(selectedMenu?.country).toUpperCase()}-${selectedMenu?.kitchen?.toUpperCase()}`}
			>
				<AddMealsByFilterPopup
					confirmation={true}
					filtersOn={filtersOn}
					foodIds={foodIds || []}
					replaceFood={replaceFood}
					setFiltersOn={setFiltersOn}
					fetchNextPage={fetchNextPage}
					isLoading={foodFiltersLoading}
					values={(selectedMenu as any) || []}
					hasNextPage={hasNextPage || false}
					handleClosePopup={handleClosePopup}
					handleReplaceFood={handleReplaceFood}
					selectedMenuFilters={selectedMenuFilters}
					addMealsByFiltersRef={addMealsByFiltersRef}
					isFetchingNextPage={isLoadingFetchNextPage}
					setSelectedMenuFilters={setSelectedMenuFilters}
					handleFoodChanges={(food, tags) => console.log(food, tags)}
					foodListFilters={(foodListFiltersData || []).filter((f) => !f.deletedAt)}
				/>
			</Popup>
		</>
	);
};

export default WeeklyMenuListCards;
