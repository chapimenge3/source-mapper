import ExcelJS from 'exceljs';
import { saveAs } from 'file-saver';
import { History } from 'history';

import { Permission } from '@calo/dashboard-types';
import DownloadIcon from '@mui/icons-material/Download';
import { Box, Button, Card, Stack } from '@mui/material';

import { caloTheme } from 'assets/images/theme/calo';
import { MenuPresentationType, Routes } from 'lib/enums';
import { useUserRoles } from 'lib/hooks';
import { Food, Menu } from 'lib/interfaces';
import { generateMenuSheets } from './ExportUtils';

import { MenuListFilters } from '../MenuList';
import { findDailyAverageCostPerMenu, findMenusWithFoodCost } from '../helpers';
import DailyMenuDatePicker from './DailyMenuDatePicker';
import WeeklyMenusDatePicker from './WeeklyMenusDatePicker';

type MenuActionsCardProps = {
	filters: MenuListFilters;
	history: History<unknown>;
	menuList: Menu[] | undefined;
	weeklyMenuList: Menu[] | undefined;
	foodList: Food[];
	foodIds: string[];
	isLoading: boolean;
	isFoodListLoading: boolean;
	weeklyAverageCost: number;
	isWeeklyMenuChanged: boolean;
} & (
	| {
			menuPresentation: MenuPresentationType.daily;
			selectedDay: string;
			setSelectedDay: React.Dispatch<React.SetStateAction<string>>;
	  }
	| {
			menuPresentation: MenuPresentationType.weekly;
			selectedWeek: number;
			setSelectedWeek: React.Dispatch<React.SetStateAction<number>>;
	  }
);

const MenuActionsCard = ({
	isWeeklyMenuChanged,
	filters,
	history,
	menuList,
	weeklyMenuList,
	foodList,
	foodIds,
	weeklyAverageCost,
	isLoading,
	isFoodListLoading,
	...props
}: MenuActionsCardProps) => {
	const userRoles = useUserRoles();

	const exportMenuHandler = async () => {
		if (!weeklyMenuList) {
			return;
		}

		const workbook = new ExcelJS.Workbook();

		const menusWithFoodCostObject = findMenusWithFoodCost(foodList, foodIds, weeklyMenuList, filters.kitchen);

		generateMenuSheets(
			weeklyMenuList,
			foodList,
			foodIds,
			filters.kitchen,
			weeklyAverageCost,
			workbook,
			true,
			menusWithFoodCostObject
		);
		for (const menu of weeklyMenuList) {
			const dailyAverageCost = findDailyAverageCostPerMenu(menusWithFoodCostObject, menu.id);
			generateMenuSheets([menu], foodList, foodIds, filters.kitchen, dailyAverageCost, workbook);
		}

		const buffer = await workbook.xlsx.writeBuffer();
		const fileType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
		const fileExtension = '.xlsx';
		const blob = new Blob([buffer], { type: fileType });
		saveAs(blob, 'weekly-menu-stats' + fileExtension);
	};

	return (
		<Card
			variant="outlined"
			sx={{
				width: 'full',
				border: 'none',
				mb: 2,
				borderRadius: '8px',
				paddingBottom: '4px',
				[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
					flexDirection: 'column'
				}
			}}
		>
			<Box
				display={'flex'}
				flexDirection="row"
				sx={{
					padding: 2,
					width: '100%',
					[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
						display: 'flex',
						flexDirection: 'column',
						width: '100%',
						justifyContent: 'center'
					}
				}}
			>
				<Stack
					display={'flex'}
					flexDirection="row"
					sx={{
						width: '50%',
						m: 'auto',
						[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
							display: 'flex',
							width: '100%',
							flexDirection: 'column',
							justifyContent: 'center'
						}
					}}
				>
					{userRoles.includes(Permission.CREATE_MENU) && (
						<Button
							variant="contained"
							data-test="menu-exact-save-button"
							sx={{
								width: '120px',
								height: '51px',
								fontWeight: 600,
								fontSize: '20px',
								borderRadius: '8px',
								textTransform: 'none',
								backgroundColor: caloTheme.palette.primary500,
								borderColor: caloTheme.palette.primary500,
								boxShadow: 'none',
								color: 'white',
								'&:hover': {
									boxShadow: 'none',
									backgroundColor: caloTheme.palette.primary600,
									borderColor: caloTheme.palette.primary600
								}
							}}
							onClick={() =>
								history.push(Routes.newMenu, {
									country: filters.country,
									brand: filters.brand,
									kitchen: filters.kitchen
								})
							}
							disabled={
								isLoading || (props.menuPresentation === MenuPresentationType.weekly && isFoodListLoading) || isWeeklyMenuChanged
							}
						>
							+ Add
						</Button>
					)}
				</Stack>
				<Stack
					sx={{
						display: 'flex',
						flexDirection: 'row',
						width: '50%',
						justifyContent: 'end',
						[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
							display: 'flex',
							width: '100%',
							flexDirection: 'column',
							justifyContent: 'center'
						}
					}}
				>
					<Stack
						sx={{
							my: 1,
							width: '100%',
							display: 'flex',
							flexDirection: 'row',
							justifyContent: 'end',
							gap: '18px',
							[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
								display: 'flex',
								width: '100%',
								flexDirection: 'column',
								justifyContent: 'center'
							}
						}}
					>
						{props.menuPresentation === MenuPresentationType.daily && (
							<DailyMenuDatePicker menuList={menuList} selectedDay={props.selectedDay} setSelectedDay={props.setSelectedDay} />
						)}
						{props.menuPresentation === MenuPresentationType.weekly && (
							<>
								<Button
									variant="outlined"
									startIcon={<DownloadIcon />}
									onClick={exportMenuHandler}
									disabled={isLoading || isFoodListLoading || isWeeklyMenuChanged}
									sx={{
										color: caloTheme.palette.neutral900,
										borderColor: caloTheme.palette.neutral900,
										borderRadius: '8px',
										fontSize: '20px',
										fontWeight: 600,
										textTransform: 'none',
										':hover': {
											color: caloTheme.palette.neutral900,
											borderColor: caloTheme.palette.neutral900
										}
									}}
								>
									Download
								</Button>
								<WeeklyMenusDatePicker
									filters={filters}
									selectedWeek={props.selectedWeek}
									setSelectedWeek={props.setSelectedWeek}
									isWeeklyMenuChanged={isWeeklyMenuChanged}
								/>
							</>
						)}
					</Stack>
				</Stack>
			</Box>
		</Card>
	);
};

export default MenuActionsCard;
