import DateFnsAdapter from '@date-io/date-fns';
import { Button, TextField, TextFieldProps, Typography } from '@mui/material';
import { Box, Stack } from '@mui/system';
import { DesktopDatePicker, LocalizationProvider, PickersDay, pickersDayClasses } from '@mui/x-date-pickers';
import { caloTheme } from 'assets/images/theme/calo';
import InputThemeProvider from 'components/MUI/InputThemeProvider';
import { eachWeekOfInterval, endOfMonth, format, getWeek, startOfMonth } from 'date-fns';
import { findStartAndEndDateForWeek } from 'lib';
import { useState } from 'react';
import { MenuListFilters } from '../../MenuList';

interface WeeklyMenusDatePickerProps {
	selectedWeek: number;
	filters: MenuListFilters;
	isWeeklyMenuChanged: boolean;
	setSelectedWeek: React.Dispatch<React.SetStateAction<number>>;
}

const WeeklyMenusDatePicker = ({ isWeeklyMenuChanged, selectedWeek, setSelectedWeek }: WeeklyMenusDatePickerProps) => {
	const [selectedDate, setSelectedDate] = useState(new Date());

	const handleRenderDateInput = (params: TextFieldProps) => {
		const { inputProps, ...rest } = params;

		const { startOfWeekDate, endOfWeekDate } = findStartAndEndDateForWeek(selectedWeek);

		const updatedInputProps = {
			...inputProps,
			value: `Week ${selectedWeek} (${format(startOfWeekDate, 'dd/MM')} - ${format(endOfWeekDate, 'dd/MM')})`
		};

		return (
			<InputThemeProvider>
				<TextField
					{...rest}
					inputProps={updatedInputProps}
					sx={{
						mr: 2,
						width: '20%',
						minWidth: '240px',
						[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
							mt: 6,
							width: '100%',
							display: 'flex',
							borderRadius: '8px',
							paddingLeft: '30px',
							flexDirection: 'column',
							justifyContent: 'center'
						}
					}}
					error={false}
				/>
			</InputThemeProvider>
		);
	};

	const handleRenderDay = (day: Date, DayComponentProps: any) => {
		const { startOfWeekDate, endOfWeekDate } = findStartAndEndDateForWeek(selectedWeek);

		if (
			format(day, 'yyyy-MM-dd') < format(startOfWeekDate, 'yyyy-MM-dd') ||
			format(day, 'yyyy-MM-dd') > format(endOfWeekDate, 'yyyy-MM-dd')
		) {
			return <PickersDay disabled={true} sx={{ backgroundColor: 'none' }} {...DayComponentProps} />;
		}

		return (
			<PickersDay
				{...DayComponentProps}
				onClick={() => null}
				sx={{
					color: 'black',
					backgroundColor: caloTheme.palette.primary100,
					':hover': { color: 'black', backgroundColor: caloTheme.palette.neutral100 },
					[`&&.${pickersDayClasses.selected}`]: {
						border: 1,
						color: 'black',
						backgroundColor: caloTheme.palette.neutral100,
						borderColor: caloTheme.palette.primary600
					}
				}}
			/>
		);
	};

	return (
		<LocalizationProvider dateAdapter={DateFnsAdapter} sx={{ mb: '4px' }}>
			<DesktopDatePicker
				components={{
					PaperContent: ({ children, ...props }: any) => {
						const startOfMonthDate = startOfMonth(selectedDate);
						const endOfMonthDate = endOfMonth(selectedDate);
						const weeksInMonth = eachWeekOfInterval({ start: startOfMonthDate, end: endOfMonthDate }, { weekStartsOn: 0 });

						return (
							<Box {...props} sx={{ display: 'flex', flexDirection: 'row' }}>
								<Stack
									sx={{
										display: 'flex',
										flexDirection: 'column',
										marginTop: '20px',
										alignItems: 'center',
										marginLeft: '10px',
										gap: '3px'
									}}
								>
									<Typography sx={{ marginBottom: '48px' }}>Week</Typography>
									{weeksInMonth.map((weekStartDate) => {
										const week = getWeek(weekStartDate);
										return (
											<Button
												key={weekStartDate.toString()}
												onClick={() => setSelectedWeek(getWeek(weekStartDate))}
												sx={{
													fontSize: '13px',
													fontWeight: 600,
													color: week === selectedWeek ? 'white' : 'black',
													minWidth: '35px',
													borderRadius: '20px',
													backgroundColor: week === selectedWeek ? caloTheme.palette.primary500 : 'white',
													':hover': { color: 'white', backgroundColor: caloTheme.palette.primary500 }
												}}
											>
												{getWeek(weekStartDate)}
											</Button>
										);
									})}
								</Stack>
								{children}
							</Box>
						);
					}
				}}
				showDaysOutsideCurrentMonth
				label="Week"
				inputFormat="dd-MM-yyyy"
				value={selectedDate}
				disabled={isWeeklyMenuChanged}
				shouldDisableDate={() => true}
				renderInput={handleRenderDateInput}
				renderDay={(day, _value, DayComponentProps) => handleRenderDay(new Date(day), DayComponentProps)}
				onMonthChange={(event) => setSelectedDate(new Date(event))}
				onChange={() => {}}
				minDate={format(Date.now(), 'yyyy-MM-dd')}
			/>
		</LocalizationProvider>
	);
};

export default WeeklyMenusDatePicker;
