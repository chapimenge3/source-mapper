import { Box, Card, Stack, Typography } from '@mui/material';
import { caloTheme } from 'assets/images/theme/calo';
import SelectMUI from 'components/MUI/SelectMUI';
import { format } from 'date-fns';
import { foodInformationFormSingleSelectCustomStyles } from 'lib/componentStyles';
import { MenuPresentationType } from 'lib/enums';
import { MenuListFilters } from '../MenuList';

interface MenuHeaderCardProps {
	selectedDay: string;
	filters: MenuListFilters;
	isWeeklyMenuChanged: boolean;
	menuPresentation: MenuPresentationType;
	setMenuPresentation: React.Dispatch<React.SetStateAction<MenuPresentationType>>;
}

interface menuPresentationOption {
	label: MenuPresentationType.daily | MenuPresentationType.weekly;
	value: MenuPresentationType.daily | MenuPresentationType.weekly;
}

const MenuHeaderCard = ({
	isWeeklyMenuChanged,
	filters,
	selectedDay,
	menuPresentation,
	setMenuPresentation
}: MenuHeaderCardProps) => {
	const menuPresentationOptions: menuPresentationOption[] = [
		{
			label: MenuPresentationType.daily,
			value: MenuPresentationType.daily
		},
		{
			label: MenuPresentationType.weekly,
			value: MenuPresentationType.weekly
		}
	];

	return (
		<Card
			variant="outlined"
			sx={{
				width: 'full',
				border: 'none',
				display: 'flex',
				flexDirection: 'row',
				justifyContent: 'space-between',
				alignItems: 'center',
				mb: 2,
				padding: 2,
				borderRadius: '8px',
				[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
					flexDirection: 'column'
				}
			}}
		>
			<Box
				sx={{
					display: 'flex',
					flexDirection: 'column',
					justifyContent: 'space-between',
					alignItems: 'center',
					[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
						display: 'flex',
						flexDirection: 'column',
						justifyContent: 'center'
					}
				}}
			>
				<Stack
					sx={{
						display: 'flex',
						flexDirection: 'row',
						alignItems: 'center',
						[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
							display: 'flex',
							flexDirection: 'column',
							mt: 2
						}
					}}
				>
					<Typography
						variant="h5"
						sx={{
							fontWeight: 600,
							fontSize: '16px',
							mr: '16px'
						}}
					>
						Menu {filters.country}
					</Typography>

					{menuPresentation === MenuPresentationType.weekly && (
						<Typography
							variant="h5"
							sx={{
								fontWeight: 600,
								fontSize: '20px'
							}}
						>
							{format(new Date(selectedDay), 'dd/MM/yy')} - {format(new Date(selectedDay), 'eeee')}
						</Typography>
					)}
				</Stack>
			</Box>
			<Stack sx={{ width: '120px' }}>
				<SelectMUI
					value={menuPresentation}
					isDisabled={isWeeklyMenuChanged}
					onChange={(data: menuPresentationOption) => setMenuPresentation(data.value as MenuPresentationType)}
					options={menuPresentationOptions}
					customStyles={{
						...foodInformationFormSingleSelectCustomStyles,
						control: (defaultStyle: any) => ({
							...defaultStyle,
							boxShadow: 'none',
							borderRadius: '8px',
							height: '46px',
							padding: '6px 0px'
						})
					}}
				/>
			</Stack>
		</Card>
	);
};

export default MenuHeaderCard;
