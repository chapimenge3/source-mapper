import { useEffect, useMemo, useState } from 'react';

import { format } from 'date-fns';
import { RouteComponentProps, useLocation } from 'react-router';
import { generatePath } from 'react-router-dom';
import { toast } from 'react-toastify';

import { Brand, Country, Kitchen } from '@calo/types';

import { UpdateMenuReq } from '@calo/dashboard-types';
import { getListWithParams, updateMenu } from 'actions';
import { getWeek } from 'date-fns';
import { findStartAndEndDateForWeek, resolveCountryFromKitchen } from 'lib';
import { MenuPresentationType, Routes } from 'lib/enums';
import { useUserKitchens } from 'lib/hooks';
import { Food, Menu } from 'lib/interfaces';
import queryClient from 'lib/queryClient';
import { chunk, flatMap, isEqual, uniq } from 'lodash';
import { useMutation, useQuery } from 'react-query';
import DailyMenuCard from './DailyMenuCard';
import MenuActionsCard from './MenuActionsCard';
import MenuHeaderCard from './MenuHeaderCard';
import Settings from './Settings';
import WeeklyAverageCostCard from './WeeklyAverageCostCard';
import WeeklyMenuListCards from './WeeklyMenuListCards';

type MenuListProps = RouteComponentProps;

export type MenuListFilters = {
	country: Country;
	brand: Brand;
	kitchen: Kitchen;
};

const MenuList = ({ history }: MenuListProps) => {
	const location = useLocation();
	const userKitchen = useUserKitchens();
	const searchParams = new URLSearchParams(location.search);
	const [isEditable, setIsEditable] = useState<boolean>(false);
	const [isWeeklyMenuChanged, setIsWeeklyMenuChanged] = useState<boolean>(false);
	const [foodIds, setFoodIds] = useState<string[]>([]);
	const [menuPresentation, setMenuPresentation] = useState(MenuPresentationType.daily);
	const [selectedWeek, setSelectedWeek] = useState(getWeek(new Date(), { weekStartsOn: 0 }));
	const [selectedDay, setSelectedDay] = useState(format(Date.now(), 'yyyy-MM-dd'));
	const [weeklyAverageCost, setWeeklyAverageCost] = useState(0);
	const { mutateAsync: updateMutation } = useMutation(updateMenu);
	const [originalWeeklyMenuData, setOriginalWeeklyMenuData] = useState<Menu[]>([]);

	const [filters, setFilters] = useState<MenuListFilters>({
		country: resolveCountryFromKitchen((userKitchen && userKitchen[0]) || Kitchen.BH1),
		brand: Brand.CALO,
		kitchen: (userKitchen && userKitchen[0]) || Kitchen.BH1,
		...JSON.parse(searchParams.get('filters') || `{}`)
	});

	const { data: menuList, isLoading } = useQuery<any, Error, Menu[]>(
		[`menu`, { brand: filters.brand, kitchen: filters.kitchen || undefined }],
		getListWithParams,
		{
			suspense: true,
			onSuccess: (data) => {
				searchParams.set('filters', JSON.stringify(filters));
				history.push({
					pathname: location.pathname,
					search: searchParams.toString()
				});
				for (const row of data || []) {
					queryClient.setQueryData(['menu', row.id], row);
				}
			}
		}
	);

	const { startOfWeekDate, endOfWeekDate } = findStartAndEndDateForWeek(selectedWeek);

	const { data: weeklyMenuList, isLoading: isWeeklyMenuLoading } = useQuery<any, Error, Menu[]>(
		[
			`menu`,
			{
				brand: filters.brand,
				kitchen: filters.kitchen || undefined,
				date: { gte: format(startOfWeekDate, 'yyyy-MM-dd'), lte: format(endOfWeekDate, 'yyyy-MM-dd') }
			}
		],
		getListWithParams,
		{
			onSuccess: (data) => {
				searchParams.set('filters', JSON.stringify(filters));
				history.push({
					pathname: location.pathname,
					search: searchParams.toString()
				});
				for (const row of data || []) {
					queryClient.setQueryData(['menu', row.id], row);
				}
				setFoodIds(uniq(flatMap(data || [], (menu) => menu.food.map((food) => food.id))));
			}
		}
	);

	useEffect(() => {
		if (weeklyMenuList && weeklyMenuList.length > 0 && originalWeeklyMenuData.length === 0) {
			setOriginalWeeklyMenuData(weeklyMenuList);
		}
	}, [weeklyMenuList]);

	const [chunkIndex, setChunkIndex] = useState<number>(0);
	const [foodList, setFoodList] = useState<Food[]>([]);

	const chunkedData = useMemo(() => chunk(foodIds, 100), [foodIds]);

	const { isLoading: isFoodListLoading } = useQuery<any, Error, any>(
		[
			'food',
			{
				filters: {
					country: filters.country,
					brand: filters.brand,
					kitchen: filters.kitchen,
					ids: chunkedData[chunkIndex]
				},
				sort: {
					orderBy: 'name',
					orderMode: 'asc'
				},
				page: 0,
				limit: 100
			}
		],
		getListWithParams,
		{
			enabled: chunkedData.length > 0 && chunkIndex <= chunkedData.length - 1,
			onSuccess: (data) => {
				if (data && data.data) {
					setFoodList((prevData) => [...prevData, ...data.data]);

					if (chunkIndex < chunkedData.length - 1) {
						setChunkIndex(chunkIndex + 1);
					}
				}
			},
			onError: () => {
				toast('Finding food cost failed', { type: 'error', autoClose: 2000 });
			}
		}
	);

	useEffect(() => {
		if (isWeeklyMenuLoading) {
			setFoodList([]);
			setChunkIndex(0);
			setWeeklyAverageCost(0);
		}
	}, [isWeeklyMenuLoading]);

	useEffect(() => {
		if (filters.kitchen) {
			const path = generatePath(Routes.menuList, { brand: filters.brand, kitchen: filters.kitchen });
			history.push(path);
		} else {
			toast(`No Kitchen available for ${filters.country}`, { type: 'error', autoClose: 2000 });
		}
	}, [filters]);

	const handleMenuUpdate = (updatedMenu: Menu) => {
		setIsWeeklyMenuChanged(true);
		const updatedWeeklyMenuList = weeklyMenuList?.map((menu) => (menu.id === updatedMenu.id ? updatedMenu : menu));
		queryClient.setQueryData<Menu[]>(
			[
				`menu`,
				{
					brand: filters.brand,
					kitchen: filters.kitchen || undefined,
					date: { gte: format(startOfWeekDate, 'yyyy-MM-dd'), lte: format(endOfWeekDate, 'yyyy-MM-dd') }
				}
			],
			updatedWeeklyMenuList!
		);
	};

	const onSubmit = async (values: Menu) => {
		const updatedMenu: UpdateMenuReq = {
			day: values.id,
			food: values.food?.map((food) => food.id) || [],
			country: values.country,
			tags: (values.tags as any) || [],
			brand: values.brand,
			kitchen: values.kitchen,
			generatedAt: values.generatedAt || undefined
		};
		await updateMutation(
			{
				...updatedMenu,
				id: values.id,
				mBrand: values.brand,
				mKitchen: values.kitchen,
				draft: values.draft as any
			},
			{
				onSuccess: (data) => {
					const updatedOriginals = originalWeeklyMenuData.map((menu) => {
						if (menu.id === data.id) {
							return data;
						}
						return menu;
					});
					setOriginalWeeklyMenuData(updatedOriginals);
				}
			}
		);
	};

	const handleUpdateWeeklyMenus = async () => {
		if (isWeeklyMenuChanged && weeklyMenuList) {
			try {
				const updatePromises: Promise<void>[] = weeklyMenuList.reduce<Promise<void>[]>((promises, menu) => {
					const originalMenu = originalWeeklyMenuData.find((original) => original.id === menu.id);
					if (
						!isEqual(
							menu.food?.map((f) => f.id),
							originalMenu?.food?.map((f) => f.id)
						)
					) {
						promises.push(onSubmit(menu));
					}
					return promises;
				}, []);
				await Promise.all(updatePromises);
				setIsEditable(false);
				setIsWeeklyMenuChanged(false);
			} catch (error) {
				console.error('Failed to update weekly menus:', error);
			}
		}
		setIsEditable(false);
		setIsWeeklyMenuChanged(false);
	};

	return (
		<>
			<MenuHeaderCard
				filters={filters}
				selectedDay={selectedDay}
				menuPresentation={menuPresentation}
				isWeeklyMenuChanged={isWeeklyMenuChanged}
				setMenuPresentation={setMenuPresentation}
			/>
			<MenuActionsCard
				filters={filters}
				menuList={menuList}
				foodList={foodList}
				foodIds={foodIds}
				history={history}
				selectedDay={selectedDay}
				selectedWeek={selectedWeek}
				setSelectedDay={setSelectedDay}
				weeklyMenuList={weeklyMenuList}
				setSelectedWeek={setSelectedWeek}
				menuPresentation={menuPresentation}
				weeklyAverageCost={weeklyAverageCost}
				isFoodListLoading={isFoodListLoading}
				isWeeklyMenuChanged={isWeeklyMenuChanged}
				isLoading={isLoading || isWeeklyMenuLoading}
			/>

			{menuPresentation === MenuPresentationType.daily && (
				<DailyMenuCard
					filters={filters}
					isLoading={isLoading}
					history={history}
					selectedMenu={menuList?.find((menu) => menu.id === selectedDay)}
				/>
			)}
			{menuPresentation === MenuPresentationType.weekly && (
				<>
					<WeeklyAverageCostCard
						isEditable={isEditable}
						setIsEditable={setIsEditable}
						weeklyAverageCost={weeklyAverageCost}
						setIsWeeklyMenuChanged={setIsWeeklyMenuChanged}
						handleUpdateWeeklyMenus={handleUpdateWeeklyMenus}
					/>
					<WeeklyMenuListCards
						filters={filters}
						foodIds={foodIds}
						foodList={foodList}
						isEditable={isEditable}
						onMenuUpdate={handleMenuUpdate}
						isLoading={isWeeklyMenuLoading}
						weeklyMenuList={weeklyMenuList}
						setWeeklyAverageCost={setWeeklyAverageCost}
					/>
				</>
			)}
			<Settings onFilter={setFilters} filters={filters} />
		</>
	);
};

export default MenuList;
