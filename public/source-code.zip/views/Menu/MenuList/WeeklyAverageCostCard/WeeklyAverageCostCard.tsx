import { Icon as Iconify } from '@iconify/react';
import { Card, IconButton, Stack, Typography } from '@mui/material';
import { caloTheme } from 'assets/images/theme/calo';
import { Icon } from 'components';
interface WeeklyAverageCostCardProps {
	weeklyAverageCost: number;
	isEditable: boolean;
	setIsWeeklyMenuChanged: (value: boolean) => void;
	setIsEditable: (value: boolean) => void;
	handleUpdateWeeklyMenus: any;
}
const WeeklyAverageCostCard = ({
	handleUpdateWeeklyMenus,
	weeklyAverageCost,
	isEditable,
	setIsEditable
}: WeeklyAverageCostCardProps) => {
	return (
		<Card
			variant="outlined"
			sx={{
				width: 'full',
				border: 'none',
				display: 'flex',
				flexDirection: 'row',
				alignItems: 'center',
				justifyContent: 'space-between',
				gap: '24px',
				mb: 2,
				padding: 2,
				borderRadius: '8px',
				[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
					flexDirection: 'column'
				}
			}}
		>
			<Stack sx={{ flexDirection: 'row', width: '60%' }}>
				<Typography sx={{ fontWeight: 600, mr: 2 }}>Average Weekly Cost</Typography>
				<Typography sx={{ fontWeight: 600 }}>{weeklyAverageCost.toFixed(2) || 0} %</Typography>
			</Stack>
			<Stack>
				<IconButton sx={{ m: 'auto' }}>
					{isEditable ? (
						<Iconify
							icon="ic:outline-check"
							color={caloTheme.palette.neutral900}
							style={{ fontWeight: 'bold' }}
							onClick={() => handleUpdateWeeklyMenus()}
						/>
					) : (
						<Icon
							name="editPen3"
							color={caloTheme.palette.neutral900}
							style={{ width: '24px', height: '24px' }}
							onClick={() => setIsEditable(true)}
						/>
					)}
				</IconButton>
			</Stack>
		</Card>
	);
};

export default WeeklyAverageCostCard;
