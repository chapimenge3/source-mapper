import { useState } from 'react';
import { generatePath } from 'react-router-dom';

import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { parseISO } from 'date-fns';
import { format } from 'date-fns/fp';
import { History } from 'history';
import { uniqBy } from 'lodash-es';

import { Permission } from '@calo/dashboard-types';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import { Box, Card, Stack, Typography } from '@mui/material';

import { caloTheme } from 'assets/images/theme/calo';
import { CaloLoader, Icon, MenuTable } from 'components';
import { Routes } from 'lib/enums';
import { useUserRoles } from 'lib/hooks';
import { Menu } from 'lib/interfaces';
import { MenuListFilters } from '../MenuList';
import Container from './Container';

interface DayMenuProps {
	filters: MenuListFilters;
	history: History<unknown>;
	isLoading: boolean;
	selectedMenu: Menu | undefined;
}

const DayMenuCard = ({ filters, history, isLoading, selectedMenu }: DayMenuProps) => {
	const userRoles = useUserRoles();
	const [closedCards, setClosedCards] = useState<string[]>([]);

	const handleDayClick = (date: string) => {
		const path = generatePath(Routes.menu, { brand: filters.brand, kitchen: filters.kitchen, id: date });
		return history.push(path);
	};

	if (isLoading) {
		return <CaloLoader />;
	}

	if (!selectedMenu) {
		return (
			<Container>
				<Typography
					sx={{
						display: 'flex',
						flexDirection: 'row',
						justifyContent: 'center',
						mt: 2,
						color: caloTheme.palette.neutral400,
						fontWeight: 400,
						fontSize: '32px'
					}}
				>
					No Menu For this Day
				</Typography>
			</Container>
		);
	}

	return (
		<Container>
			<Card
				variant="outlined"
				sx={{
					mb: 2,
					width: 'full',
					border: 'none',
					borderRadius: '8px',
					height: closedCards.includes(selectedMenu.id) ? '8vh' : 'auto',
					[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
						flexDirection: 'column'
					}
				}}
			>
				<Box display={'flex'} flexDirection={'row'} justifyContent={'space-between'} sx={{ ml: 2, mt: 3 }}>
					<Stack display={'flex'} flexDirection={'row'} justifyContent={'space-between'}>
						<Typography
							sx={{ fontFamily: caloTheme.typography.fontFamily, fontWeight: 600, fontSize: '20px', lineHeight: '24px', mr: 3 }}
						>{`${format('EEEE dd/MM/yyyy')(parseISO(selectedMenu.id))}`}</Typography>
						<Typography
							sx={{ fontFamily: caloTheme.typography.fontFamily, fontWeight: 600, fontSize: '20px', lineHeight: '24px', mr: 3 }}
						>{`${uniqBy(selectedMenu.food, 'name.en').length} Meals`}</Typography>
					</Stack>
					<Stack display={'flex'} flexDirection={'row'} justifyContent={'space-between'}>
						{userRoles.includes(Permission.UPDATE_MENU) && userRoles.includes(Permission.VIEW_MENU) && (
							<Stack sx={{ mr: 6 }}>
								<Icon
									name="editPen2"
									style={{ cursor: 'pointer', backgroundColor: 'white', borderColor: 'black' }}
									size={6}
									onClick={() => handleDayClick(selectedMenu.id)}
								/>
							</Stack>
						)}
						<Stack sx={{ mr: 2 }}>
							{closedCards.includes(selectedMenu.id) ? (
								<ExpandMoreIcon
									onClick={() => setClosedCards(closedCards.filter((id) => id !== selectedMenu.id))}
									sx={{ cursor: 'pointer', mt: '-4px' }}
									fontSize="large"
								/>
							) : (
								<KeyboardArrowUpIcon
									fontSize="large"
									onClick={() => setClosedCards([...closedCards, selectedMenu.id])}
									sx={{ cursor: 'pointer', mt: '-4px' }}
								/>
							)}
						</Stack>
					</Stack>
				</Box>
				<Box sx={{ ml: 2, mt: 4, minHeight: '20rem' }}>
					<MenuTable
						key={selectedMenu.id}
						selectedDate={selectedMenu.id}
						isEditable={false}
						kitchen={selectedMenu?.kitchen}
						brand={selectedMenu?.brand}
						foodList={selectedMenu?.food}
						foodLabel={selectedMenu?.tags}
						setReplaceFood={() => null}
						handleAddFoodTag={() => null}
						draftTrack={undefined}
					/>
				</Box>
			</Card>
		</Container>
	);
};

export default DayMenuCard;
