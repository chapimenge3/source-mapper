import { useEffect, useState } from 'react';

import { format as formatDate, parseISO } from 'date-fns';
import { format } from 'date-fns/fp';
import { startCase } from 'lodash-es';
import { QueryObserverResult, RefetchOptions, RefetchQueryFilters, useMutation } from 'react-query';

import { PermissionService } from '@calo/services';
import { DeliveryAddress, DeliveryStatus, DeliveryTime, Food, Subscription } from '@calo/types';
import { Box, Card, MenuItem, Stack, TextField, Typography } from '@mui/material';

import { updateDelivery } from 'actions';
import { caloTheme } from 'assets/images/theme/calo';
import { Icon } from 'components';
import { convertTimeToRangeWithFormatting } from 'lib/helpers';
import { Delivery } from 'lib/interfaces';
import { AddressService } from 'services';
import DeliveriesMealTable from './DeliveriesMealTable';
import DeliveryAction from './DeliveryAction';
import DeliveryPaymentIcons from './DeliveryPaymentIcons';
import styles from './styles';
interface DeliveriesMealsProps {
	selectedDate: string;
	selectedDelivery: Delivery;
	refetchAllDeliveries: () => void;
	subscription: Subscription & { remainingDays: number; expectedLastDeliveryDay: string; ratings: any[] };
	refetchDelivery: <TPageData>(
		options?: (RefetchOptions & RefetchQueryFilters<TPageData>) | undefined
	) => Promise<QueryObserverResult<unknown, unknown>>;
}

const DeliveriesMeals = ({
	refetchAllDeliveries,
	subscription,
	selectedDate,
	selectedDelivery,
	refetchDelivery
}: DeliveriesMealsProps) => {
	const [selectedAddress, setSelectedAddress] = useState<Delivery['deliveryAddress']>(selectedDelivery?.deliveryAddress);
	const [selectedAddressCustomTime, setSelectedAddressCustomTime] = useState<string>();

	useEffect(() => {
		setSelectedAddress(selectedDelivery?.deliveryAddress);
	}, [selectedDelivery]);

	const { mutateAsync: updateMutation } = useMutation(updateDelivery);

	const handleChangeAddress = async (deliveryAddress: string) => {
		await updateMutation({
			id: selectedDelivery.id,
			deliveryAddressId: deliveryAddress
		});
		refetchAllDeliveries();
		refetchDelivery();
	};

	const handleChangeTime = async (time: DeliveryTime) => {
		await updateMutation({ id: selectedDelivery.id, time: time });
		refetchAllDeliveries();
		refetchDelivery();
	};

	useEffect(() => {
		const address = subscription.deliveryAddresses.find((add) =>
			selectedAddress ? selectedAddress.id === add.id : add.default
		) as DeliveryAddress & { customDeliveryTime: string };
		if (address && address.customDeliveryTime) {
			const list = address.customDeliveryTime.split(':');
			const time = new Date();
			time.setHours(parseInt(list[0]));
			time.setMinutes(parseInt(list[1]));
			const formattedTime = formatDate(time, 'h:mm a');
			setSelectedAddressCustomTime(formattedTime);
		}
	}, [selectedAddress, selectedDelivery, selectedDate]);
	const giftItems =
		selectedDelivery.giftedItems && selectedDelivery.giftedItems.meal
			? selectedDelivery.giftedItems.meal.map((meal) => ({ ...meal, isGiftedItem: true }))
			: [];
	return (
		<>
			<Card variant="outlined" sx={{ ...styles.mainContainer }}>
				<Box sx={{ ...styles.mainBox }} display={'flex'} flexDirection={'row'} justifyContent={'space-between'}>
					<Stack display={'flex'} flexDirection={'row'}>
						<Typography sx={{ textAlign: 'left', ...styles.selectedDateText }}>{selectedDate}</Typography>
						{selectedDelivery.status === DeliveryStatus.cancelled || selectedDelivery.status === DeliveryStatus.paused ? (
							<Typography sx={{ ...styles.deliveryStatusText }}>
								{selectedDelivery.status === DeliveryStatus.cancelled ? 'Cancelled' : 'Paused'}
							</Typography>
						) : (
							<Typography
								sx={{
									...styles.deliveryDeliveredAtText,
									color: selectedDelivery.deliveredAt ? caloTheme.palette.primary500 : caloTheme.palette.secondaryYellow500
								}}
							>
								{selectedDelivery.deliveredAt
									? `Delivered ${format('hh:mm a')(new Date(Date.parse(selectedDelivery.deliveredAt)))}`
									: 'Pending'}
							</Typography>
						)}
						<Stack display={'flex'} flexDirection={'row'} justifyContent={'space-around'}>
							<DeliveryPaymentIcons delivery={selectedDelivery} />
						</Stack>
					</Stack>
					<Stack>
						<DeliveryAction
							subscription={subscription}
							delivery={selectedDelivery}
							refetchDelivery={refetchDelivery}
							refetchAllDeliveries={refetchAllDeliveries}
						/>
					</Stack>
				</Box>

				<Box display={'flex'} flexDirection={'row'} width={'100%'}>
					<Stack width="33%" display={'flex'} flexDirection={'column'}>
						<Typography variant="caption" sx={{ ...styles.titleText }}>
							Driver
						</Typography>

						<Typography variant="h6" sx={{ textAlign: 'left', ...styles.text }}>
							{selectedDelivery.driver?.name || '----'}
						</Typography>
					</Stack>
					<Stack width="33%">
						<Typography variant="caption" sx={{ ...styles.titleText }}>
							Delivery Cost
						</Typography>
						<Typography variant="h6" sx={{ textAlign: 'left', ...styles.text }}>
							{selectedDelivery.cost || 0} {selectedDelivery.currency}
						</Typography>
					</Stack>
					<Stack width="33%">
						<Typography variant="caption" sx={{ ...styles.titleText }}>
							Paid Amount
						</Typography>
						<Typography variant="h6" sx={{ textAlign: 'left', ...styles.text }}>
							{selectedDelivery.paidAmount} {selectedDelivery.currency}
						</Typography>
					</Stack>

					{selectedDelivery.eta?.range && (
						<Stack width="33%">
							<Typography variant="caption" sx={{ ...styles.titleText }}>
								Delivery ETA
							</Typography>
							<Typography variant="h6" sx={{ textAlign: 'left', ...styles.text }}>
								{`${format('hh:mm a')(parseISO(selectedDelivery.eta?.range.gte))} - ${format('hh:mm a')(parseISO(selectedDelivery.eta?.range.lte))}`}
							</Typography>
						</Stack>
					)}

					{selectedAddressCustomTime && (
						<Stack width="33%">
							<Typography variant="caption" sx={{ ...styles.titleText }}>
								Custom Delivery ETA
							</Typography>
							<Typography variant="h6" sx={{ textAlign: 'left', ...styles.text }}>
								{`${convertTimeToRangeWithFormatting(selectedAddressCustomTime)[0]} - ${convertTimeToRangeWithFormatting(selectedAddressCustomTime)[1]}`}
							</Typography>
						</Stack>
					)}
				</Box>

				<Box display={'flex'} flexDirection={'column'} sx={{ mt: 4 }}>
					<DeliveriesMealTable
						meals={selectedDelivery.food as Food[]}
						refetchDelivery={refetchDelivery}
						selectedDelivery={selectedDelivery}
						subscription={subscription}
						// @ts-ignore
						addons={selectedDelivery.addons || []}
						gifted={(giftItems as any) || []}
					/>
				</Box>

				<Box
					display={'flex'}
					flexDirection={'row'}
					justifyContent={'space-between'}
					sx={{
						my: 4,
						[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
							width: 'full',
							flexDirection: 'column'
						}
					}}
				>
					<TextField
						select
						type="text"
						name="deliveryTime"
						label="Delivery Time"
						disabled={!PermissionService.deliveryCanBeEdited(selectedDelivery)}
						sx={{
							width: '50%',
							mx: 2,
							[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
								width: '91%',
								mb: 2
							}
						}}
						placeholder="Select Delivery Time"
						id="exact-subscription-deilveryTime"
						value={selectedDelivery.time}
						onChange={(data: any) => handleChangeTime(data.target.value)}
						InputProps={{ inputProps: { style: { borderRadius: 8, width: '100%' } }, style: { borderRadius: 8, width: '100%' } }}
					>
						{Object.values(DeliveryTime).map((deliveryTime) => (
							<MenuItem key={deliveryTime} value={deliveryTime}>
								{startCase(deliveryTime)}
							</MenuItem>
						))}
					</TextField>

					<TextField
						select
						type="text"
						name="Delivery Address"
						disabled={!PermissionService.deliveryCanBeEdited(selectedDelivery)}
						value={selectedAddress?.id}
						label="Delivery Address"
						sx={{
							width: '50%',
							mr: 2,
							[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
								width: '92%',
								mb: 2,
								mx: 2
							}
						}}
						placeholder="Select Delivery Time"
						id="exact-subscription-deilveryTime"
						onChange={(data: any) => handleChangeAddress(data.target.value)}
						InputProps={{ inputProps: { style: { borderRadius: 8 } }, style: { borderRadius: 8 } }}
					>
						{subscription.deliveryAddresses?.map((deliveryAddress) => (
							<MenuItem key={deliveryAddress.id} value={deliveryAddress.id}>
								{deliveryAddress.notes ? (
									<p>
										{' '}
										{AddressService.display(deliveryAddress)}
										<br />
										<Icon name={'notes'} className="cursor-pointer" size={5} /> <i>{deliveryAddress.notes}</i>
									</p>
								) : (
									AddressService.display(deliveryAddress)
								)}
							</MenuItem>
						))}
					</TextField>
				</Box>
			</Card>
		</>
	);
};
export default DeliveriesMeals;
