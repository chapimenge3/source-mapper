import { useState } from 'react';

import { compact, flatten, groupBy } from 'lodash';

import { Currency } from '@calo/types';
import { Button, TableCell, TableRow, Typography } from '@mui/material';

import { caloTheme } from 'assets/images/theme/calo';
import { Select2 } from 'components';
import FoodDietTypeTags from 'components/FoodDietTypeTags';
import { getIngredientsToAvoid } from 'lib/helpers';
import { Delivery, FoodWithPosition, MenuFood } from 'lib/interfaces';

interface FoodMenuPickerProps {
	food: FoodWithPosition;
	delivery: Delivery;
	currency: Currency;
	foodList: MenuFood;
	allMenuFood: MenuFood[];
	onPick: (food: MenuFood) => Promise<void>;
}

const FoodMenuPicker = ({ allMenuFood, food, onPick, foodList, currency, delivery }: FoodMenuPickerProps) => {
	const [selectedSize, setSelectedSize] = useState<any>({ size: foodList.size, foodId: foodList.id, foodName: foodList.name.en });
	const sameMealSize = flatten(Object.values(groupBy(allMenuFood, 'name.en')));

	const handleSizeChange = (size: string, allSizes: MenuFood[]) => {
		const selectedMealData = flatten(compact(allSizes.filter((r) => r.size === size)));
		setSelectedSize({ size: selectedMealData[0].size, foodId: selectedMealData[0].id, foodName: selectedMealData[0].name.en });
	};

	const handleFoodSize = (foodName: MenuFood) => {
		const allSizes = compact(sameMealSize.map((r) => r.name.en === foodName.name.en && r));
		return (
			<Select2
				value={selectedSize.size}
				name="size"
				className="w-20 mt-2 z-0"
				onChange={(data: any) => handleSizeChange(data.target.value, allSizes)}
				options={Object.values(allSizes).map((meal) => ({
					value: meal.size,
					label: meal.size
				}))}
			/>
		);
	};

	const handleSelectMeal = (foodList: any, selectedSize: any) => {
		if (selectedSize.foodName === foodList.name.en && selectedSize.size !== foodList.size) {
			onPick(selectedSize);
		} else {
			onPick(foodList);
		}
	};

	return (
		<TableRow key={foodList.id}>
			<TableCell>
				<Typography sx={{ fontFamily: caloTheme.typography.fontFamily, fontWeight: 600, fontSize: '16px', lineHeight: '23px' }}>
					{foodList.name.en}
				</Typography>
			</TableCell>
			<TableCell>
				{getIngredientsToAvoid(foodList, delivery).map((i: any) =>
					i.isAlergen ? <span className="text-red-500"> {i.name}, </span> : <span> {i.name}, </span>
				)}
			</TableCell>
			<TableCell>
				<Typography display={'flex'} flexDirection={'row'}>
					{foodList.tags?.map((r: any) => <FoodDietTypeTags key={r} tag={r} />)}
				</Typography>
			</TableCell>
			<TableCell>{handleFoodSize(foodList)}</TableCell>
			<TableCell>
				<Button
					variant="outlined"
					aria-label="show-meal-macros"
					sx={{
						mt: 2,
						height: '45px',
						fontWeight: 600,
						fontSize: '14px',
						boxShadow: 'none',
						lineHeight: '17px',
						borderRadius: '8px',
						fontFamily: caloTheme.typography.fontFamily,
						borderColor: caloTheme.palette.primary500,
						color:
							food.name.en === foodList.name.en && food.size === selectedSize.size
								? caloTheme.palette.white
								: caloTheme.palette.primary500,
						backgroundColor:
							food.name.en === foodList.name.en && food.size === selectedSize.size
								? caloTheme.palette.primary500
								: caloTheme.palette.white,
						'&:hover': {
							borderColor: caloTheme.palette.primary500,
							backgroundColor:
								food.name.en === foodList.name.en && food.size === selectedSize.size
									? caloTheme.palette.primary600
									: caloTheme.palette.primary100,
							color:
								food.name.en === foodList.name.en && food.size === selectedSize.size
									? caloTheme.palette.white
									: caloTheme.palette.primary500
						},
						[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
							justifyItems: 'center',
							margin: 'auto',
							marginTop: 4,
							width: 'auto'
						}
					}}
					onClick={() =>
						food.name.en === foodList.name.en && food.size === selectedSize.size ? null : handleSelectMeal(foodList, selectedSize)
					}
				>
					{food.name.en === foodList.name.en && food.size === selectedSize.size ? 'Selected' : 'Select'}
				</Button>
			</TableCell>
		</TableRow>
	);
};
export default FoodMenuPicker;
