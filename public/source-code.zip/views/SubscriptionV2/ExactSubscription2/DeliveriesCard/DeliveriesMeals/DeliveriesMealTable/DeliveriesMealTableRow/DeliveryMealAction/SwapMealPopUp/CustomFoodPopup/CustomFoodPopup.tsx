import { useEffect, useMemo, useState } from 'react';

import { flatten, sortBy, startCase } from 'lodash';

import { Permission } from '@calo/dashboard-types';
import { FoodComponentType, Localized } from '@calo/types';
import {
	Box,
	Button,
	MenuItem,
	Stack,
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableRow,
	TextField,
	Typography
} from '@mui/material';

import { caloTheme } from 'assets/images/theme/calo';
import { CaloLoader } from 'components';
import Input from 'components/Input';
import { useUserRoles } from 'lib/hooks';
import { MenuFood } from 'lib/interfaces';

interface FoodPickerProps {
	customFood: any;
	customFoodModalRef: any;
	isLoading: boolean;
	customMealAction: string;
	customFoodComponent: MenuFood[];
	handleUpdateCustomFood: (value: MenuFood, customName: Localized) => void;
}

const CustomFoodPopup = ({
	customFoodModalRef,
	customMealAction,
	isLoading,
	customFood,
	handleUpdateCustomFood,
	customFoodComponent
}: FoodPickerProps) => {
	const roles = useUserRoles();
	const [customFoodComponents, setCustomFoodComponents] = useState<any>({
		base: [],
		protein: [],
		topping: [],
		sauce: [],
		side: []
	});

	const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
	const [selectedCustomComp, setSelectedCustomComp] = useState<{ value: string; label: string; type: FoodComponentType }>();
	const [customFoodName, setCustomFoodName] = useState<Localized>({ en: '', ar: '' });

	const sidesComponents = customFoodComponent
		?.filter((f: any) => f.tags.includes(FoodComponentType.side))
		.map((r: any) => ({ value: r.id, label: typeof r.name === 'string' ? r.name : r.name.en }));

	const options = useMemo(
		() =>
			sortBy(sidesComponents, (f) => `${f.label}`).map((sides: any) => ({
				value: sides.value,
				label: sides.label
			})),
		[sidesComponents]
	);

	const handleCount = (type: FoodComponentType) => {
		if (type === FoodComponentType.side) {
			try {
				const sidesCount = customFoodComponents?.side.length;
				return sidesCount;
			} catch {
				return 0;
			}
		} else {
			let counts = 0;
			if (customFoodComponents[type][0]) {
				counts = customFoodComponents[type]?.length;
			}
			return counts;
		}
	};

	const handleRemoveSides = (sideId: any) => {
		const i = customFoodComponents.side.indexOf(sideId);
		customFoodComponents.side.splice(i, 1);
		setCustomFoodComponents({ ...customFoodComponents, side: customFoodComponents.side });
	};

	const handleSideComponent = (comp: any) => {
		const count = customFood?.components.find((r: any) => r.id === comp.value);
		for (let i = 1; i <= count.count; i++) {
			customFoodComponents['side'].push({ value: comp.value, label: comp.label });
		}
		return customFoodComponents['side'];
	};

	const getComponents = () => {
		const fC = customFoodComponent
			?.filter((cus: any) => customFood?.components?.find((r: any) => r.id === cus.id))
			.map((k: any) => ({ value: k.id, label: typeof k.name === 'string' ? k.name : k.name.en, tags: k.tags }));
		fC?.map((k: any) =>
			k.tags[0] === FoodComponentType.side
				? handleSideComponent(k)
				: customFoodComponents[k.tags[0]].push({ value: k.value, label: k.label })
		);
	};
	useEffect(() => {
		getComponents();
	}, [customFood]);

	useEffect(() => {
		if (customFood.name) {
			setCustomFoodName({ en: customFood.name.en, ar: customFood.name.en });
		}
		setIsSubmitting(false);
	}, []);

	const handleNameChange = (data: string) => {
		const customName = data;
		if (customName.length <= 32) {
			setCustomFoodName({ en: data, ar: data });
		}
	};

	useEffect(() => {
		if (selectedCustomComp && selectedCustomComp.value.length > 0) {
			if (selectedCustomComp?.type === FoodComponentType.side) {
				setCustomFoodComponents({
					...customFoodComponents,
					side: [
						...customFoodComponents.side,
						(customFoodComponents.side[handleCount(FoodComponentType.side) - 1] = {
							value: selectedCustomComp!.value,
							label: selectedCustomComp!.label
						})
					]
				});
			} else {
				setCustomFoodComponents({
					...customFoodComponents,
					[selectedCustomComp?.type]: [{ value: selectedCustomComp!.value, label: selectedCustomComp!.label }]
				});
			}
		}
	}, [selectedCustomComp]);

	return (
		<>
			{isLoading ? (
				<Stack>
					<CaloLoader />
				</Stack>
			) : (
				<>
					<Stack className="mb-4">
						<Input
							label="Meal Name"
							value={customFoodName.en}
							disabled={!roles.includes(Permission.UPDATE_DELIVERY_CUSTOM_FOOD)}
							onChange={(data: any) => handleNameChange(data.target.value)}
						/>
						{customFoodName.en.length >= 32 && (
							<span>
								<p className="text-sm text-red-300"> Maximum characters is 32</p>
							</span>
						)}
					</Stack>
					<Table
						sx={{
							mx: 2,
							width: '100%',
							marginY: '4px',
							minHeight: '12rem',
							[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
								flexDirection: 'column'
							}
						}}
					>
						<TableHead>
							<TableRow style={{ width: '100%' }}>
								<TableCell
									style={{ width: '13rem', fontFamily: caloTheme.typography.fontFamily, fontWeight: 600 }}
								>{`Base (${handleCount(FoodComponentType.base)}/1)`}</TableCell>
								<TableCell
									style={{ width: '13rem', fontFamily: caloTheme.typography.fontFamily, fontWeight: 600 }}
								>{`Protein (${handleCount(FoodComponentType.protein)}/1)`}</TableCell>
								<TableCell
									style={{ width: '13rem', fontFamily: caloTheme.typography.fontFamily, fontWeight: 600 }}
								>{`Sides (${handleCount(FoodComponentType.side)}/3)`}</TableCell>
								<TableCell
									style={{ width: '13rem', fontFamily: caloTheme.typography.fontFamily, fontWeight: 600 }}
								>{`Toppings (${handleCount(FoodComponentType.topping)}/1)`}</TableCell>
								<TableCell
									style={{ width: '13rem', fontFamily: caloTheme.typography.fontFamily, fontWeight: 600 }}
								>{`Sauce (${handleCount(FoodComponentType.sauce)}/1)`}</TableCell>
							</TableRow>
						</TableHead>
						<TableBody>
							<TableRow sx={{ border: 0, width: '100%' }}>
								{Object.values(FoodComponentType).map((type) => (
									<TableCell key={type}>
										{type === FoodComponentType.side
											? customFoodComponents[type]?.map(
													(r: any, index: number) =>
														customFoodComponents[type][index]?.label && (
															<Stack key={index}>
																<Typography
																	sx={{
																		my: 2,
																		borderRadius: '8px',
																		color: caloTheme.palette.primary500,
																		backgroundColor: caloTheme.palette.neutral100
																	}}
																>
																	<p className="px-2 font-bold">
																		{r.label}
																		{
																			<i
																				className="float-right mt-1 fas fa-times text-md ml-2  cursor-pointer"
																				onClick={() => handleRemoveSides(r)}
																			/>
																		}
																	</p>
																</Typography>
															</Stack>
														)
												)
											: customFoodComponents[type][0]?.label && (
													<Stack sx={{ display: 'flex', flexDirection: 'row' }}>
														<Stack
															className="border-1 my-2 bg-gray-100 text-green-400 text-sm rounded-lg"
															sx={{ color: caloTheme.palette.primary500 }}
														>
															<p className="px-2 font-bold">
																{customFoodComponents[type][0].label}
																{
																	<i
																		className="float-right mt-1 fas fa-times text-md cursor-pointer ml-2"
																		style={{ color: caloTheme.palette.primary500 }}
																		onClick={() => setCustomFoodComponents({ ...customFoodComponents, [type]: [] })}
																	/>
																}
															</p>
														</Stack>
													</Stack>
												)}
									</TableCell>
								))}
							</TableRow>
							<TableRow sx={{ border: 0 }}>
								{Object.values(FoodComponentType).map((type) => (
									<TableCell sx={{ border: 0 }} key={Math.random()}>
										{type !== FoodComponentType.side && customFoodComponents[type].length === 0 && (
											<TextField
												select
												placeholder="Select"
												className={'w-full'}
												id="select-component-customMeal"
												label={startCase(`${type}`)}
												value={customFoodComponents[type][0]?.value}
												InputProps={{ inputProps: { style: { borderRadius: 8, width: 'full' } }, style: { borderRadius: 8 } }}
											>
												{customFoodComponent
													?.filter((f: any) => f.tags.includes(type))
													.map((r: any) => ({
														label: typeof r.name === 'string' ? r.name : r.name.en,
														value: r.id
													}))
													.map((selected) => (
														<MenuItem
															key={selected.value}
															value={selected.value}
															onClick={() => setSelectedCustomComp({ value: selected.value, label: selected.label, type: type })}
														>
															{startCase(selected.label)}
														</MenuItem>
													))}
											</TextField>
										)}
										{type === FoodComponentType.side && handleCount(FoodComponentType.side) < 3 && (
											<TextField
												select
												id="select-component-customMeal"
												className={'w-full'}
												label={startCase(`${type} - ${handleCount(FoodComponentType.side) + 1}`)}
												InputProps={{ inputProps: { style: { borderRadius: 8, width: '100%' } }, style: { borderRadius: 8 } }}
											>
												{options.map((r: any, index) => (
													<MenuItem
														value={r.value}
														key={`${r.value}-${index}`}
														onClick={() =>
															setSelectedCustomComp({ label: r.label, value: r.value, type: FoodComponentType.side })
														}
													>
														{startCase(r.label)}
													</MenuItem>
												))}
											</TextField>
										)}
									</TableCell>
								))}
							</TableRow>
						</TableBody>
					</Table>
					<Box display={'flex'} flexDirection={'row'} justifyContent={'center'} textAlign={'center'} width={'full'}>
						<Button
							variant="text"
							aria-label="show-meal-macros"
							sx={{
								mr: 4,
								height: '45px',
								fontWeight: 600,
								fontSize: '14px',
								lineHeight: '17px',
								borderRadius: '8px',
								color: caloTheme.palette.neutral900,
								'&:hover': {
									backgroundColor: caloTheme.palette.neutral100,
									color: caloTheme.palette.neutral400
								},
								[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
									justifyItems: 'center',
									margin: 'auto',
									marginTop: 4,
									width: 'auto'
								}
							}}
							onClick={() => customFoodModalRef.current.close()}
						>
							Cancel
						</Button>
						<Button
							variant="contained"
							aria-label="show-meal-macros"
							disabled={
								isSubmitting ||
								customFoodName.en.length === 0 ||
								flatten(Object.values(customFoodComponents)).map((r: any) => ({ id: r.value })).length === 0
							}
							sx={{
								height: '45px',
								fontWeight: 600,
								fontSize: '14px',
								lineHeight: '17px',
								borderRadius: '8px',
								color: caloTheme.palette.white,
								backgroundColor: caloTheme.palette.primary500,
								'&:hover': {
									backgroundColor: caloTheme.palette.primary600,
									color: caloTheme.palette.white
								},
								[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
									justifyItems: 'center',
									margin: 'auto',
									marginTop: 4,
									width: 'auto'
								}
							}}
							onClick={() => {
								setIsSubmitting(true);
								handleUpdateCustomFood(customFoodComponents, customFoodName);
							}}
						>
							{customMealAction === 'create' ? 'Create Custom Meal' : 'Update Custom Meal'}
						</Button>
					</Box>
				</>
			)}
		</>
	);
};
export default CustomFoodPopup;
