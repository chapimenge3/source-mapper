import { useRef, useState } from 'react';

import { endOfWeek, getWeek, getYear } from 'date-fns/fp';
import { round, sumBy } from 'lodash-es';
import { QueryObserverResult, RefetchOptions, RefetchQueryFilters, useMutation, useQuery } from 'react-query';

import { AddonAddedAsType } from '@calo/dashboard-types';
import { MacrosService } from '@calo/services';
import { ActivityLevel, Brand, DietType, Food, FoodType, Subscription } from '@calo/types';
import {
	Box,
	Button,
	Stack,
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableRow,
	Typography,
	styled,
	tableCellClasses
} from '@mui/material';

import { addAddonFood, getRecordWithParams } from 'actions';
import mutation from 'actions/mutation';
import { caloTheme } from 'assets/images/theme/calo';
import { CaloLoader, ModalRef } from 'components';
import Popup from 'components/Popup';
import { useDocumentMedia } from 'hooks';
import { Delivery, Menu as FoodMenu, MenuFood } from 'lib/interfaces';
import queryClient from 'lib/queryClient';
import MenuFoodPicker from 'views/Deliveries/ExactDelivery/MenuTab/MenuFoodPicker';
import AddonsPickerPopup from '../DeliveryAction/AddonsPickerPopup';
import DeliveriesMealTableRow from './DeliveriesMealTableRow';
import DeliveriesMealTableRowMobile from './DeliveriesMealTableRowMobile';

interface DeliveriesMealTableProps {
	meals: Food[];
	addons: Food[];
	gifted: Food[];
	selectedDelivery: Delivery;
	subscription: Subscription;
	refetchDelivery: <TPageData>(
		options?: (RefetchOptions & RefetchQueryFilters<TPageData>) | undefined
	) => Promise<QueryObserverResult<unknown, unknown>>;
}

const DeliveriesMealTable = ({
	selectedDelivery,
	meals,
	gifted,
	addons,
	subscription,
	refetchDelivery
}: DeliveriesMealTableProps) => {
	const { isMobile, isTablet } = useDocumentMedia();
	const addonModalRef = useRef<ModalRef>();
	const { mutateAsync: addAddonMutation } = useMutation(addAddonFood);

	const [isGifted, setIsGifted] = useState<boolean>(false);
	const [addonType, setAddonType] = useState(FoodType.coffee);
	const [selectedAddon, setSelectedAddon] = useState<MenuFood | null>(null);
	const [selectedAddType, setSelectedAddType] = useState<AddonAddedAsType>(AddonAddedAsType.addon);

	const week = getWeek(new Date(selectedDelivery.day));
	const year = getYear(endOfWeek(new Date(selectedDelivery.day)));

	const { data, isLoading: MenuLoading } = useQuery(
		[
			'/menu',
			selectedDelivery.day,
			{
				brand: selectedDelivery.brand ? selectedDelivery.brand : Brand.CALO,
				kitchen: selectedDelivery.kitchen,
				userId: selectedDelivery.userId
			}
		],
		getRecordWithParams,
		{
			retry: false
		}
	);
	const menu = data as FoodMenu;

	const StyledTableCell = styled(TableCell)(() => ({
		[`&.${tableCellClasses.head}`]: {
			flexShrink: 0,
			border: 'none',
			fontWeight: 600,
			fontSize: '12px',
			lineHeight: '14px',
			variant: 'caption',
			color: caloTheme.palette.neutral900,
			fontFamily: caloTheme.typography.fontFamily
		},
		[`&.${tableCellClasses.body}`]: {
			flexShrink: 0,
			border: 'none',
			fontWeight: 600,
			fontSize: '12px',
			variant: 'caption',
			lineHeight: '14px',
			color: caloTheme.palette.neutral900,
			fontFamily: caloTheme.typography.fontFamily
		}
	}));

	const deliveryMacros =
		selectedDelivery.macros ||
		MacrosService.getMacrosBag(
			MacrosService.getCal(selectedDelivery.macrosData!),
			selectedDelivery.plan.dietType || DietType.balanced,
			selectedDelivery.macrosData?.weight ?? 0,
			selectedDelivery.macrosData?.activityLevel || ActivityLevel.level1
		);

	const handleAddAddonRequest = async (mealAdded: Food) => {
		if (!mealAdded) return;
		await addAddonMutation(
			{ foodType: addonType, foodId: mealAdded.id, id: selectedDelivery.id, isGifted: isGifted, addedAs: selectedAddType },
			{
				onSuccess: (data) => {
					const query = queryClient.getQueryData(['deliveries', selectedDelivery.id]) as any;
					const deliveryUpdated = { ...query, addons: data.addons, cost: data.cost };
					mutation(['deliveries', selectedDelivery.id], deliveryUpdated);
					setSelectedAddon(null);
					setIsGifted(false);
					addonModalRef.current?.close();
					refetchDelivery();
				}
			}
		);
	};

	return (
		<>
			{isTablet || isMobile ? (
				<Box overflow="auto" width="100%" sx={{ padding: 2 }}>
					{meals?.map((meal, index) => (
						<DeliveriesMealTableRowMobile
							key={meal.id}
							mealType={'meal'}
							delivery={selectedDelivery}
							refetchDelivery={refetchDelivery}
							subscription={subscription}
							meal={{ ...meal, positionIndex: index }}
						/>
					))}
					{addons?.map((meal, index) => (
						<DeliveriesMealTableRowMobile
							key={meal.id}
							mealType={'addon'}
							delivery={selectedDelivery}
							refetchDelivery={refetchDelivery}
							subscription={subscription}
							meal={{ ...meal, positionIndex: index }}
						/>
					))}
				</Box>
			) : (
				<Table
					sx={{
						marginY: '4px',
						minHeight: '120px',
						tableLayout: 'fixed',
						overflow: 'auto',
						width: '100%',
						mx: 2,
						[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
							flexDirection: 'column'
						}
					}}
				>
					<TableHead sx={{ backgroundColor: caloTheme.palette.neutral50, borderRadius: '8px' }}>
						<TableRow>
							<StyledTableCell sx={{ width: '17%' }}>Name</StyledTableCell>
							<StyledTableCell sx={{ width: '5%' }}></StyledTableCell>
							<StyledTableCell sx={{ width: '12%' }} style={{ textAlign: 'center' }}>
								Portion
							</StyledTableCell>
							<StyledTableCell sx={{ width: '16%' }} style={{ textAlign: 'center' }}>
								Type
							</StyledTableCell>
							<StyledTableCell sx={{ width: '13%' }}>Macros</StyledTableCell>
							<StyledTableCell sx={{ width: '10%' }}>Tags</StyledTableCell>
							<StyledTableCell sx={{ width: '12%' }}></StyledTableCell>
						</TableRow>
					</TableHead>
					<TableBody>
						{MenuLoading ? (
							<>
								<TableRow>
									<StyledTableCell colSpan={7} style={{ textAlign: 'center' }}>
										<CaloLoader />
									</StyledTableCell>
								</TableRow>
							</>
						) : meals.length === 0 && addons.length === 0 && gifted.length === 0 ? (
							<>
								<TableRow>
									<TableCell colSpan={7} style={{ width: '100%', textAlign: 'center' }}>
										<Button
											variant="contained"
											sx={{
												textAlign: 'center',
												mr: 2,
												height: '45px',
												fontWeight: 600,
												fontSize: '14px',
												lineHeight: '17px',
												borderRadius: '8px',
												boxShadow: 'none',
												textTransform: 'none',
												color: caloTheme.palette.white,
												backgroundColor: caloTheme.palette.primary500,
												'&:hover': {
													boxShadow: 'none',
													backgroundColor: caloTheme.palette.primary600,
													color: caloTheme.palette.white
												},
												[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
													justifyItems: 'center',
													margin: 'auto',
													marginTop: 4,
													width: 'auto'
												}
											}}
											onClick={() => {
												setSelectedAddType(AddonAddedAsType.meal);
												addonModalRef.current?.open();
											}}
										>
											Add Meal
										</Button>
										<Button
											variant="contained"
											sx={{
												textAlign: 'center',
												height: '45px',
												fontWeight: 600,
												fontSize: '14px',
												lineHeight: '17px',
												borderRadius: '8px',
												boxShadow: 'none',
												textTransform: 'none',
												color: caloTheme.palette.white,
												backgroundColor: caloTheme.palette.primary500,
												'&:hover': {
													boxShadow: 'none',
													backgroundColor: caloTheme.palette.primary600,
													color: caloTheme.palette.white
												},
												[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
													justifyItems: 'center',
													margin: 'auto',
													marginTop: 4,
													width: 'auto'
												}
											}}
											onClick={() => {
												setSelectedAddType(AddonAddedAsType.addon);
												addonModalRef.current?.open();
											}}
										>
											Add Addon
										</Button>
									</TableCell>
								</TableRow>
							</>
						) : (
							<>
								{meals?.map((meal, index) => (
									<DeliveriesMealTableRow
										subscription={subscription}
										menu={menu}
										key={meal.id}
										mealType={'meal'}
										delivery={selectedDelivery}
										refetchDelivery={refetchDelivery}
										meal={{ ...meal, positionIndex: index }}
									/>
								))}
								{addons?.map((meal, index) => (
									<DeliveriesMealTableRow
										subscription={subscription}
										menu={menu}
										key={meal.id}
										mealType={'addon'}
										refetchDelivery={refetchDelivery}
										delivery={selectedDelivery}
										meal={{ ...meal, positionIndex: index }}
									/>
								))}
								{gifted?.map((gifted, index) => (
									<DeliveriesMealTableRow
										subscription={subscription}
										menu={menu}
										key={gifted.id || ''}
										mealType={'giftItem'}
										refetchDelivery={refetchDelivery}
										delivery={selectedDelivery}
										meal={{ ...gifted, positionIndex: index }}
									/>
								))}
							</>
						)}
					</TableBody>
				</Table>
			)}

			<Box
				width={'auto'}
				display="flex"
				flexDirection={'row'}
				sx={{
					my: 2,
					mx: 3,
					[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
						flexDirection: 'column'
					}
				}}
			>
				<Typography
					variant="h3"
					sx={{
						fontFamily: caloTheme.typography.fontFamily,
						width: '140px',
						fontWeight: 700,
						fontSize: '18px',
						lineHeight: '21.6px',
						mr: 3
					}}
				>
					Total
				</Typography>

				<Stack display={'flex'} flexDirection={'row'} justifyContent={'space-between'} sx={{ width: '100%' }}>
					<Stack
						display="flex"
						flexDirection="row"
						sx={{
							fontFamily: caloTheme.typography.fontFamily,
							fontWeight: 400,
							mr: 3,
							fontSize: '16px',
							lineHeight: '19px'
						}}
					>
						Calories{' '}
						<Typography
							variant="subtitle2"
							sx={{
								mt: '-3px',
								ml: 1,
								fontFamily: caloTheme.typography.fontFamily,
								fontWeight: 600,
								fontSize: '20px',
								lineHeight: '24px'
							}}
						>
							{round(sumBy(selectedDelivery.food, (food) => food.macros?.cal || 0))} g
						</Typography>
					</Stack>
					<Stack
						display="flex"
						flexDirection="row"
						sx={{
							fontFamily: caloTheme.typography.fontFamily,
							fontWeight: 400,
							mr: 3,
							fontSize: '16px',
							lineHeight: '19px'
						}}
					>
						Protein{' '}
						<Typography
							variant="subtitle2"
							sx={{
								mt: '-3px',
								ml: 1,
								fontFamily: caloTheme.typography.fontFamily,
								fontWeight: 600,
								fontSize: '20px',
								lineHeight: '24px'
							}}
						>
							{round(sumBy(selectedDelivery.food, (food) => food.macros?.protein || 0))} g
						</Typography>
					</Stack>
					<Stack
						display="flex"
						flexDirection="row"
						sx={{
							fontFamily: caloTheme.typography.fontFamily,
							fontWeight: 400,
							mr: 3,
							fontSize: '16px',
							lineHeight: '19px'
						}}
					>
						Carbs{' '}
						<Typography
							variant="subtitle2"
							sx={{
								mt: '-3px',
								ml: 1,
								fontFamily: caloTheme.typography.fontFamily,
								fontWeight: 600,
								fontSize: '20px',
								lineHeight: '24px'
							}}
						>
							{round(sumBy(selectedDelivery.food, (food) => food.macros?.carbs || 0))} g
						</Typography>
					</Stack>
					<Stack
						display="flex"
						flexDirection="row"
						sx={{
							fontFamily: caloTheme.typography.fontFamily,
							fontWeight: 400,
							mr: 2,
							fontSize: '16px',
							lineHeight: '19px'
						}}
					>
						Fat{' '}
						<Typography
							variant="subtitle2"
							sx={{
								mt: '-3px',
								ml: 1,
								fontFamily: caloTheme.typography.fontFamily,
								fontWeight: 600,
								fontSize: '20px',
								lineHeight: '24px'
							}}
						>
							{round(sumBy(selectedDelivery.food, (food) => food.macros?.fat || 0))} g
						</Typography>
					</Stack>
				</Stack>
			</Box>

			<Box
				width={'auto'}
				display="flex"
				flexDirection={'row'}
				sx={{
					my: 2,
					mx: 3,
					[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
						flexDirection: 'column'
					}
				}}
			>
				<Typography
					variant="h3"
					sx={{
						fontFamily: caloTheme.typography.fontFamily,
						width: '140px',
						fontWeight: 700,
						fontSize: '18px',
						lineHeight: '21.6px',
						mr: 3
					}}
				>
					Target Macros
				</Typography>
				<Stack display={'flex'} flexDirection={'row'} justifyContent={'space-between'} sx={{ width: '100%' }}>
					<Stack
						display="flex"
						flexDirection="row"
						sx={{
							fontFamily: caloTheme.typography.fontFamily,
							fontWeight: 400,
							mr: 3,
							fontSize: '16px',
							lineHeight: '19px'
						}}
					>
						Calories{' '}
						<Typography
							variant="subtitle2"
							sx={{
								mt: '-3px',
								ml: 1,
								fontFamily: caloTheme.typography.fontFamily,
								fontWeight: 600,
								fontSize: '20px',
								lineHeight: '24px'
							}}
						>
							{deliveryMacros.cal} g
						</Typography>
					</Stack>
					<Stack
						display="flex"
						flexDirection="row"
						sx={{
							fontFamily: caloTheme.typography.fontFamily,
							fontWeight: 400,
							mr: 3,
							fontSize: '16px',
							lineHeight: '19px'
						}}
					>
						Protein{' '}
						<Typography
							variant="subtitle2"
							sx={{
								mt: '-3px',
								ml: 1,
								fontFamily: caloTheme.typography.fontFamily,
								fontWeight: 600,
								fontSize: '20px',
								lineHeight: '24px'
							}}
						>
							{deliveryMacros.protein.min} - {deliveryMacros.protein.max} g
						</Typography>
					</Stack>
					<Stack
						display="flex"
						flexDirection="row"
						sx={{
							fontFamily: caloTheme.typography.fontFamily,
							fontWeight: 400,
							mr: 3,
							fontSize: '16px',
							lineHeight: '19px'
						}}
					>
						Carbs{' '}
						<Typography
							variant="subtitle2"
							sx={{
								mt: '-3px',
								ml: 1,
								fontFamily: caloTheme.typography.fontFamily,
								fontWeight: 600,
								fontSize: '20px',
								lineHeight: '24px'
							}}
						>
							{deliveryMacros.carbs.min} - {deliveryMacros.carbs.max} g
						</Typography>
					</Stack>
					<Stack
						display="flex"
						flexDirection="row"
						sx={{
							fontFamily: caloTheme.typography.fontFamily,
							fontWeight: 400,
							mr: 3,
							fontSize: '16px',
							lineHeight: '19px'
						}}
					>
						Fat{' '}
						<Typography
							variant="subtitle2"
							sx={{
								mt: '-3px',
								ml: 1,
								fontFamily: caloTheme.typography.fontFamily,
								fontWeight: 600,
								fontSize: '20px',
								lineHeight: '24px'
							}}
						>
							{deliveryMacros.fat.min} - {deliveryMacros.fat.max}
						</Typography>
					</Stack>
				</Stack>
			</Box>

			<Popup
				ref={addonModalRef}
				maxWidth={'lg'}
				onClose={() => {
					addonModalRef.current?.close();
					setSelectedAddon(null);
				}}
			>
				<Box display={'flex'} flexDirection={'row'} justifyContent={'space-between'} sx={{ mb: 2 }}>
					<Stack>
						<Typography
							sx={{
								fontWeight: 600,
								fontSize: '19px',
								fontFamily: caloTheme.typography.fontFamily,
								textTransform: 'uppercase',
								mb: '-4px'
							}}
						>
							{selectedAddType === AddonAddedAsType.addon ? 'Add new addon' : 'Add new meal'}
						</Typography>
					</Stack>
				</Box>
				{selectedAddType === AddonAddedAsType.addon ? (
					<AddonsPickerPopup
						year={year}
						week={week}
						isGifted={isGifted}
						addonType={addonType}
						setIsGifted={setIsGifted}
						delivery={selectedDelivery}
						setAddonType={setAddonType}
						addonModalRef={addonModalRef}
						selectedAddon={selectedAddon}
						country={selectedDelivery.country}
						setSelectedAddon={setSelectedAddon}
						handleAddAddonRequest={(v) => handleAddAddonRequest(v)}
					/>
				) : (
					<MenuFoodPicker
						menu={menu}
						gifted={true}
						isGifted={isGifted}
						setIsGifted={setIsGifted}
						setMealType={setAddonType}
						delivery={selectedDelivery}
						menuModalRef={addonModalRef}
						refetchDelivery={refetchDelivery}
						deliveryBalance={selectedDelivery.balance}
						handleAddMealRequest={(v) => handleAddAddonRequest(v)}
					/>
				)}
			</Popup>
		</>
	);
};
export default DeliveriesMealTable;
