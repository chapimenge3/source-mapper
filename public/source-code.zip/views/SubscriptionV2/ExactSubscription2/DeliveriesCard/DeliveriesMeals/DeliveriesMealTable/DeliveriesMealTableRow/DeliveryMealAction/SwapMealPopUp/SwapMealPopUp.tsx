import { useEffect, useMemo, useState } from 'react';

import { parseISO } from 'date-fns';
import { isBefore } from 'date-fns/fp';
import { flatten, groupBy, intersection } from 'lodash-es';
import { useMutation, useQuery } from 'react-query';

import { Permission } from '@calo/dashboard-types';
import { Brand, DietType, FoodType, Kitchen, Localized } from '@calo/types';
import {
	Box,
	Button,
	Stack,
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableRow,
	Typography,
	styled,
	tableCellClasses
} from '@mui/material';

import { createCustomFood, getAddonSubscriptionMenu, getListWithParams, getRecordWithParams, updateCustomFood } from 'actions';
import mutation from 'actions/mutation';
import { caloTheme } from 'assets/images/theme/calo';
import { CaloLoader } from 'components';
import Popup from 'components/Popup';
import { useUserRoles } from 'lib/hooks';
import { Delivery, FoodWithPosition, Menu, MenuFood } from 'lib/interfaces';
import queryClient from 'lib/queryClient';
import CustomFoodPopup from './CustomFoodPopup';
import CustomMealPicker from './CustomMealPicker';
import FoodMenuPicker from './FoodMenuPicker';

interface SwapMealPopUpProps {
	delivery: Delivery;
	customFoodModalRef: any;
	selectedMeal: FoodWithPosition;
	handleReplace: (value: MenuFood) => Promise<void>;
	handleReplaceAddonSubscriptionFood: (value: MenuFood) => Promise<void>;
}

const SwapMealPopUp = ({
	customFoodModalRef,
	selectedMeal,
	delivery,
	handleReplace,
	handleReplaceAddonSubscriptionFood
}: SwapMealPopUpProps) => {
	const roles = useUserRoles();
	const [customFood, setCustomFood] = useState<any | null>();
	const [allMenuFood, setAllMenufood] = useState<MenuFood[]>();
	const [customMealAction, setCustomMealAction] = useState<string>('');
	const { mutateAsync: updateCustomFoodMutation } = useMutation(updateCustomFood);
	const { mutateAsync: createCustomFoodMutation } = useMutation(createCustomFood);

	const { data, isLoading: menuLoading } = useQuery(
		[
			'/menu',
			delivery.day,
			{
				brand: delivery.brand ? delivery.brand : Brand.CALO,
				kitchen: delivery.kitchen,
				userId: delivery.userId
			}
		],
		getRecordWithParams,
		{
			retry: false
		}
	);
	const menu = data as Menu;

	const menuFood = useMemo(() => {
		if (!selectedMeal) {
			return [];
		}

		let food = (menu?.food || []).filter((f) => intersection(f.type, selectedMeal.type).length > 0);

		if (isBefore(Date.now())(parseISO(delivery.day))) {
			food = food.filter((f) => (f.tags || []).includes(delivery.dietType || DietType.balanced));
		}
		setAllMenufood(food);

		return Object.values(groupBy(food, 'name.en')).map((r) => r[0]);
	}, [menu, delivery, selectedMeal]);

	const { data: customFoodCom, isLoading } = useQuery<any, Error, { data: any[] }>(
		[
			'food-components/custom-food',
			{
				filters: {
					kitchen: delivery.kitchen ? delivery.kitchen : Kitchen.BH1,
					brand: delivery.brand ? delivery.brand : Brand.CALO
				}
			}
		],
		getListWithParams,
		{
			enabled: roles.includes(Permission.VIEW_FOOD_COMPONENTS_CUSTOM_FOOD),
			onSuccess: (data) => {
				for (const row of data?.data || []) {
					queryClient.setQueryData(['food-components/custom-food', row.id], row);
				}
			}
		}
	);

	const customFoodComponent = customFoodCom as any;
	const isAddonSubscriptionFood = Boolean(selectedMeal?.addedAs && selectedMeal?.addedAs === 'addonSubscription');

	const { data: userCustomMeals, refetch } = useQuery<any, Error, { data: any[] }>(
		['food/custom', { subscriptionId: delivery.userId, deliveryId: delivery.id }],
		getListWithParams,
		{
			enabled: roles.includes(Permission.VIEW_FOOD_COMPONENTS_CUSTOM_FOOD)
		}
	);
	const userCustomMeals2 = useMemo(() => userCustomMeals?.data.map((customFood) => customFood), [userCustomMeals?.data]);

	const { data: addonSubscriptionData } = useQuery(
		[`addonSubscription/${delivery.kitchen}`, delivery.kitchen],
		() => getAddonSubscriptionMenu(delivery.kitchen || Kitchen.BH1),
		{ enabled: isAddonSubscriptionFood }
	);

	const shouldRenderAddonSubscriptionMenu =
		isAddonSubscriptionFood &&
		addonSubscriptionData &&
		addonSubscriptionData?.addonSubscriptionMenu &&
		addonSubscriptionData?.addonSubscriptionMenu?.length > 0;
	const filteredAddonSubscriptionMenu = shouldRenderAddonSubscriptionMenu
		? addonSubscriptionData?.addonSubscriptionMenu
				?.filter((data: any) => data?.addonCategory?.includes(selectedMeal?.belongsTo))
				?.filter((r: any) => r?.id !== selectedMeal?.id)
		: [];

	const handleUpdateCustomFood = async (x: any, customName: Localized) => {
		const customComponents = flatten(Object.values(x)).map((r: any) => ({ id: r.value }));
		await updateCustomFoodMutation(
			{
				deliveryId: delivery.id,
				foodId: customFood.id === 'food' ? customFood.sk : customFood.id,
				name: customName,
				components: customComponents.map((r) => r.id)
			},
			{
				onSuccess: (data) => {
					customFoodModalRef.current?.close();
					setCustomFood(null);
					refetch();
				}
			}
		);
	};

	const handleCreateCustomFood = async (components: any, customName: Localized) => {
		const customComponents = flatten(Object.values(components)).map((r: any) => ({ id: r.value }));
		await createCustomFoodMutation(
			{
				subscriptionId: delivery.userId,
				deliveryId: delivery.id,
				name: customName,
				foodComponentIds: customComponents.map((r) => r.id)
			},
			{
				onSuccess: (data) => {
					customFoodModalRef.current?.close();
					handleReplace(data);
					mutation(['food/custom', { subscriptionId: delivery.userId, deliveryId: delivery.id }], data);
					refetch();
				}
			}
		);
	};

	const handleCustomMeal = (componentData: any, customName: Localized) => {
		if (customMealAction === 'update') {
			handleUpdateCustomFood(componentData, customName);
		} else if (customMealAction === 'create') {
			handleCreateCustomFood(componentData, customName);
		}
	};

	useEffect(() => {
		if (customFood && customMealAction === 'update') {
			customFoodModalRef.current?.open();
		}
	}, [customFood]);

	const StyledTableCell = styled(TableCell)(() => ({
		[`&.${tableCellClasses.head}`]: {
			flexShrink: 0,
			border: 'none',
			fontWeight: 600,
			fontSize: '12px',
			lineHeight: '14px',
			variant: 'caption',
			backgroundColor: caloTheme.palette.neutral100,
			color: caloTheme.palette.neutral900,
			fontFamily: caloTheme.typography.fontFamily
		},
		[`&.${tableCellClasses.body}`]: {
			flexShrink: 0,
			border: 'none',
			fontWeight: 600,
			backgroundColor: caloTheme.palette.neutral100,
			fontSize: '12px',
			variant: 'caption',
			lineHeight: '14px',
			color: caloTheme.palette.neutral900,
			fontFamily: caloTheme.typography.fontFamily
		}
	}));

	return (
		<>
			<Box maxHeight={'22rem'} sx={{ overflowY: 'auto', overflowX: 'hidden' }}>
				{menuLoading ? (
					<CaloLoader />
				) : menuFood.length > 0 ? (
					<Table
						stickyHeader
						sx={{
							marginY: '4px',
							minHeight: '24rem',
							width: 'full',
							mx: 2,
							[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
								flexDirection: 'column'
							}
						}}
					>
						<TableHead>
							<TableRow>
								<StyledTableCell style={{ width: '30%' }}>Name</StyledTableCell>
								<StyledTableCell style={{ width: '30%' }}>Ingredients</StyledTableCell>
								<StyledTableCell style={{ width: '10%' }}>Tags</StyledTableCell>
								<StyledTableCell style={{ width: '10%' }}>Sizes</StyledTableCell>
								<StyledTableCell style={{ width: '10%' }}></StyledTableCell>
							</TableRow>
						</TableHead>
						<TableBody>
							{shouldRenderAddonSubscriptionMenu &&
								filteredAddonSubscriptionMenu?.map((r: any) => (
									<FoodMenuPicker
										key={r.id}
										foodList={r}
										onPick={handleReplaceAddonSubscriptionFood}
										food={selectedMeal!}
										currency={delivery.currency}
										delivery={delivery}
										allMenuFood={allMenuFood || []}
									/>
								))}
							{!isAddonSubscriptionFood &&
								menuFood.map((r) => (
									<FoodMenuPicker
										key={r.id}
										foodList={r}
										onPick={handleReplace}
										food={selectedMeal!}
										currency={delivery.currency}
										delivery={delivery}
										allMenuFood={allMenuFood || []}
									/>
								))}
						</TableBody>
					</Table>
				) : (
					<Typography display={'flex'} flexDirection={'row'} justifyContent={'center'} sx={{ my: 2 }}>
						No meals to swap with
					</Typography>
				)}
			</Box>

			{delivery.brand !== Brand.MEALO &&
				(selectedMeal?.type?.includes(FoodType.lunch) || selectedMeal?.type?.includes(FoodType.dinner)) &&
				!shouldRenderAddonSubscriptionMenu && (
					<Box sx={{ my: 2 }}>
						<Stack display="flex" flexDirection={'row'} justifyContent={'space-between'} sx={{ my: 2 }}>
							<Typography
								sx={{
									fontWeight: 600,
									textTransform: 'uppercase',
									fontSize: '19px',
									ml: 2,
									my: 'auto'
								}}
							>
								Custom Meals
							</Typography>
							{roles.includes(Permission.CREATE_USER_CUSTOM_FOOD) && (
								<Button
									variant="contained"
									aria-label="show-meal-macros"
									sx={{
										ml: '-16px',
										height: '45px',
										fontWeight: 600,
										fontSize: '14px',
										lineHeight: '17px',
										borderRadius: '8px',
										textTransform: 'none',
										color: caloTheme.palette.white,
										backgroundColor: caloTheme.palette.primary500,
										'&:hover': {
											backgroundColor: caloTheme.palette.primary600,
											color: caloTheme.palette.white
										},
										[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
											justifyItems: 'center',
											margin: 'auto',
											marginTop: 4,
											width: 'auto'
										}
									}}
									onClick={() => {
										setCustomMealAction('create');
										setCustomFood(null);
										customFoodModalRef.current?.open();
									}}
								>
									Create Custom Meal
								</Button>
							)}
						</Stack>
						<Box maxHeight={'16rem'} sx={{ overflowY: 'auto', overflowX: 'hidden', mb: 2 }}>
							{userCustomMeals2?.length === 0 ? (
								<p className="flex justify-center font-bold mt-4"> No custom meal available</p>
							) : isLoading ? (
								<CaloLoader />
							) : (
								<Table
									stickyHeader
									sx={{
										marginY: '4px',
										minHeight: '12rem',
										width: 'full',
										mx: 2,
										[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
											flexDirection: 'column'
										}
									}}
								>
									<TableHead sx={{ fontFamily: caloTheme.typography.fontFamily }}>
										<TableRow>
											<StyledTableCell style={{ width: '30%' }}>Meal</StyledTableCell>
											<StyledTableCell style={{ width: '50%' }}>Component</StyledTableCell>
											<StyledTableCell style={{ width: '10%' }}></StyledTableCell>
											<StyledTableCell style={{ width: '10%' }}></StyledTableCell>
										</TableRow>
									</TableHead>
									<TableBody>
										{!isLoading &&
											userCustomMeals2 &&
											userCustomMeals2.map((r: any) => (
												<CustomMealPicker
													key={r.id}
													delivery={delivery}
													customMeal={r}
													onPick={handleReplace}
													food={selectedMeal!}
													setCustomFood={(v) => setCustomFood(v)}
													setCustomMealAction={setCustomMealAction}
													customFoodComponent={customFoodComponent?.data}
												/>
											))}
									</TableBody>
								</Table>
							)}
						</Box>
						{roles.includes(Permission.VIEW_FOOD_COMPONENTS_CUSTOM_FOOD) && (
							<Popup
								ref={customFoodModalRef}
								onClose={() => {
									customFoodModalRef.current?.close();
									setCustomFood(null);
									setCustomMealAction('');
								}}
								maxWidth="xl"
								title={customMealAction === 'update' ? 'Update Custom Meal' : 'Create Custom Meal'}
							>
								<CustomFoodPopup
									isLoading={isLoading}
									customMealAction={customMealAction}
									customFoodModalRef={customFoodModalRef}
									customFood={customFood || []}
									handleUpdateCustomFood={handleCustomMeal}
									customFoodComponent={customFoodComponent?.data}
								/>
							</Popup>
						)}
					</Box>
				)}
		</>
	);
};
export default SwapMealPopUp;
