import { useEffect, useState } from 'react';

import cx from 'classnames';
import { capitalize, compact, flatten, groupBy, startCase, uniqBy } from 'lodash-es';
import { QueryObserverResult, RefetchOptions, RefetchQueryFilters, useMutation, useQuery } from 'react-query';

import { PermissionService } from '@calo/services';
import { Brand, FoodActionType, FoodType, Kitchen, Subscription } from '@calo/types';
import { Button, MenuItem, Select, TableCell, TableRow, Tooltip, Typography } from '@mui/material';
import { Stack } from '@mui/system';

import { getListWithParams, replaceFood } from 'actions';
import { caloTheme } from 'assets/images/theme/calo';
import { Icon } from 'components';
import FoodDietTypeTags from 'components/FoodDietTypeTags';
import { Delivery, FoodComponent, FoodWithPosition, Menu, MenuFood } from 'lib/interfaces';
import DeliveryMealAction from './DeliveryMealAction';

interface DeliveriesMealTableRowProps {
	menu: Menu;
	mealType: string;
	delivery: Delivery;
	meal: FoodWithPosition;
	subscription: Subscription;
	refetchDelivery: <TPageData>(
		options?: (RefetchOptions & RefetchQueryFilters<TPageData>) | undefined
	) => Promise<QueryObserverResult<unknown, unknown>>;
}
const DeliveriesMealTableRow = ({
	meal,
	mealType,
	delivery,
	subscription,
	refetchDelivery,
	menu
}: DeliveriesMealTableRowProps) => {
	const [isOpen, setIsOpen] = useState<boolean>(false);
	const [foodComponentsData, setFoodComponentsData] = useState<FoodComponent[]>([]);
	const [mealActionMsg, setMealActionMsg] = useState<string>();

	const [selectedSize, setSelectedSize] = useState<any>({ size: meal?.size, foodId: meal?.id, foodName: meal.name?.en });
	const { mutateAsync: replaceMutation } = useMutation(replaceFood);

	useQuery<any, Error, { data: FoodComponent[] }>(
		[
			'food-components',
			{
				limit: meal.components?.length,
				filters: {
					withChildComponents: false,
					ids: meal.components?.map((component) => component.id),
					country: delivery.country,
					brand: delivery.brand || Brand.CALO,
					kitchen: delivery.kitchen || Kitchen.BH1
				}
			}
		],
		getListWithParams,
		{
			suspense: false,
			keepPreviousData: true,
			enabled: !!meal.components && !!meal.components.length,
			onSuccess: (data) => {
				setFoodComponentsData([...foodComponentsData, ...(data.data || [])]);
			}
		}
	);

	const handleSizeChange = (size: string, allSizes: MenuFood[]) => {
		const selectedMealData = uniqBy(flatten(compact(allSizes.filter((r) => r.size === size))), 'id');
		setSelectedSize({ size: selectedMealData[0].size, foodId: selectedMealData[0].id, foodName: selectedMealData[0].name?.en });
		handleReplace(selectedMealData[0]);
	};

	const handleFoodSize = (foodName: MenuFood) => {
		const sameMealSize = flatten(Object.values(groupBy(menu?.food, 'name.en')));
		const allSizes = uniqBy(compact(sameMealSize.map((r) => r.name?.en === foodName.name?.en && r)), 'size');
		return (
			<Tooltip
				title={`${allSizes.length === 0 ? 'No Sizes' : allSizes.length <= 1 ? 'The only size for this meal is already Selected' : PermissionService.deliveryCanBeEdited(delivery) ? '' : 'Can not change size during lockup time'}`}
				placement="top"
				arrow
			>
				<Select
					value={selectedSize.size}
					name="size"
					style={{
						width: '100%'
					}}
					disabled={!(allSizes.length > 1) || !PermissionService.deliveryCanBeEdited(delivery)}
					onChange={(data: any) => handleSizeChange(data.target.value, allSizes)}
				>
					{(allSizes.length === 0 ? [{ size: foodName.size }] : Object.values(allSizes)).map((type) => (
						<MenuItem key={type.size} value={type.size}>
							{startCase(type.size)}
						</MenuItem>
					))}
				</Select>
			</Tooltip>
		);
	};

	const handleReplace = async (food: any) => {
		await replaceMutation(
			{
				id: delivery.id,
				sourceId: meal.id,
				targetId: food.size === 'C' ? (food.id === 'food' ? food.sk : food.id) : food.id || food.foodId,
				positionIndex: meal.positionIndex
			},
			{
				onSuccess: () => {
					refetchDelivery();
				}
			}
		);
	};

	useEffect(() => {
		if (meal.actions) {
			const removedAction = meal.actions
				.filter((action) => action.type === FoodActionType.remove)
				.flatMap((component) => component.componentId);
			const swappedAction = meal.actions
				.filter((action) => action.type === FoodActionType.swap)
				.flatMap((component) => component.componentId);

			if (removedAction && removedAction.length > 0 && !swappedAction) {
				setMealActionMsg(`Meal has some components removed from it`);
			} else if (removedAction.length > 0 || swappedAction) {
				setMealActionMsg(`Meal has some components changed from it`);
			} else {
				setMealActionMsg('');
			}
		}
	}, [meal]);

	return (
		<>
			<TableRow key={meal.id}>
				<TableCell
					sx={{
						fontWeight: 600,
						fontSize: '16px',
						fontHeight: '19px',
						variant: 'h2',
						fontFamily: caloTheme.typography.fontFamily,
						color: caloTheme.palette.neutral900,
						component: 'th',
						scope: 'row',
						display: 'table-cell',
						flexDirection: 'row'
					}}
				>
					{meal.name
						? mealType === 'giftItem'
							? '(Gift)'
							: meal.skipped && (
									<b
										className={cx('', {
											'text-cRed': meal.skipped
										})}
									>
										{' '}
										SKIPPED
									</b>
								)
						: 'Unkown meal'}{' '}
					{meal.name?.en}
				</TableCell>
				<TableCell>
					{meal.actions && meal.actions.length > 0 && (
						<Tooltip title={mealActionMsg} placement="top" arrow>
							<span>
								<Icon name="removeIcon" size={6} className="w-12" />
							</span>
						</Tooltip>
					)}
				</TableCell>

				<TableCell
					style={{ textAlign: 'center' }}
					sx={{
						fontWeight: 400,
						fontSize: '16px',
						fontHeight: '19px',
						variant: 'h2',
						fontFamily: caloTheme.typography.fontFamily,
						color: caloTheme.palette.neutral900,
						scope: 'row'
					}}
				>
					{mealType === 'meal' ? handleFoodSize(meal) : meal.size}
				</TableCell>

				<TableCell>
					{meal.type ? (
						<Typography
							variant="h1"
							sx={{
								ml: 2,
								borderRadius: '37px',
								textAlign: 'center',
								px: '6px',
								py: '8px',
								width: '80%',
								fontWeight: 600,
								background:
									meal.type?.includes(FoodType.dinner) || meal.type?.includes(FoodType.lunch)
										? caloTheme.palette.primary100
										: meal.type?.includes(FoodType.coffee) || meal.type?.includes(FoodType.juice)
											? caloTheme.palette.secondaryPurple100
											: meal.type?.includes(FoodType.breakfast)
												? caloTheme.palette.secondaryYellow100
												: caloTheme.palette.secondaryBlue100,

								color:
									meal.type?.includes(FoodType.dinner) || meal.type?.includes(FoodType.lunch)
										? caloTheme.palette.primary700
										: meal.type?.includes(FoodType.coffee) || meal.type?.includes(FoodType.juice)
											? caloTheme.palette.secondaryPurple800
											: meal.type?.includes(FoodType.breakfast)
												? caloTheme.palette.secondaryYellow800
												: caloTheme.palette.secondaryBlue700,
								fontSize: '14px',
								lineHeight: '17px',
								fontFamily: caloTheme.typography.fontFamily
							}}
						>
							{meal?.addedAs && meal?.addedAs === 'addonSubscription'
								? 'Add-on Subscription'
								: capitalize(meal.type?.join(' & '))}
						</Typography>
					) : (
						<Typography
							sx={{
								ml: 2,
								borderRadius: '37px',
								textAlign: 'center',
								px: '6px',
								py: '8px',
								width: '80%',
								fontWeight: 600,
								fontSize: '14px',
								lineHeight: '17px',
								fontFamily: caloTheme.typography.fontFamily
							}}
						>
							---
						</Typography>
					)}
				</TableCell>

				<TableCell>
					<Button
						variant="text"
						aria-label="show-meal-macros"
						sx={{
							ml: '-16px',
							height: '45px',
							fontWeight: 600,
							fontSize: '14px',
							lineHeight: '17px',
							borderRadius: '8px',
							textTransform: 'none',
							color: caloTheme.palette.primary500,
							backgroundColor: isOpen ? caloTheme.palette.primary100 : 'white',
							'&:hover': {
								backgroundColor: caloTheme.palette.primary100,
								color: caloTheme.palette.primary600
							},
							[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
								justifyItems: 'center',
								margin: 'auto',
								marginTop: 4,
								width: 'auto'
							}
						}}
						disabled={!meal.macros}
						onClick={() => setIsOpen(!isOpen)}
					>
						{isOpen ? 'Hide Macros' : 'Show Macros'}
					</Button>
				</TableCell>

				<TableCell>
					<Typography display="flex" flexDirection="row" className="tags capitalize">
						{meal.tags?.map((type, i) => <FoodDietTypeTags key={i} tag={type} blueBuerry />)}
					</Typography>
				</TableCell>

				<TableCell>
					<DeliveryMealAction
						subscription={subscription}
						meal={meal}
						mealType={mealType}
						delivery={delivery}
						refetchDelivery={refetchDelivery}
					/>
				</TableCell>
			</TableRow>
			{isOpen && (
				<TableRow>
					<TableCell
						colSpan={6}
						sx={{
							familyFont: caloTheme.typography.fontFamily,
							fontWeight: 600,
							fontSize: '16px',
							lineHeight: '19px'
						}}
					>
						<Stack display={'flex'} flexDirection="row" justifyContent={'space-start'}>
							{Object.entries(meal.macros).map(([mealMacrosKey, mealMacrosValue]) => (
								<Stack>
									<Typography
										variant="h6"
										sx={{
											color:
												mealMacrosKey === 'cal'
													? caloTheme.palette.primary500
													: mealMacrosKey === 'fat'
														? caloTheme.palette.secondaryYellow500
														: mealMacrosKey === 'carbs'
															? caloTheme.palette.secondaryPurple500
															: caloTheme.palette.secondaryBlue500,
											backgroundColor:
												mealMacrosKey === 'cal'
													? caloTheme.palette.primary100
													: mealMacrosKey === 'fat'
														? caloTheme.palette.secondaryYellow100
														: mealMacrosKey === 'carbs'
															? caloTheme.palette.secondaryPurple100
															: caloTheme.palette.secondaryBlue100,
											mr: 4,
											borderRadius: '8px',
											left: '12px',
											top: '8px',
											fontSize: '16px',
											lineHeight: '19px',
											fontFamily: 600,
											padding: '10px 16px 10px 18px'
										}}
									>
										{`${mealMacrosKey === 'cal' ? 'Calories' : capitalize(mealMacrosKey)}: ${mealMacrosValue} ${mealMacrosKey === 'cal' ? '' : 'g'}`}
									</Typography>
								</Stack>
							))}
						</Stack>
					</TableCell>
				</TableRow>
			)}
		</>
	);
};
export default DeliveriesMealTableRow;
