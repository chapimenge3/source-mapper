import { flatten } from 'lodash';

import { Permission } from '@calo/dashboard-types';
import { PermissionService } from '@calo/services';
import { Delivery } from '@calo/types';
import { Button, Stack, TableCell, TableRow, Typography } from '@mui/material';

import { caloTheme } from 'assets/images/theme/calo';
import { Icon } from 'components';
import { useUserRoles } from 'lib/hooks';
import { MenuFood } from 'lib/interfaces';

interface CustomMealPickerProps {
	food: MenuFood;
	customMeal: any;
	delivery: Delivery;
	onPick: (food: any) => void;
	setCustomFood: (value: any) => void;
	setCustomMealAction: (value: string) => void;
	customFoodComponent: any;
}

const CustomMealPicker = ({
	delivery,
	customFoodComponent,
	setCustomMealAction,
	food,
	onPick,
	customMeal,
	setCustomFood
}: CustomMealPickerProps) => {
	const roles = useUserRoles();

	const handleCustomMealComponents = (data: any) => {
		const customComponentData = data?.map((comp: any) => customFoodComponent?.filter((r: any) => comp.id === r.id));
		return (
			<span>
				{customComponentData
					? flatten(customComponentData).map(
							(comp: any, index) => `${comp?.name.en} ${index === customComponentData.length - 1 ? '' : ','}`
						)
					: ''}
			</span>
		);
	};

	return (
		<>
			<TableRow
				key={customMeal.id}
				sx={{
					borderRadius: '8px',
					width: 'full',
					zIndex: 10
				}}
			>
				<TableCell>
					{' '}
					<span>{customMeal.name.en}</span>
				</TableCell>
				<TableCell>{handleCustomMealComponents(customMeal.components)}</TableCell>
				<TableCell>
					{roles.includes(Permission.UPDATE_DELIVERY_CUSTOM_FOOD) && (
						<Stack display={'flex'} flexDirection={'row'}>
							<button
								onClick={() => {
									setCustomMealAction('update');
									setCustomFood(customMeal);
								}}
								className="has-tooltip-danger w-full"
								disabled={!PermissionService.deliveryCanBeEdited(delivery)}
								data-tooltip={
									PermissionService.deliveryCanBeEdited(delivery) ? undefined : 'You cannot update after the lock-up time'
								}
							>
								<Typography sx={{ width: 'full', color: caloTheme.palette.primary500 }}>
									<Icon name="editPen" size={5} className="cursor-pointer" />
								</Typography>
							</button>
						</Stack>
					)}
				</TableCell>
				<TableCell>
					<Button
						variant="contained"
						aria-label="select-customMeal"
						sx={{
							mr: 1,
							border: 1,
							height: '45px',
							fontWeight: 600,
							fontSize: '14px',
							boxShadow: 'none',
							lineHeight: '17px',
							borderRadius: '8px',
							borderColor: caloTheme.palette.primary500,
							color: food?.name.en === customMeal?.name.en ? caloTheme.palette.white : caloTheme.palette.primary500,
							cursor: food?.name.en === customMeal?.name.en ? 'not-allowed' : 'pointer',
							backgroundColor: food?.name.en === customMeal?.name.en ? caloTheme.palette.primary500 : caloTheme.palette.white,
							'&:hover': {
								boxShadow: 'none',
								backgroundColor:
									food?.name.en === customMeal?.name.en ? caloTheme.palette.primary500 : caloTheme.palette.primary100,
								color: food?.name.en === customMeal?.name.en ? caloTheme.palette.white : caloTheme.palette.primary500
							},
							[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
								justifyItems: 'center',
								margin: 'auto',
								marginTop: 4,
								width: 'auto'
							}
						}}
						onClick={() => (food?.name.en === customMeal?.name.en ? null : onPick(customMeal))}
					>
						{food?.name.en === customMeal?.name.en ? 'Selected' : 'Select'}
					</Button>
				</TableCell>
			</TableRow>
		</>
	);
};
export default CustomMealPicker;
