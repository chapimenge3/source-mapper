import cx from 'classnames';
import { capitalize } from 'lodash-es';
import { QueryObserverResult, RefetchOptions, RefetchQueryFilters } from 'react-query';

import { Subscription } from '@calo/types';
import { Box, Card, CardContent, CardHeader, Stack, Tooltip, Typography } from '@mui/material';

import { caloTheme } from 'assets/images/theme/calo';
import { Icon } from 'components';
import FoodDietTypeTags from 'components/FoodDietTypeTags';
import { Delivery, FoodWithPosition } from 'lib/interfaces';
import DeliveryMealAction from '../DeliveriesMealTableRow/DeliveryMealAction';

interface DeliveriesMealTableRowMobileProps {
	mealType: string;
	delivery: Delivery;
	meal: FoodWithPosition;
	subscription: Subscription;
	refetchDelivery: <TPageData>(
		options?: (RefetchOptions & RefetchQueryFilters<TPageData>) | undefined
	) => Promise<QueryObserverResult<unknown, unknown>>;
}

const DeliveriesMealTableRowMobile = ({
	meal,
	mealType,
	delivery,
	subscription,
	refetchDelivery
}: DeliveriesMealTableRowMobileProps) => {
	return (
		<Card key={meal.id} sx={{ width: 'full', mb: 3 }}>
			<CardHeader
				title={
					<Box display={'flex'} flexDirection={'row'} width={'full'} justifyContent="space-between">
						<Stack sx={{}}>
							<Typography
								display={'flex'}
								flexDirection={'row'}
								sx={{
									fontSize: '16px',
									fontWeight: 600,
									lineHeight: '19px',
									mt: 2
								}}
							>
								<Typography display={'flex'} flexDirection={'column'} sx={{ my: 'auto' }}>
									{meal.name
										? meal.skipped && (
												<b
													className={cx('', {
														'text-cRed': meal.skipped
													})}
												>
													{' '}
													SKIPPED
												</b>
											)
										: 'Unkown meal'}
								</Typography>
								{meal.name?.en}{' '}
								{meal.actions?.[0]?.componentId && meal.actions?.[0]?.componentId?.length > 0 && (
									<Tooltip title="This meal has some removed components" placement="top" arrow>
										<span>
											<Icon name="removeIcon" size={6} className="w-12" />
										</span>
									</Tooltip>
								)}
							</Typography>
						</Stack>
						<Stack>
							<Typography sx={{ fontWeight: 600, mt: '-8px' }}>
								<DeliveryMealAction
									subscription={subscription}
									meal={meal}
									mealType={mealType}
									delivery={delivery}
									refetchDelivery={refetchDelivery}
								/>
							</Typography>
						</Stack>
					</Box>
				}
			/>
			<CardContent>
				<>
					<Stack display={'flex'} gap={2}>
						{Object.entries(meal.macros).map(([mealMacrosKey, mealMacrosValue]) => (
							<Stack>
								<Typography
									variant="subtitle1"
									sx={{
										color:
											mealMacrosKey === 'cal'
												? caloTheme.palette.primary500
												: mealMacrosKey === 'fat'
													? caloTheme.palette.secondaryYellow500
													: mealMacrosKey === 'carbs'
														? caloTheme.palette.secondaryPurple500
														: caloTheme.palette.secondaryBlue500,
										backgroundColor:
											mealMacrosKey === 'cal'
												? caloTheme.palette.primary100
												: mealMacrosKey === 'fat'
													? caloTheme.palette.secondaryYellow100
													: mealMacrosKey === 'carbs'
														? caloTheme.palette.secondaryPurple100
														: caloTheme.palette.secondaryBlue100,
										borderRadius: '8px',
										left: '12px',
										top: '8px',
										padding: '10px 16px 10px 18px'
									}}
								>
									{`${mealMacrosKey === 'cal' ? 'Calories' : capitalize(mealMacrosKey)}: ${mealMacrosValue} ${mealMacrosKey === 'cal' ? '' : 'g'}`}
								</Typography>
							</Stack>
						))}
					</Stack>
					<Stack
						sx={{
							color: caloTheme.palette.neutral900,
							my: 1,
							width: 'full',
							display: 'flex',
							flexDirection: 'column',
							justifyContent: 'space-between'
						}}
					>
						<Stack
							sx={{
								fontWeight: 600,
								fontFamily: caloTheme.typography.fontFamily,
								color: caloTheme.palette.neutral900,
								my: 1,
								width: 'full',
								flexDirection: 'column',
								ml: 1
							}}
						>
							Type
							<Typography
								variant="h1"
								sx={{
									mt: 1,
									borderRadius: '37px',
									textAlign: 'center',
									width: 'full',
									p: '6px',
									background: caloTheme.palette.primary100,
									color: caloTheme.palette.primary700,
									fontWeight: 600,
									fontSize: '14px',
									lineHeight: '17px',
									fontFamily: caloTheme.typography.fontFamily
								}}
							>
								{capitalize(meal.type?.join(' & '))}
							</Typography>
						</Stack>
						<Stack
							sx={{
								fontWeight: 600,
								fontFamily: caloTheme.typography.fontFamily,
								color: caloTheme.palette.neutral900,
								my: 1,
								ml: 1,
								width: 'full',
								flexDirection: 'column'
							}}
						>
							Tags
							<Typography>
								<div className="tags capitalize">
									{meal.tags.map((type, i) => (
										<FoodDietTypeTags key={i} tag={type} blueBuerry />
									))}
								</div>
							</Typography>
						</Stack>
					</Stack>
				</>
			</CardContent>
		</Card>
	);
};
export default DeliveriesMealTableRowMobile;
