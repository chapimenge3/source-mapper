import { Fragment, useEffect, useRef, useState } from 'react';

import { QueryObserverResult, RefetchOptions, RefetchQueryFilters, useMutation, useQuery } from 'react-query';

import { Permission } from '@calo/dashboard-types';
import { PermissionService } from '@calo/services';
import {
	Brand,
	Country,
	Food,
	FoodActionType,
	FoodComponent,
	FoodComponentType,
	FoodDietType,
	FoodType,
	Kitchen,
	Subscription
} from '@calo/types';
import ArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import LoadingButton from '@mui/lab/LoadingButton';
import {
	Box,
	Button,
	CircularProgress,
	Grid,
	Menu,
	MenuItem,
	Stack,
	Table,
	TableBody,
	TableCell,
	TableRow,
	Typography
} from '@mui/material';

import {
	customizeMeal,
	deleteAddonMenu,
	deleteFoodMenu,
	getListWithParams,
	replaceAddonSubscriptionFood,
	replaceFood,
	skipMeal,
	unSkipMeal
} from 'actions';
import mutation from 'actions/mutation';
import { caloTheme } from 'assets/images/theme/calo';
import { ModalRef } from 'components';
import CustomizeMealCard from 'components/CustomizeMealPopup';
import FoodDietTypeTags from 'components/FoodDietTypeTags';
import Popup from 'components/Popup';
import { getIngredientsToAvoid } from 'lib/helpers';
import { useUserRoles } from 'lib/hooks';
import { Delivery, FoodWithPosition, MenuFood } from 'lib/interfaces';
import queryClient from 'lib/queryClient';
import SwapMealPopUp from './SwapMealPopUp';

interface DeliveryMealProps {
	delivery: Delivery;
	mealType: string;
	meal: FoodWithPosition;
	subscription: Subscription;
	refetchDelivery: <TPageData>(
		options?: (RefetchOptions & RefetchQueryFilters<TPageData>) | undefined
	) => Promise<QueryObserverResult<unknown, unknown>>;
}
const DeliveryMeal = ({ meal, mealType, delivery, subscription, refetchDelivery }: DeliveryMealProps) => {
	const roles = useUserRoles();
	const foodModalRef = useRef<ModalRef>();
	const confirmModalRef = useRef<ModalRef>();
	const customFoodModalRef = useRef<ModalRef>();
	const removeComponentsRef = useRef<ModalRef>();

	const [customFood, setCustomFood] = useState<any | null>();
	const [selected, setSelected] = useState<FoodWithPosition | null>();
	const [selectedDeleteFood, setSelectedDeleteFood] = useState<Food>();
	const [customizeMealLoading, setCustomizeMealLoading] = useState<boolean>(false);
	const [customFoodComponents, setCustomFoodComponents] = useState<FoodComponent[]>([]);
	const [allCustomFoodComponents, setAllCustomFoodComponents] = useState<FoodComponent[]>([]);

	const [selectedMealToRemoveComponents, setSelectedMealToRemoveComponents] = useState<Food>();
	const [selectedRemovedComponentIdList, setSelectedRemovedComponentIdList] = useState<string[]>([]);
	const [selectedSwappedComponent, setSelectedSwappedComponent] = useState<{ oldId: string; newId: string }[]>([]);
	const [selectedComponent, setSelectedComponent] = useState<FoodComponent | undefined>(undefined);
	const [caloKidsComponents, setCaloKidsComponents] = useState<FoodComponent[]>([]);

	const [deliveryActionMenuAnchorEl, setDeliveryActionMenuAnchorEl] = useState<null | HTMLElement>(null);
	const isExportMenuOpened = Boolean(deliveryActionMenuAnchorEl);
	const isAddonSubscriptionFood = Boolean(meal?.addedAs && meal?.addedAs === 'addonSubscription');

	const { mutateAsync: replaceMutation } = useMutation(replaceFood);
	const { mutateAsync: deleteFoodMutation } = useMutation(deleteFoodMenu);
	const { mutateAsync: skipMealMutation } = useMutation(skipMeal);
	const { mutateAsync: unSkipMealMutation } = useMutation(unSkipMeal);
	const { mutateAsync: deleteAddonMutation } = useMutation(deleteAddonMenu);
	const { mutateAsync: customizeMealMutation } = useMutation(customizeMeal);
	const { mutateAsync: replaceAddonSubscriptionFoodMutation } = useMutation(replaceAddonSubscriptionFood);

	useQuery<any, Error, { data: any[] }>(
		[
			'food-components/custom-food',
			{
				filters: {
					kitchen: delivery.kitchen || Kitchen.BH1,
					brand: delivery.brand || Brand.CALO
				}
			}
		],
		getListWithParams,
		{
			retry: false,
			enabled: roles.includes(Permission.VIEW_FOOD_COMPONENTS_CUSTOM_FOOD),
			onSuccess: (data) => {
				if (data.data) {
					setAllCustomFoodComponents([...data.data] || []);
					setCustomFoodComponents([...data.data] || []);
				}
			}
		}
	);

	useQuery<any, Error, { data: FoodComponent[] }>(
		[
			'food-components/custom-food',
			{
				filters: {
					country: delivery.country,
					brand: delivery.brand || Brand.CALO,
					kitchen: delivery.kitchen || Kitchen.BH1,
					foodType: FoodType.caloKids
				}
			}
		],
		getListWithParams,
		{
			suspense: false,
			keepPreviousData: true,
			enabled: meal.type?.includes(FoodType.caloKids),
			onSuccess: (data) => {
				if (data) {
					setCaloKidsComponents(data.data);
				}
			}
		}
	);

	useEffect(() => {
		const isPreBuilt = selectedMealToRemoveComponents?.tags.includes(FoodDietType.preBuiltCustom);
		if (isPreBuilt) {
			const modifiedComp = allCustomFoodComponents.filter((customComp) =>
				customComp.tags?.some((tag: any) => selectedComponent?.tags?.includes(tag))
			);
			setCustomFoodComponents(modifiedComp || []);
		} else {
			setCustomFoodComponents(
				allCustomFoodComponents.filter((customComp) => customComp.tags?.includes(FoodComponentType.sauce)) || []
			);
		}
	}, [selectedComponent, selectedMealToRemoveComponents]);

	const onSkip = async () => {
		if (meal.skipped) {
			await unSkipMealMutation(
				{ deliveryId: delivery.id, foodId: meal.id },
				{
					onSuccess: () => {
						refetchDelivery();
					}
				}
			);
		} else {
			await skipMealMutation(
				{ deliveryId: delivery.id, foodId: meal.id },
				{
					onSuccess: () => {
						refetchDelivery();
					}
				}
			);
		}
	};

	useEffect(() => {
		if (selected) {
			foodModalRef.current?.open();
		} else {
			foodModalRef.current?.close();
		}
	}, [selected, customFood]);

	const handleEditMeal = (item: FoodWithPosition) => {
		if (item.isCustom) {
			setCustomFood!(item);
			setSelected(item);
		} else {
			setSelected(item);
		}
	};

	const handleReplace = async (food: any) => {
		if (selected) {
			await replaceMutation(
				{
					id: delivery.id,
					sourceId: selected.id,
					targetId: food.size === 'C' ? (food.id === 'food' ? food.sk : food.id) : food.id || food.foodId,
					positionIndex: selected.positionIndex
				},
				{
					onSuccess: () => {
						foodModalRef.current?.close();
						refetchDelivery();
					}
				}
			);
		}
	};

	const handleReplaceAddonSubscription = async (food: any) => {
		if (selected) {
			await replaceAddonSubscriptionFoodMutation(
				{
					subscriptionId: subscription.id,
					deliveryId: delivery.id,
					sourceId: selected.id,
					targetId: food?.id
				},
				{
					onSuccess: () => {
						foodModalRef.current?.close();
						refetchDelivery();
					}
				}
			);
		}
	};

	const deleteMenuFood = async (food: MenuFood) => {
		await deleteFoodMutation(
			{
				id: delivery.id,
				foodId: food.id
			},
			{
				onSuccess: (data) => {
					const query = queryClient.getQueryData(['deliveries', delivery.id]) as any;
					const deliveryUpdated = { ...query, food: data.food, cost: data.cost };
					mutation(['deliveries', delivery.id], deliveryUpdated);
					confirmModalRef.current?.close();
					setSelectedDeleteFood(undefined);
					refetchDelivery();
				}
			}
		);
	};

	const deleteMenuAddon = async (addon: MenuFood) => {
		await deleteAddonMutation(
			{
				id: delivery.id,
				addonId: addon.id
			},
			{
				onSuccess: (data) => {
					const query = queryClient.getQueryData(['deliveries', delivery.id]) as any;
					const deliveryUpdated = { ...query, addons: data.addons, cost: data.cost };
					mutation(['deliveries', delivery.id], deliveryUpdated);
					confirmModalRef.current?.close();
					setSelectedDeleteFood(undefined);
					refetchDelivery();
				}
			}
		);
	};

	const handleCustomizeMeal = async (
		foodId: string,
		delId: string,
		removedIds: string[],
		swappedIds: { oldId: string; newId: string }[]
	) => {
		const actions = [
			{
				type: FoodActionType.remove,
				componentId: removedIds
			},
			{
				type: FoodActionType.swap,
				swappedComponents: swappedIds,
				componentId: swappedIds.map((swap) => swap.oldId)
			}
		];
		setCustomizeMealLoading(true);
		await customizeMealMutation(
			{
				foodId: foodId,
				deliveryId: delId,
				actions: actions.filter((action) => action.componentId.length !== 0)
			},
			{
				onSuccess: () => {
					refetchDelivery();
					removeComponentsRef.current?.close();
				},
				onError: () => {
					setCustomizeMealLoading(false);
				}
			}
		);
		setCustomizeMealLoading(false);
	};

	return (
		<>
			<Fragment>
				<Grid container direction="row" justifyContent="space-between" alignItems="center">
					<LoadingButton
						loading={false}
						id="delivery-action-button"
						aria-haspopup="true"
						disableElevation
						onClick={(event) => {
							!deliveryActionMenuAnchorEl && setDeliveryActionMenuAnchorEl(event.currentTarget);
						}}
						variant="outlined"
						aria-label="meal-actions"
						sx={{
							width: '124px',
							height: '45px',
							fontWeight: 600,
							fontSize: '14px',
							lineHeight: '17px',
							borderRadius: '8px',
							textTransform: 'none',
							color: caloTheme.palette.black,
							borderColor: caloTheme.palette.neutral900,
							'&:hover': {
								borderColor: caloTheme.palette.neutral900,
								backgroundColor: caloTheme.palette.neutral100,
								color: caloTheme.palette.black
							},
							[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
								justifyItems: 'center',
								margin: 'auto',
								marginTop: 1,
								width: 'auto'
							}
						}}
						endIcon={<ArrowDownIcon />}
						disabled={!meal.name || !roles.includes(Permission.UPDATE_SUBSCRIPTION) || mealType === 'giftItem'}
					>
						Action
					</LoadingButton>
					<Menu
						MenuListProps={{
							'aria-labelledby': 'export-button'
						}}
						anchorEl={deliveryActionMenuAnchorEl}
						open={isExportMenuOpened}
						onClose={() => setDeliveryActionMenuAnchorEl(null)}
					>
						{roles.includes(Permission.REPLACE_FOOD_DELIVERY_MENU) && !meal.skipped && (
							<MenuItem
								sx={{ fontWeight: 600, py: 1, mr: 2 }}
								disabled={isAddonSubscriptionFood ? false : mealType !== 'meal'}
								onClick={() => {
									handleEditMeal(meal);
									setDeliveryActionMenuAnchorEl(null);
								}}
							>
								<Box>Replace Meal</Box>
							</MenuItem>
						)}
						{roles.includes(Permission.DELETE_FOOD_DELIVERY_MENU) && !meal.skipped && (
							<MenuItem
								sx={{ fontWeight: 600, py: 1, mr: 2 }}
								onClick={() => {
									setSelectedDeleteFood(meal);
									confirmModalRef.current?.open();
									setDeliveryActionMenuAnchorEl(null);
								}}
								disabled={
									isAddonSubscriptionFood ? true : mealType === 'meal' ? !PermissionService.deliveryCanBeEdited(delivery) : false
								}
							>
								<Box>Delete Meal</Box>
							</MenuItem>
						)}
						{roles.includes(Permission.DELETE_FOOD_DELIVERY_MENU) && (
							<MenuItem
								onClick={() => {
									onSkip();
									setDeliveryActionMenuAnchorEl(null);
								}}
								sx={{ fontWeight: 600, py: 1, mr: 2 }}
								disabled={
									isAddonSubscriptionFood ? true : mealType === 'meal' ? !PermissionService.deliveryCanBeEdited(delivery) : false
								}
							>
								<Box>{meal.skipped ? 'Un-Skip Meal' : 'Skip Meal'}</Box>
							</MenuItem>
						)}
						{roles.includes(Permission.REMOVE_COMPONENT_FROM_DELIVERY_FOOD) && !meal.skipped && (
							<MenuItem
								sx={{ fontWeight: 600, py: 1, mr: 2 }}
								onClick={() => {
									setSelectedMealToRemoveComponents(meal);
									setSelectedSwappedComponent(
										meal.actions
											?.filter((action) => action.type === FoodActionType.swap)
											?.flatMap((action) => action.swappedComponents || []) ?? []
									);
									setSelectedRemovedComponentIdList(
										meal.actions
											?.filter((action) => action.type === FoodActionType.remove)
											?.flatMap((action) => action.componentId || []) ?? []
									);
									removeComponentsRef.current?.open();
									setDeliveryActionMenuAnchorEl(null);
								}}
								disabled={
									mealType === 'meal' &&
									[FoodType.lunch, FoodType.dinner, FoodType.breakfast, FoodType.caloKids].some((type) =>
										meal.type?.includes(type)
									)
										? !PermissionService.deliveryCanBeEdited(delivery)
										: true
								}
							>
								<Box>Edit Meal</Box>
							</MenuItem>
						)}
					</Menu>
				</Grid>

				<Popup ref={confirmModalRef} title={'Confirm Delete Meal'} onClose={() => confirmModalRef.current?.close()}>
					<Box>
						<Stack>
							<Typography
								display={'flex'}
								flexDirection={'row'}
								sx={{
									lineHeight: '17px',
									fontWeight: 600,
									fontSize: '14px',
									color: caloTheme.palette.neutral900
								}}
							>
								{selectedDeleteFood?.name.en}
							</Typography>
						</Stack>
						<Stack display={'felx'} flexDirection={'row'} justifyContent={'center'} sx={{ mt: 3 }}>
							<Button
								aria-label="addAddressButton"
								sx={{
									width: 'auto',
									height: '45px',
									mx: 2,
									lineHeight: '17px',
									fontWeight: 600,
									fontSize: '14px',
									borderRadius: '8px',
									color: caloTheme.palette.neutral600,
									'&:hover': {
										backgroundColor: caloTheme.palette.neutral100,
										borderColor: caloTheme.palette.neutral100
									}
								}}
								onClick={() => {
									confirmModalRef.current?.close();
									setSelectedDeleteFood(undefined);
								}}
							>
								Cancel
							</Button>
							<Button
								variant="contained"
								aria-label="confirm-remove-meal"
								sx={{
									width: 'auto',
									height: '45px',
									lineHeight: '17px',
									fontWeight: 600,
									fontSize: '14px',
									borderRadius: '8px',
									boxShadow: 'none',
									padding: '14px 20px 14px 20px',
									backgroundColor: caloTheme.palette.primary500,
									borderColor: caloTheme.palette.primary500,
									color: 'white',
									'&:hover': {
										color: 'white',
										backgroundColor: caloTheme.palette.primary600,
										borderColor: caloTheme.palette.primary600
									},
									[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
										marginTop: 2,
										width: '75%',
										mx: 1
									}
								}}
								onClick={() =>
									delivery!.addons?.find((addon) => addon.id === selectedDeleteFood!.id)
										? deleteMenuAddon(selectedDeleteFood!)
										: deleteMenuFood(selectedDeleteFood!)
								}
							>
								Confirm
							</Button>
						</Stack>
					</Box>
				</Popup>

				<Popup
					ref={foodModalRef}
					title={'Replace Meal'}
					subTitle={
						<Table
							stickyHeader
							sx={{
								mx: 2,
								marginY: '4px',
								[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
									flexDirection: 'column'
								}
							}}
						>
							<TableBody>
								<TableRow key={selected?.id}>
									<TableCell>{selected?.name?.en}</TableCell>
									<TableCell>
										{getIngredientsToAvoid(selected, delivery).map((i: any) =>
											i.isAlergen ? <span className="text-red-500"> {i.name}, </span> : <span> {i.name}, </span>
										)}
									</TableCell>
									<TableCell>
										<Stack display={'flex'} flexDirection={'row'}>
											{selected?.tags?.map((r: any) => <FoodDietTypeTags key={r} tag={r} />)}
										</Stack>
									</TableCell>
									<TableCell>{selected?.size}</TableCell>
									<TableCell></TableCell>
								</TableRow>
							</TableBody>
						</Table>
					}
					maxWidth={'lg'}
					onClose={() => {
						setSelected(null);
						setCustomFood(null);
						foodModalRef.current?.close();
					}}
				>
					<SwapMealPopUp
						key={selected?.id}
						delivery={delivery}
						selectedMeal={selected!}
						handleReplace={handleReplace}
						handleReplaceAddonSubscriptionFood={handleReplaceAddonSubscription}
						customFoodModalRef={customFoodModalRef}
					/>
				</Popup>

				<Popup
					fullWidth
					maxWidth="md"
					ref={removeComponentsRef}
					title={'Customize Meal'}
					onClose={() => removeComponentsRef.current?.close()}
				>
					<>
						<Stack sx={{ mt: '-16px' }}>
							<CustomizeMealCard
								key={meal.id}
								brand={delivery.brand || Brand.CALO}
								country={delivery.country || Country.BH}
								kitchen={delivery.kitchen || Kitchen.BH1}
								customFoodComponents={customFoodComponents}
								setCustomFoodComponents={setCustomFoodComponents}
								selectedSwappedComponent={selectedSwappedComponent}
								setSelectedSwappedComponent={setSelectedSwappedComponent}
								components={selectedMealToRemoveComponents?.components || []}
								selectedRemovedComponentIdList={selectedRemovedComponentIdList}
								setSelectedRemovedComponentIdList={setSelectedRemovedComponentIdList}
								isPreBuiltMeal={meal.tags?.includes(FoodDietType.preBuiltCustom)}
								selectedComponent={selectedComponent}
								setSelectedComponent={(comp) => setSelectedComponent(comp)}
								allCustomFoodComponents={allCustomFoodComponents}
								caloKidsComponents={meal.type?.includes(FoodType.caloKids) ? caloKidsComponents : []}
							/>
						</Stack>

						<Stack display={'felx'} flexDirection={'row'} justifyContent={'center'} sx={{ mt: 3 }}>
							<Button
								sx={{
									width: 'auto',
									height: '45px',
									mx: 2,
									lineHeight: '17px',
									fontWeight: 600,
									fontSize: '14px',
									borderRadius: '8px',
									color: caloTheme.palette.neutral600,
									'&:hover': {
										backgroundColor: caloTheme.palette.neutral100,
										borderColor: caloTheme.palette.neutral100
									}
								}}
								onClick={() => {
									removeComponentsRef.current?.close();
									setSelectedDeleteFood(undefined);
								}}
								disabled={customizeMealLoading}
							>
								Cancel
							</Button>
							<Button
								variant="contained"
								aria-label="confirm-remove-meal"
								sx={{
									width: 'auto',
									height: '45px',
									lineHeight: '17px',
									fontWeight: 600,
									fontSize: '14px',
									borderRadius: '8px',
									boxShadow: 'none',
									padding: '14px 20px 14px 20px',
									backgroundColor: caloTheme.palette.primary500,
									borderColor: caloTheme.palette.primary500,
									color: 'white',
									'&:hover': {
										color: 'white',
										backgroundColor: caloTheme.palette.primary600,
										borderColor: caloTheme.palette.primary600
									},
									[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
										marginTop: 2,
										width: '75%',
										mx: 1
									}
								}}
								disabled={customizeMealLoading}
								endIcon={customizeMealLoading ? <CircularProgress size={20} /> : null}
								onClick={() =>
									handleCustomizeMeal(
										selectedMealToRemoveComponents!.id,
										delivery.id,
										selectedRemovedComponentIdList,
										selectedSwappedComponent
									)
								}
							>
								Save
							</Button>
						</Stack>
					</>
				</Popup>
			</Fragment>
		</>
	);
};
export default DeliveryMeal;
