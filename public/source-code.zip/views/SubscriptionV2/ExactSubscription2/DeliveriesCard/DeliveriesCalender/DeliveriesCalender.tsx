import { useEffect, useState } from 'react';

import { format } from 'date-fns/fp';
import { startCase, uniq } from 'lodash-es';

import { Subscription } from '@calo/types';
import DateFnsAdapter from '@date-io/date-fns';
import { DeliveryDining, ExpandMore as ExpandMoreIcon } from '@mui/icons-material';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import {
	Button,
	Card,
	CardContent,
	CardHeader,
	Collapse,
	Grid,
	IconButton,
	List,
	ListItem,
	ListItemButton,
	ListItemIcon,
	ListItemText,
	Paper,
	Stack,
	TextField,
	Typography,
	styled
} from '@mui/material';
import Divider from '@mui/material/Divider';
import { LocalizationProvider, PickersDay, PickersDayProps, StaticDatePicker, pickersDayClasses } from '@mui/x-date-pickers';

import { getUnpaidDeliveries, postSyncRemainingDays } from 'actions';
import { caloTheme } from 'assets/images/theme/calo';
import { Routes } from 'lib/enums';
import { Delivery } from 'lib/interfaces';

interface DeliveriesCalenderProps {
	selectedDate: Date;
	allDeliveries: Delivery[];
	setSelectedDate: (value: Date) => void;
	subscription: Subscription & { remainingDays: number; expectedLastDeliveryDay: string; ratings: any[] };
	refetchSubscription: () => void;
}

interface getUnpaidDeliveriesProps {
	loading: boolean;
	loaded: boolean;
	count: number;
	totalUnpaidDeliveriesCost: number;
	unpaidDeliveries: {
		id: string;
		day: string;
	}[];
}

const Indexes = [
	{ status: 'delivered', color: caloTheme.palette.primary100 },
	{ status: 'pending', color: caloTheme.palette.secondaryYellow100 },
	{ status: 'skip', color: caloTheme.palette.neutral700 },
	{ status: 'cancel', color: caloTheme.palette.secondaryRed100 },
	{ status: 'paused', color: caloTheme.palette.secondaryPurple100 }
];

const DeliveriesCalender = ({
	allDeliveries,
	selectedDate,
	setSelectedDate,
	subscription,
	refetchSubscription
}: DeliveriesCalenderProps) => {
	const [isOpen, setIsOpen] = useState<boolean>(true);
	const [skipDeliveryDay, setSkipDeliveryDay] = useState<string[]>(uniq([]));
	const [deliveriedDeliveryDay, setDeliveriedDeliveryDay] = useState<string[]>(uniq([]));
	const [cancelledDeliveryDay, setCancelledDeliveryDay] = useState<string[]>(uniq([]));
	const [pendingDeliveryDay, setPendingDeliveryDay] = useState<string[]>(uniq([]));
	const [pausedDeliveryDay, setPausedDeliveryDay] = useState<string[]>(uniq([]));
	const [unpaidDeliveryCount, setUnpaidDeliveryCount] = useState<getUnpaidDeliveriesProps>({
		loading: false,
		loaded: false,
		count: 0,
		totalUnpaidDeliveriesCost: 0,
		unpaidDeliveries: []
	});
	const [syncDeliveriesState, setSyncDeliveriesState] = useState<boolean>(false);

	const fetchUnpaidDeliveries = async () => {
		setUnpaidDeliveryCount({
			...unpaidDeliveryCount,
			loading: true
		});

		try {
			const {
				count,
				totalUnpaidDeliveriesCost,
				unpaidDeliveries: unpaidDeliveriesItems
			} = await getUnpaidDeliveries(subscription.id);

			setUnpaidDeliveryCount({
				loading: false,
				loaded: true,
				count: count,
				totalUnpaidDeliveriesCost: totalUnpaidDeliveriesCost,
				unpaidDeliveries: unpaidDeliveriesItems
			});
		} catch {
			setUnpaidDeliveryCount({
				...unpaidDeliveryCount,
				loading: false
			});
		}
	};

	const syncRemainingDays = async () => {
		setSyncDeliveriesState(true);
		try {
			const { remainingDays } = await postSyncRemainingDays(subscription.id);
			refetchSubscription();
			subscription.remainingDays = remainingDays;
			setSyncDeliveriesState(false);
		} catch {
			setSyncDeliveriesState(false);
		}
	};

	const StyledCircle = styled(Paper)(({ color }) => ({
		width: 24,
		height: 24,
		borderRadius: '50%',
		backgroundColor: color
	}));

	useEffect(() => {
		allDeliveries.filter((del) => del.skipped && setSkipDeliveryDay((old) => [...old, del.day]));
		allDeliveries.filter((del) => del.deliveredAt && setDeliveriedDeliveryDay((old) => [...old, del.day]));
		allDeliveries.filter((del) => del.status === 'cancelled' && setCancelledDeliveryDay((old) => [...old, del.day]));
		allDeliveries.filter((del) => !del.deliveredAt && setPendingDeliveryDay((old) => [...old, del.day]));
		allDeliveries.filter((del) => del.status === 'paused' && setPausedDeliveryDay((old) => [...old, del.day]));
	}, [allDeliveries]);

	const handleRenderDay = (day: Date, DayComponentProps: PickersDayProps<Date>) => {
		const calenderDay = format('yyyy-MM-dd')(day);
		if (calenderDay === format('yyyy-MM-dd')(Date.now())) {
			return (
				<PickersDay
					style={{
						color: 'white',
						backgroundColor: caloTheme.palette.primary500,
						borderColor: DayComponentProps.tabIndex === 0 ? caloTheme.palette.primary900 : caloTheme.palette.primary500
					}}
					sx={{
						[`&&.${pickersDayClasses.selected}`]: {
							border: 1,
							color: 'white',
							backgroundColor: caloTheme.palette.primary500,
							borderColor: caloTheme.palette.primary900
						}
					}}
					{...DayComponentProps}
				/>
			);
		} else if (skipDeliveryDay.includes(calenderDay)) {
			return (
				<PickersDay
					sx={{
						backgroundColor: caloTheme.palette.neutral700,
						textDecoration: 'line-through',
						color: 'black',
						':hover': { color: 'black', backgroundColor: caloTheme.palette.neutral700 },
						[`&&.${pickersDayClasses.selected}`]: {
							border: 1,
							color: 'black',
							backgroundColor: caloTheme.palette.neutral700,
							borderColor: caloTheme.palette.primary600
						}
					}}
					{...DayComponentProps}
				/>
			);
		} else if (deliveriedDeliveryDay.includes(calenderDay)) {
			return (
				<PickersDay
					sx={{
						backgroundColor: caloTheme.palette.primary100,
						color: 'black',
						':hover': { color: 'black', backgroundColor: caloTheme.palette.primary100 },
						[`&&.${pickersDayClasses.selected}`]: {
							border: 1,
							color: 'black',
							backgroundColor: caloTheme.palette.primary100,
							borderColor: caloTheme.palette.primary600
						}
					}}
					{...DayComponentProps}
				/>
			);
		} else if (cancelledDeliveryDay.includes(calenderDay)) {
			return (
				<PickersDay
					sx={{
						backgroundColor: caloTheme.palette.secondaryRed100,
						color: 'red',
						':hover': { color: 'red', backgroundColor: caloTheme.palette.secondaryRed100 },
						[`&&.${pickersDayClasses.selected}`]: {
							border: 1,
							color: 'red',
							backgroundColor: caloTheme.palette.secondaryRed100,
							borderColor: caloTheme.palette.primary600
						}
					}}
					{...DayComponentProps}
				/>
			);
		} else if (pausedDeliveryDay.includes(calenderDay)) {
			return (
				<PickersDay
					sx={{
						backgroundColor: caloTheme.palette.secondaryPurple100,
						color: 'black',
						':hover': { color: 'black', backgroundColor: caloTheme.palette.secondaryPurple100 },
						[`&&.${pickersDayClasses.selected}`]: {
							border: 1,
							color: 'black',
							backgroundColor: caloTheme.palette.secondaryPurple100,
							borderColor: caloTheme.palette.primary600
						}
					}}
					{...DayComponentProps}
				/>
			);
		} else if (pendingDeliveryDay.includes(calenderDay)) {
			return (
				<PickersDay
					sx={{
						backgroundColor: caloTheme.palette.secondaryYellow100,
						color: 'black',
						':hover': { color: 'black', backgroundColor: caloTheme.palette.secondaryYellow100 },
						[`&&.${pickersDayClasses.selected}`]: {
							border: 1,
							color: 'black',
							backgroundColor: caloTheme.palette.secondaryYellow100,
							borderColor: caloTheme.palette.primary600
						}
					}}
					{...DayComponentProps}
				/>
			);
		} else {
			return (
				<PickersDay
					sx={{
						[`&&.${pickersDayClasses.selected}`]: {
							backgroundColor: '#0000',
							color: 'black',
							borderColor: caloTheme.palette.primary600,
							borderStyle: 'dashed',
							border: 'none'
						}
					}}
					{...DayComponentProps}
				/>
			);
		}
	};

	return (
		<>
			<Stack
				sx={{
					[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
						mx: 4,
						width: '100%',
						justifyContent: 'center'
					}
				}}
			>
				<LocalizationProvider dateAdapter={DateFnsAdapter}>
					<StaticDatePicker
						value={selectedDate}
						displayStaticWrapperAs="desktop"
						onChange={(newValue) => {
							setSelectedDate((newValue && newValue) || selectedDate);
						}}
						renderInput={(params) => <TextField {...params} />}
						dayOfWeekFormatter={(day) => `${day}`}
						renderDay={(day, _value, DayComponentProps) => handleRenderDay(day, DayComponentProps)}
					/>
				</LocalizationProvider>
			</Stack>

			<Card
				variant="outlined"
				sx={{
					ml: 4,
					borderWidth: 0,
					width: '100%',
					[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
						ml: 3,
						width: '94%',
						justifyContent: 'center'
					}
				}}
			>
				<CardHeader
					title="Index"
					action={
						<IconButton onClick={() => setIsOpen(!isOpen)} aria-label="show more">
							{isOpen ? <KeyboardArrowUpIcon /> : <ExpandMoreIcon />}
						</IconButton>
					}
				/>
				<CardContent>
					<Collapse in={isOpen}>
						<Grid container spacing={5}>
							{Indexes.map((index, idx) => (
								<Grid item key={idx}>
									<Grid container alignItems="center">
										<Grid item sx={{ display: 'flex', flexDirection: 'row' }}>
											<StyledCircle color={index.color} />
											<Typography
												variant={'caption'}
												sx={{
													ml: '6px',
													fontWeight: 600,
													fontSize: '14px',
													lineHeight: '24px',
													fontFamily: caloTheme.typography.fontFamily
												}}
											>
												{startCase(index.status)}
											</Typography>
										</Grid>
									</Grid>
								</Grid>
							))}
						</Grid>
					</Collapse>
				</CardContent>
			</Card>
			<Stack>
				<Stack
					sx={{
						width: '100%',
						height: '85px',
						marginX: 4,
						gridColumn: 4,
						marginY: 1,
						backgroundColor: caloTheme.palette.primary50,
						[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
							width: '90%',
							mx: 4
						}
					}}
				>
					<Typography
						variant={'caption'}
						sx={{
							m: 1,
							mb: 1,
							fontWeight: 600,
							fontSize: '12px',
							lineHeight: '14px',
							fontFamily: caloTheme.typography.fontFamily
						}}
					>
						Remaining Days
						<Button
							variant="outlined"
							aria-label="Sync Remaining Days"
							disabled={syncDeliveriesState}
							sx={{
								width: 'auto',
								height: '25px',
								lineHeight: '17px',
								fontWeight: 600,
								fontSize: '14px',
								borderRadius: '8px',
								padding: '14px 20px 14px 20px',
								marginLeft: '10px',
								color: caloTheme.palette.primary500,
								borderColor: caloTheme.palette.primary500,
								'&:hover': {
									color: caloTheme.palette.primary600,
									borderColor: caloTheme.palette.primary600
								}
							}}
							onClick={() => syncRemainingDays()}
						>
							{syncDeliveriesState ? 'Syncing...' : 'Sync'}
						</Button>
					</Typography>
					<Typography
						variant="h5"
						sx={{
							textAlign: 'center',
							fontWeight: 600,
							fontSize: '19px',
							lineHeight: '23px',
							fontFamily: caloTheme.typography.fontFamily,
							color: '#000000'
						}}
					>
						{`${subscription.remainingDays} days` || '----'}
					</Typography>
				</Stack>

				<Stack
					sx={{
						width: '100%',
						height: '85px',
						marginX: 4,
						marginY: 2,
						backgroundColor: caloTheme.palette.primary50,
						color: caloTheme.palette.neutral900,
						display: 'flex',
						direction: 'column',
						[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
							width: '90%',
							mx: 4
						}
					}}
				>
					<Typography
						variant={'caption'}
						sx={{
							m: 1,
							mb: 2,
							fontWeight: 600,
							fontSize: '12px',
							lineHeight: '14px',
							fontFamily: caloTheme.typography.fontFamily
						}}
					>
						Cost Per Day
					</Typography>
					<Typography
						variant="h5"
						sx={{
							textAlign: 'center',
							fontWeight: 600,
							fontSize: '19px',
							lineHeight: '23px',
							fontFamily: caloTheme.typography.fontFamily,
							color: '#000000'
						}}
					>
						{`${subscription.plan.pricePerDay} ${subscription.currency}` || '---'}
					</Typography>
				</Stack>
				<Stack
					sx={{
						width: '100%',
						marginX: 4,
						marginY: 2,
						backgroundColor: caloTheme.palette.primary50,
						color: caloTheme.palette.neutral900,
						display: 'flex',
						direction: 'column',
						[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
							width: '90%',
							mx: 4
						}
					}}
				>
					<Typography
						variant={'caption'}
						sx={{
							m: 1,
							mb: 2,
							fontWeight: 600,
							fontSize: '12px',
							lineHeight: '14px',
							fontFamily: caloTheme.typography.fontFamily
						}}
					>
						Unpaid Deliveries
					</Typography>
					<Typography
						variant="h5"
						sx={{
							textAlign: 'center',
							fontWeight: 600,
							fontSize: '19px',
							lineHeight: '23px',
							fontFamily: caloTheme.typography.fontFamily,
							color: '#000000'
						}}
					>
						{!unpaidDeliveryCount.loaded && (
							<Button
								variant="outlined"
								aria-label="Get Unpaid Deliveries"
								disabled={unpaidDeliveryCount.loading}
								sx={{
									width: 'auto',
									height: '25px',
									lineHeight: '17px',
									fontWeight: 600,
									fontSize: '14px',
									borderRadius: '8px',
									padding: '14px 20px 14px 20px',
									marginBottom: '20px',
									color: caloTheme.palette.primary500,
									borderColor: caloTheme.palette.primary500,
									'&:hover': {
										color: caloTheme.palette.primary600,
										borderColor: caloTheme.palette.primary600
									}
								}}
								onClick={() => fetchUnpaidDeliveries()}
							>
								{' '}
								{unpaidDeliveryCount.loading ? 'Fetching...' : 'Fetch'}{' '}
							</Button>
						)}

						{unpaidDeliveryCount.loaded && (
							<>
								<List>
									<ListItem disablePadding>
										<ListItemButton>
											<ListItemIcon>
												<ListItemText
													sx={{
														fontWeight: 'bold',
														fontFamily: caloTheme.typography.fontFamily
													}}
													primary={`${unpaidDeliveryCount.count}`}
												/>
											</ListItemIcon>
											<ListItemText primary={`${unpaidDeliveryCount.count > 1 ? 'Deliveries' : 'Delivery'}`} />
										</ListItemButton>
									</ListItem>
									<ListItem disablePadding>
										<ListItemButton>
											<ListItemIcon>
												<ListItemText
													sx={{
														fontWeight: 'bold',
														fontFamily: caloTheme.typography.fontFamily
													}}
													primary={`${unpaidDeliveryCount.totalUnpaidDeliveriesCost}`}
												/>
											</ListItemIcon>
											<ListItemText primary={`Total Cost`} />
										</ListItemButton>
									</ListItem>
								</List>
								{unpaidDeliveryCount.count > 9 && (
									<>
										<Divider />
										<List>
											{unpaidDeliveryCount.unpaidDeliveries.map((delivery) => (
												<ListItem disablePadding>
													<ListItemButton>
														<ListItemIcon>
															<DeliveryDining />
														</ListItemIcon>
														<ListItemText
															primary={delivery.day}
															onClick={() => window.open(Routes.delivery.replace(':id', delivery.id as string), '_blank')}
														/>
													</ListItemButton>
												</ListItem>
											))}
										</List>
									</>
								)}
							</>
						)}
					</Typography>
				</Stack>
			</Stack>
		</>
	);
};
export default DeliveriesCalender;
