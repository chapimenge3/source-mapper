import { useMemo, useState } from 'react';

import InfiniteScroll from 'react-infinite-scroll-component';
import { useInfiniteQuery } from 'react-query';
import { useHistory, useLocation } from 'react-router-dom';

import { Permission } from '@calo/dashboard-types';

import { Button, CaloLoader } from 'components';
import client from 'lib/client';
import { Routes } from 'lib/enums';
import { useUserRoles } from 'lib/hooks';
import { KDSUser } from 'lib/interfaces';
import Settings from '../Settings';
import KDSUserRow from './KDSUserRow';

const KDSUserList = () => {
	const history = useHistory();
	const roles = useUserRoles();
	const location = useLocation();
	const searchParams = new URLSearchParams(location.search);
	const [filters, setFilters] = useState({
		country: '',
		kitchen: '',
		...JSON.parse(searchParams.get('filters') || `{}`)
	});

	const { data, fetchNextPage, hasNextPage, isFetchingNextPage, isLoading } = useInfiniteQuery<{
		data: KDSUser[];
		meta: any;
	}>(
		['/kitchen-users', filters],
		async ({ pageParam, queryKey }) => {
			const { data } = await client.get(queryKey[0] as string, {
				params: {
					...(pageParam && {
						cursor: pageParam
					}),
					country: filters.country,
					kitchen: filters.kitchen
				}
			});
			return data;
		},
		{
			getNextPageParam: (data) => data.meta?.cursor,
			onSuccess: () => {
				searchParams.set('filters', JSON.stringify(filters));
				history.push({
					pathname: location.pathname,
					search: searchParams.toString()
				});
			}
		}
	);

	const users = useMemo(
		() =>
			(data?.pages || []).reduce<KDSUser[]>((res, r) => {
				res = [...res, ...(r.data || [])];
				return res;
			}, []),
		[data]
	);

	return (
		<InfiniteScroll
			dataLength={users.length || 0}
			next={fetchNextPage}
			hasMore={!!hasNextPage}
			loader={null}
			scrollableTarget="scrollable"
			className="max-h-auto"
		>
			<section className="section is-title-bar">
				<div className="level">
					<div className="level-left">
						<div className="level-item">
							<ul>
								<li>
									Kitchen Users / {filters.country} / {filters.kitchen || 'All'}
								</li>
							</ul>
						</div>
					</div>
					{roles.includes(Permission.CREATE_KDS_USER) && (
						<div className="level-right">
							<div className="level-item">
								<Button icon="fas fa-plus" onClick={() => history.push(Routes.newKdsUser)} className="mr-4" />
							</div>
						</div>
					)}
				</div>
			</section>
			<section>
				{users && users.length === 0 && !isLoading ? (
					<span className="absolute w-full text-3xl mt-4 text-center font-bold text-gray-400 ">NO KITCHEN USERS</span>
				) : isLoading ? (
					<div className="flex justify-center mt-8">
						<CaloLoader />
					</div>
				) : (
					<>
						<div className="card has-table has-table-container-upper-radius">
							<div className="card-content">
								<div className="table-container">
									<table className="table is-fullwidth is-striped is-hoverable is-sortable">
										<thead>
											<tr className="bg-black">
												<th style={{ color: 'white' }}>Name</th>
												<th style={{ color: 'white' }}>Phone Number</th>
												<th style={{ color: 'white' }}>Email</th>
												<th style={{ color: 'white' }}>Country</th>
												<th style={{ color: 'white' }}>Kitchen</th>
											</tr>
										</thead>
										<tbody>{users?.map((user: any) => <KDSUserRow key={`${user.id}`} user={user} />)}</tbody>
										{users.length >= 25 && (
											<tfoot>
												<th>Name</th>
												<th>Phone Number</th>
												<th>Email</th>
												<th>Country</th>
												<th>Kitchen</th>
											</tfoot>
										)}
									</table>
									{!!hasNextPage && (
										<div className="flex justify-center pb-3">
											<Button onClick={() => fetchNextPage()} content="Load more" loading={isFetchingNextPage} />
										</div>
									)}
								</div>
							</div>
						</div>
					</>
				)}
				<Settings onFilter={setFilters} filters={filters} />
			</section>
		</InfiniteScroll>
	);
};

export default KDSUserList;
