import { useFormik } from 'formik';
import parsePhoneNumberFromString from 'libphonenumber-js';

import { KDSCreateReq } from '@calo/dashboard-types';
import { Country, Kitchen } from '@calo/types';

import { generatePassword } from 'lib/helpers';

export default (onSubmit: (values: Omit<KDSCreateReq, 'id'>) => any) =>
	useFormik<Omit<KDSCreateReq, 'id'>>({
		initialValues: {
			name: '',
			phoneNumber: '',
			email: '',
			country: Country.BH,
			kitchen: [Kitchen.BH1],
			password: generatePassword()
		},
		validate: (values: Omit<KDSCreateReq, 'id'>) => {
			const errors: any = {};

			if (!values.name) {
				errors.name = true;
			}
			if (!values.country) {
				errors.country = true;
			}
			if (!values.kitchen) {
				errors.kitchen = true;
			}
			if (!values.email) {
				errors.email = true;
			}

			const phoneNumber = parsePhoneNumberFromString(values.phoneNumber!, values.country);
			if (!phoneNumber || (phoneNumber && !phoneNumber.isValid())) {
				errors.phoneNumber = true;
			}
			return errors;
		},
		onSubmit: async (values) => {
			try {
				await onSubmit(values);
			} catch (error) {
				console.log(error);
			}
		}
	});
