import { Kitchen, Macros } from '@calo/types';
import { IngredientType } from 'lib/interfaces';

export enum MeasurementUnitDisplay {
	g = 'gram',
	ml = 'ml',
	piece = 'piece'
}

export const calculateCalories = (macros: Macros | undefined) => {
	return macros ? macros.fat * 9 + macros?.carbs * 4 + macros?.protein * 4 : 0;
};

export const formatKitchenText = (kitchen: Kitchen | undefined) => {
	return kitchen ? kitchen.slice(0, 2) + ' ' + kitchen.slice(2) : '';
};

export enum FormOperation {
	create = 'CREATE',
	update = 'UPDATE'
}

export type IngredientOperationValues =
	| { operation: FormOperation.update; ingredient: IngredientType }
	| { operation: FormOperation.create };
