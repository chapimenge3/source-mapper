import { Box, Stack, Typography } from '@mui/material';
import { caloTheme } from 'assets/images/theme/calo';
import { useDocumentMedia } from 'hooks';
import { FoodFeedbackPages } from 'lib/enums';
import CustomScrollbars from 'react-custom-scrollbars';

interface FoodFeedbackTabProps {
	selectedPage: FoodFeedbackPages;
	setSelectedPage: (value: FoodFeedbackPages) => void;
}
const FoodFeedbackTab = ({ selectedPage, setSelectedPage }: FoodFeedbackTabProps) => {
	const { isMobile, isTablet } = useDocumentMedia();

	return (
		<CustomScrollbars
			style={{
				width: '100%',
				height: isMobile || isTablet ? '30vh' : '6vh'
			}}
			renderThumbVertical={({ style, ...props }) => (
				<div
					{...props}
					style={{
						...style,
						backgroundColor: '#888',
						borderRadius: '5px'
					}}
				/>
			)}
		>
			<Box
				sx={{
					display: 'flex',
					width: 'full',
					mb: '4px',
					borderBottom: 1,
					borderColor: caloTheme.palette.neutral50,
					justifyContent: 'space-between',
					mx: 2,
					[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
						flexDirection: 'column'
					}
				}}
			>
				{Object.values(FoodFeedbackPages).map((page) => (
					<Stack
						key={page}
						onClick={() => setSelectedPage(page)}
						sx={{
							height: '39px',
							width: '50%',
							left: '0px',
							flexShrink: 0,
							top: '10px',
							padding: '10px 24px 10px 24px',
							borderBottom: selectedPage === page ? 2 : 0,
							color: selectedPage === page ? caloTheme.palette.primary500 : caloTheme.palette.neutral600,
							[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
								width: 'auto'
							}
						}}
					>
						<Typography
							sx={{
								cursor: 'pointer',
								letterSpacing: -0.02,
								textAlign: 'center',
								fontSize: '16px',
								lineHeight: '19px',
								fontFamily: caloTheme.typography.fontFamily,
								fontWeight: 600,
								color: selectedPage === page ? caloTheme.palette.primary500 : caloTheme.palette.neutral600
							}}
						>
							{page}
						</Typography>
					</Stack>
				))}
			</Box>
		</CustomScrollbars>
	);
};
export default FoodFeedbackTab;
