import { useEffect, useState } from 'react';

import { differenceInDays, endOfWeek, parseISO, startOfWeek } from 'date-fns';
import { format } from 'date-fns/fp';
import { keyBy, orderBy, uniq, uniqBy } from 'lodash-es';
import { useMutation, useQuery } from 'react-query';
import { useParams } from 'react-router';
import { toast } from 'react-toastify';

import { BatchUpdateFoodListReq, BatchUpdateFoodReq, Permission } from '@calo/dashboard-types';
import { Stack } from '@mui/material';

import { batchUpdate, getList, getListWithParams } from 'actions';
import { Routes } from 'lib/enums';
import { addonsWithinThisWeek } from 'lib/helpers';
import history from 'lib/history';
import { useUserRoles } from 'lib/hooks';
import { Food, FoodComponent } from 'lib/interfaces';
import FoodForm from './FoodForm';

const ExactFood = () => {
	const roles = useUserRoles();
	const { slug } = useParams<{ slug: string }>();
	const { mutateAsync: updateMutation } = useMutation(batchUpdate);

	const [name, setName] = useState('');
	const [filterIds, setFilterIds] = useState<string[]>([]);
	const [exFoodCompIds, setExFoodCompIds] = useState<string[]>([]);

	const [foodCompIDS, setFoodCompIDS] = useState(exFoodCompIds);
	const [foodWithAllSizes, setFoodWithAllSizes] = useState<Food[]>([]);
	const [foodComponentListIDS, setFoodComponentListIDS] = useState<FoodComponent[]>([]);
	const [usedOnMenuButtonColor, setUsedOnMenuButtonColor] = useState<string[]>([]);

	const [selectedFood, setSelectedFood] = useState<Food | undefined>();

	const { data: foodList, refetch } = useQuery<string, Error, Food[]>([`food/slug/${slug}`], getList, {
		suspense: true
	});

	useEffect(() => {
		if (foodList) {
			setFoodWithAllSizes(foodList);
			setSelectedFood(foodList[0]);
		}
	}, [foodList]);

	useEffect(() => {
		if (selectedFood) {
			setExFoodCompIds(selectedFood.components?.map((r) => r.id) || []);
		}
	}, [selectedFood, foodList]);

	useQuery<any, Error, { data: FoodComponent[] }>(
		[
			'food-components',
			{
				limit: filterIds.length,
				filters: {
					withChildComponents: true,
					ids: filterIds,
					country: selectedFood?.country,
					brand: selectedFood?.brand,
					kitchen: selectedFood?.kitchen
				}
			}
		],
		getListWithParams,
		{
			suspense: false,
			keepPreviousData: true,
			enabled: !!filterIds.length && roles.includes(Permission.VIEW_FOOD_COMPONENTS),
			onSuccess: (data) => {
				setFoodComponentListIDS([...foodComponentListIDS, ...(data.data || [])]);
			}
		}
	);

	const { data: foodComponentList } = useQuery<any, Error, { data: FoodComponent[] }>(
		[
			'food-components',
			{
				limit: 50,
				filters: {
					withChildComponents: true,
					name,
					country: selectedFood?.country,
					brand: selectedFood?.brand,
					kitchen: selectedFood?.kitchen
				}
			}
		],
		getListWithParams,
		{
			enabled: !!name,
			keepPreviousData: true
		}
	);

	useEffect(() => {
		const newId: string[] = [];
		uniq([...foodCompIDS, ...exFoodCompIds])?.forEach((r) => {
			!filterIds.includes(r) && newId.push(r);
		});
		setFilterIds(newId);
	}, [foodCompIDS, exFoodCompIds]);

	useEffect(() => {
		foodList?.map(
			(meal) =>
				meal.usedOnMenu &&
				meal.usedOnMenu.map((data) => {
					if (data.type === 'mainMenu') {
						if (
							differenceInDays(parseISO(data.date!), parseISO(format('yyyy-MM-dd')(+Date.now()))) <= 1 &&
							differenceInDays(parseISO(data.date!), parseISO(format('yyyy-MM-dd')(+Date.now()))) >= 0
						) {
							return setUsedOnMenuButtonColor((old) => [...old, 'red']);
						} else {
							return setUsedOnMenuButtonColor((old) => [...old, 'yellow']);
						}
					} else {
						return addonsWithinThisWeek(data.week!)
							? setUsedOnMenuButtonColor((old) => [...old, 'red'])
							: setUsedOnMenuButtonColor((old) => [...old, 'addons']);
					}
				})
		);
	}, []);

	const filteredFoodUsed = uniqBy(
		orderBy(selectedFood?.usedOnMenu, ['date', 'week'], ['asc'])?.filter((r) => {
			if (r.date) {
				return differenceInDays(parseISO(r.date!), parseISO(format('yyyy-MM-dd')(+Date.now()))) >= 0;
			} else {
				const weekNumber = r.week!.toString().split('#');
				const date = new Date(+weekNumber[0], 0, 1 + +weekNumber[1] * 7);
				const weekDate = date;
				weekDate.setDate(date.getDate() - 7);
				return (
					differenceInDays(parseISO(format('yyyy-MM-dd')(startOfWeek(weekDate))), parseISO(format('yyyy-MM-dd')(+Date.now()))) &&
					differenceInDays(+endOfWeek(weekDate), Date.now()) >= 0
				);
			}
		}),
		'date'
	);

	const handleUpdateFood = async ({ averageRating, numberOfRatings, totalRating, country, brand, ...values }: Partial<Food>) => {
		//not common changes
		const { size, components, packagingIds, macros, withManualMacros, micronutrients, price, ...commonChanges } = values;
		if (selectedFood) {
			const updatedFoods: BatchUpdateFoodReq = [];

			updatedFoods.push(
				...foodWithAllSizes.map((food) => {
					if (food.id === selectedFood.id) {
						// update selected size with all changes
						return {
							id: selectedFood.id,
							size,
							components,
							packagingIds,
							macros,
							price,
							micronutrients,
							withManualMacros
						};
					} else {
						//update all other sizes with common changes and reorder/add/remove
						let comps = food.components;
						if (components) {
							const rightCompOrder = components.map((c) => c.id);
							const keyedComp = keyBy(food.components, 'id');
							comps = rightCompOrder.map((id) => {
								if (keyedComp[id]) return keyedComp[id];
								else
									return {
										id,
										quantity: 0
									};
							});
							return { id: food.id, components: comps };
						}
						return { id: food.id };
					}
				})
			);
			const req: BatchUpdateFoodListReq = {
				updatedCommonAttributes: commonChanges,
				updatedFoods
			};
			const response = await updateMutation(req, {
				onSuccess: () => {
					if (filteredFoodUsed.length > 0) {
						toast('The change will take effect on the next new generated menu', { type: 'success', autoClose: 2000 });
					}
					refetch(); //useMutation once the BE is fixed
				}
			});
			setFoodWithAllSizes(response);
			if (values.name?.en !== selectedFood.name.en) {
				history.push(Routes.foodSlug.replace(':slug', response[0].slug));
			}
		}
	};

	if (selectedFood) {
		return (
			<Stack direction="column" justifyContent="space-between" alignItems="stretch" spacing={0}>
				<FoodForm
					name={name}
					roles={roles}
					setName={setName}
					food={selectedFood}
					onSubmit={handleUpdateFood}
					selectedFood={selectedFood}
					setFoodCompIDS={setFoodCompIDS}
					setSelectedFood={setSelectedFood}
					foodWithAllSizes={foodWithAllSizes}
					filteredFoodUsed={filteredFoodUsed}
					allSizesFood={foodWithAllSizes || []}
					setFoodWithAllSizes={setFoodWithAllSizes}
					foodComponentListIDS={foodComponentListIDS}
					usedOnMenuButtonColor={usedOnMenuButtonColor}
					foodComponents={foodComponentList?.data || []}
				/>
			</Stack>
		);
	} else {
		return <div />;
	}
};

export default ExactFood;
