import { RefObject, useEffect, useMemo, useRef, useState } from 'react';

import { compact, flatten, keyBy, round, sumBy, upperFirst } from 'lodash-es';
import { useQuery } from 'react-query';

import { MeasurementUnit, MenuFoodComponent, UpdateFoodReq } from '@calo/dashboard-types';
import { Food as FoodType } from '@calo/types';
import { Stack } from '@mui/material';

import { getListWithParams } from 'actions';
import {
	Components,
	Information,
	Ingredients,
	MealInformation,
	NutritionalInformation,
	PackagingInformation,
	PortioningNotes
} from 'components/Sections';
import {
	calculateFoodPurchasingCost,
	getLastUpdatedPurchasingCostDate,
	makeFoodSlug,
	orderMealsBySize,
	quantitiesCupsCalculator
} from 'lib/helpers';
import { setComponentsOnFood } from 'lib/helpers/setComponentsOnFood';
import { BaseOmit, Food, FoodComponent } from 'lib/interfaces';
import StickyHeader from './StickyHeader';
import useFoodForm from './useFoodForm';

interface FoodFormProps {
	roles: any;
	food: Food;
	name: string;
	selectedFood: Food;
	allSizesFood: Food[];
	filteredFoodUsed: any;
	foodWithAllSizes: Food[];
	usedOnMenuButtonColor: string[];
	foodComponents: FoodComponent[];
	setName: (value: string) => void;
	foodComponentListIDS: FoodComponent[];
	setSelectedFood: (food: Food) => void;
	setFoodCompIDS: (value: string[]) => void;
	setFoodWithAllSizes: (food: Food[]) => void;
	onSubmit: (value: Omit<UpdateFoodReq, BaseOmit>) => Promise<void>;
}

const FoodForm = ({
	onSubmit,
	food,
	foodComponents,
	roles,
	setName,
	name,
	setFoodCompIDS,
	foodComponentListIDS,
	allSizesFood,
	filteredFoodUsed,
	selectedFood,
	foodWithAllSizes,
	usedOnMenuButtonColor,
	setSelectedFood,
	setFoodWithAllSizes
}: FoodFormProps) => {
	const [childFoodCompIDS, setChildFoodCompIDS] = useState<string[]>([]);
	const isDisabled = false;

	const { data: childFoodComponentListIDS, isLoading } = useQuery<any, Error, { data: FoodComponent[] }>(
		[
			'food-components',
			{
				limit: childFoodCompIDS.length,
				filters: {
					withChildComponents: true,
					ids: childFoodCompIDS,
					country: food.country,
					brand: food.brand,
					kitchen: food.kitchen
				}
			}
		],
		getListWithParams,
		{
			suspense: false,
			enabled: !!childFoodCompIDS,
			onSuccess: (data) => {
				setChildComponent(keyBy(data.data, 'id'));
			}
		}
	);

	const {
		handleSubmit,
		values,
		handleChange,
		handleBlur,
		isSubmitting,
		isValid,
		dirty,
		setFieldValue,
		setValues,
		resetForm,
		errors
	} = useFoodForm(food, onSubmit);

	const componentAPIIds = useMemo(() => keyBy(foodComponentListIDS!, 'id'), [foodComponentListIDS]);
	const componentAPI = useMemo(() => keyBy(foodComponents!, 'id'), [foodComponents!]);

	const [allComp, setAllcomp] = useState({ ...componentAPI, ...componentAPIIds });
	const [packageCost, setPackageCost] = useState(0);
	const [childComponent, setChildComponent] = useState<any>({});
	const [purchasingCostFood, setPurchasingCostFood] = useState<number>(0);

	const sectionRefs: RefObject<HTMLDivElement>[] = [
		useRef<HTMLDivElement>(null),
		useRef<HTMLDivElement>(null),
		useRef<HTMLDivElement>(null),
		useRef<HTMLDivElement>(null),
		useRef<HTMLDivElement>(null),
		useRef<HTMLDivElement>(null)
	];

	useEffect(() => {
		setAllcomp({ ...componentAPI, ...componentAPIIds });
		handlePurchasingFoodCost();
	}, [componentAPIIds, componentAPI]);

	useEffect(() => {
		setChildFoodCompIDS(compact(flatten(values.components?.map((r) => allComponents[r.id]?.childComponents?.map((r) => r.id)))));
		handlePurchasingFoodCost();
	}, [componentAPIIds, componentAPI, childComponent, allComp, componentAPI, componentAPIIds, childFoodComponentListIDS]);

	useEffect(() => resetForm, [food]);

	const allComponents = useMemo(() => allComp, [allComp]);

	useEffect(() => {
		if (
			((childFoodComponentListIDS && childFoodComponentListIDS?.data.length > 0) ||
				childComponent?.length > 0 ||
				childFoodCompIDS?.length > 0) &&
			values.components?.length !== 0
		) {
			const childCompIng = compact(
				flatten(
					values.components?.map(
						(row) =>
							allComponents &&
							allComponents[row.id]?.childComponents?.map(
								(r) =>
									childComponent &&
									childComponent[r.id]?.ingredients?.map((r: any) => ({
										id: r.id,
										category: r.category,
										name: r.name,
										slug: r.slug
									}))
							)
					)
				)
			);
			const ingredComponent = compact(
				flatten(
					values.components?.map((row) =>
						allComponents[row.id]?.ingredients?.map((r: any) => ({
							id: r.id,
							category: r.category,
							name: r.name,
							slug: r.slug
						}))
					)
				)
			);
			setValues({
				...values,
				ingredients: compact([...flatten(childCompIng), ...ingredComponent])
			});
		}
		handlePurchasingFoodCost();
	}, [childFoodComponentListIDS, childFoodCompIDS, childComponent]);

	const getFoodComponentAmount = (fc: MenuFoodComponent) => {
		const component = allComponents[fc.id];
		const componentWeight =
			component?.measurementUnit === MeasurementUnit.cup
				? quantitiesCupsCalculator([fc.quantity], component?.cups!)
				: round((component?.weight || 1) * fc.quantity, 6);

		return componentWeight;
	};

	const handleComponentsChange = async (rows: MenuFoodComponent[]) => {
		rows.map((r, index) => isNaN(r.quantity) && rows.splice(index, 1, { id: r.id, quantity: 0 }));
		setFoodCompIDS(rows.map((r) => r.id));
		setChildFoodCompIDS(compact(flatten(rows.map((r) => allComponents[r.id]?.childComponents?.map((r) => r.id)))));
		const ingredComponent = compact(
			flatten(
				rows.map((row) =>
					allComponents[row.id]?.ingredients?.map((r: any) => ({
						id: r.id,
						category: r.category,
						name: r.name,
						slug: r.slug
					}))
				)
			)
		);
		setValues({
			...values,
			components: rows,
			macros: {
				cal: values.withManualMacros
					? values.macros?.cal || 0
					: Math.round(sumBy(rows, (fc) => allComponents[fc.id]?.macros.cal * getFoodComponentAmount(fc))),
				protein: values.withManualMacros
					? values.macros?.protein || 0
					: Math.round(sumBy(rows, (fc) => allComponents[fc.id]?.macros.protein * getFoodComponentAmount(fc))),
				carbs: values.withManualMacros
					? values.macros?.carbs || 0
					: Math.round(sumBy(rows, (fc) => allComponents[fc.id]?.macros.carbs * getFoodComponentAmount(fc))),
				fat: values.withManualMacros
					? values.macros?.fat || 0
					: Math.round(sumBy(rows, (fc) => allComponents[fc.id]?.macros.fat * getFoodComponentAmount(fc))),
				fiber: values.withManualMacros
					? values.macros?.fiber || 0
					: Math.round(sumBy(rows, (fc) => (allComponents[fc.id]?.macros.fiber || 0) * getFoodComponentAmount(fc)) || 0)
			},
			micronutrients: {
				addedSugar: values.withManualMacros
					? values.micronutrients?.addedSugar
					: Math.round(sumBy(rows, (fc) => (allComponents[fc.id]?.micronutrients?.addedSugar || 0) * getFoodComponentAmount(fc))),
				cholesterol: values.withManualMacros
					? values.micronutrients?.cholesterol
					: Math.round(
							sumBy(rows, (fc) => (allComponents[fc.id]?.micronutrients?.cholesterol || 0) * getFoodComponentAmount(fc))
						),
				saturatedFats: values.withManualMacros
					? values.micronutrients?.saturatedFats
					: Math.round(
							sumBy(rows, (fc) => (allComponents[fc.id]?.micronutrients?.saturatedFats || 0) * getFoodComponentAmount(fc))
						),
				sodium: values.withManualMacros
					? values.micronutrients?.sodium
					: Math.round(sumBy(rows, (fc) => (allComponents[fc.id]?.micronutrients?.sodium || 0) * getFoodComponentAmount(fc))),
				totalSugar: values.withManualMacros
					? values.micronutrients?.totalSugar
					: Math.round(sumBy(rows, (fc) => (allComponents[fc.id]?.micronutrients?.totalSugar || 0) * getFoodComponentAmount(fc))),
				transFats: values.withManualMacros
					? values.micronutrients?.transFats
					: Math.round(sumBy(rows, (fc) => (allComponents[fc.id]?.micronutrients?.transFats || 0) * getFoodComponentAmount(fc)))
			},
			ingredients: compact(flatten(ingredComponent))
		});
		handlePurchasingFoodCost();
	};

	const displayMessageForMacrosLimits = (macrosProp: 'carbs' | 'cal' | 'protein' | 'fat') => {
		const defaultSizes = ['XS', 'S', 'M', 'L', 'XL'];
		const existingSizes = orderMealsBySize(allSizesFood).map((food) => food.size);
		if (defaultSizes.includes(food.size) && food.macros[macrosProp] && values.macros && values.macros[macrosProp]) {
			const index = defaultSizes.indexOf(food.size);
			const existingSizeIndex = existingSizes.indexOf(food.size);
			if (index === -1) return '';
			const hightLimit = allSizesFood.find((food) => food.size === existingSizes[existingSizeIndex + 1])?.macros[macrosProp];
			const lowLimit = allSizesFood.find((food) => food.size === existingSizes[existingSizeIndex - 1])?.macros[macrosProp];
			if (lowLimit && lowLimit > values.macros[macrosProp])
				return `${upperFirst(macrosProp)} amount is less than on a smaller meal`;
			if (hightLimit && hightLimit < values.macros[macrosProp])
				return `${upperFirst(macrosProp)} amount is more than on a larger meal`;
			return '';
		}
		return '';
	};

	const getTotalCost = () => {
		const componentCost = values.components?.map(
			(r) => (foodComponentListIDS.find((k) => k.id === r.id)?.cost || 0) * r.quantity
		);
		const cC = round(
			sumBy(componentCost, (fk) => fk || 0),
			3
		);
		return (packageCost + cC).toFixed(3);
	};

	const handlePurchasingFoodCost = () => {
		const slug = makeFoodSlug(values.name!, values.brand, values.kitchen!);

		if (values.components?.length !== 0 && slug) {
			const foodWithComponents = setComponentsOnFood([values] as FoodType[], Object.values(allComponents));
			// on each component in foodWithComponents, set the childComponents property to the childComponents of the component in allComponents using childComponent map
			for (const [index, _] of foodWithComponents[0].components.entries()) {
				if (foodWithComponents[0].components[index].childComponents) {
					foodWithComponents[0].components[index].childComponents = foodWithComponents[0].components[index].childComponents?.map(
						(ch) => ({ ...childComponent[ch.id], quantity: ch.quantity })
					);
				}
			}
			const componentsPurchasingCost = calculateFoodPurchasingCost(foodWithComponents[0].components);
			setPurchasingCostFood(componentsPurchasingCost);
		} else {
			setPurchasingCostFood(0);
		}
	};

	const handleLastUpdatedCost = () => {
		if (values.components?.length === 0) {
			return getLastUpdatedPurchasingCostDate([values as unknown as FoodComponent]);
		} else {
			const mealComponents = compact(
				flatten(values.components?.map((row) => allComponents[row.id] && { ...allComponents[row.id], quantity: row.quantity }))
			);
			const mealChildComponentsData = compact(
				flatten(
					values.components?.map((row) =>
						allComponents[row.id]?.childComponents?.map(
							(r) => childComponent && childComponent[r.id] && { ...childComponent[r.id], quantity: r.quantity }
						)
					)
				)
			);
			const allMealComponents = [...mealComponents, ...mealChildComponentsData];
			return getLastUpdatedPurchasingCostDate(allMealComponents);
		}
	};

	const handleAutoCalculate = (value: boolean) => {
		if (value) {
			setValues({
				...values,
				withManualMacros: value
			});
		} else {
			setValues({
				...values,
				macros: {
					cal: Math.round(sumBy(values.components, (fc) => allComponents[fc.id]?.macros.cal * getFoodComponentAmount(fc))),
					protein: Math.round(
						sumBy(values.components, (fc) => allComponents[fc.id]?.macros.protein * getFoodComponentAmount(fc))
					),
					carbs: Math.round(sumBy(values.components, (fc) => allComponents[fc.id]?.macros.carbs * getFoodComponentAmount(fc))),
					fat: Math.round(sumBy(values.components, (fc) => allComponents[fc.id]?.macros.fat * getFoodComponentAmount(fc))),
					fiber: Math.round(
						sumBy(values.components, (fc) => (allComponents[fc.id]?.macros.fiber || 0) * getFoodComponentAmount(fc)) || 0
					)
				},
				micronutrients: {
					addedSugar: Math.round(
						sumBy(values.components, (fc) => (allComponents[fc.id]?.micronutrients?.addedSugar || 0) * getFoodComponentAmount(fc))
					),
					cholesterol: Math.round(
						sumBy(
							values.components,
							(fc) => (allComponents[fc.id]?.micronutrients?.cholesterol || 0) * getFoodComponentAmount(fc)
						)
					),
					saturatedFats: Math.round(
						sumBy(
							values.components,
							(fc) => (allComponents[fc.id]?.micronutrients?.saturatedFats || 0) * getFoodComponentAmount(fc)
						)
					),
					sodium: Math.round(
						sumBy(values.components, (fc) => (allComponents[fc.id]?.micronutrients?.sodium || 0) * getFoodComponentAmount(fc))
					),
					totalSugar: Math.round(
						sumBy(values.components, (fc) => (allComponents[fc.id]?.micronutrients?.totalSugar || 0) * getFoodComponentAmount(fc))
					),
					transFats: Math.round(
						sumBy(values.components, (fc) => (allComponents[fc.id]?.micronutrients?.transFats || 0) * getFoodComponentAmount(fc))
					)
				},
				withManualMacros: value
			});
		}
	};

	return (
		<Stack direction="column" justifyContent="space-between" alignItems="stretch" spacing={2}>
			<StickyHeader
				roles={roles}
				dirty={dirty}
				values={values}
				isValid={isValid}
				setValues={setValues}
				isDisabled={isDisabled}
				sectionRefs={sectionRefs}
				isSubmitting={isSubmitting}
				handleSubmit={handleSubmit}
				selectedFood={selectedFood}
				setSelectedFood={setSelectedFood}
				filteredFoodUsed={filteredFoodUsed}
				foodWithAllSizes={foodWithAllSizes}
				setFoodWithAllSizes={setFoodWithAllSizes}
				usedOnMenuButtonColor={usedOnMenuButtonColor}
			/>
			<MealInformation
				values={values}
				errors={errors}
				food={food}
				isDisabled={isDisabled}
				roles={roles}
				setFieldValue={setFieldValue}
				ref={sectionRefs[0]}
			/>
			<Components
				values={values}
				isDisabled={isDisabled}
				foodComponents={foodComponents}
				isLoading={isLoading}
				allComponents={allComponents}
				setFieldValue={setFieldValue}
				handleComponentsChange={handleComponentsChange}
				ref={sectionRefs[1]}
				roles={roles}
				setName={setName}
				name={name}
			/>
			<NutritionalInformation
				values={values}
				setFieldValue={setFieldValue}
				errors={errors}
				handleBlur={handleBlur}
				handleChange={handleChange}
				microNutrientsAuto={values.withManualMacros || false}
				handleAutoCalculate={handleAutoCalculate}
				displayMessageForMacrosLimits={displayMessageForMacrosLimits}
				ref={sectionRefs[2]}
			/>
			<Information
				values={values}
				setFieldValue={setFieldValue}
				errors={errors}
				handleBlur={handleBlur}
				roles={roles}
				food={food}
				isDisabled={isDisabled}
				allSizesFood={allSizesFood}
				getTotalCost={getTotalCost}
				purchasingCostFood={purchasingCostFood}
				handleLastUpdatedCost={handleLastUpdatedCost}
			/>
			<PortioningNotes
				values={values}
				errors={errors}
				handleChange={handleChange}
				roles={roles}
				isDisabled={isDisabled}
				ref={sectionRefs[5]}
			/>
			<Ingredients values={values} roles={roles} isLoading={isLoading} ref={sectionRefs[3]} />
			<PackagingInformation
				values={values}
				setFieldValue={setFieldValue}
				setPackageCost={(r) => setPackageCost(r)}
				food={food}
				isDisabled={isDisabled}
				ref={sectionRefs[4]}
				roles={roles}
			/>
		</Stack>
	);
};

export default FoodForm;
