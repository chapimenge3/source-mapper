import { useRef } from 'react';

import { Link } from 'react-router-dom';

import { Permission } from '@calo/dashboard-types';
import { Country } from '@calo/types';
import { Icon, Icon as Iconify } from '@iconify/react';
import { Button, Divider, IconButton, Stack, Typography } from '@mui/material';

import { caloTheme } from 'assets/images/theme/calo';
import { ModalRef } from 'components';
import { Routes } from 'lib/enums';
import { resolveCountry } from 'lib/helpers';
import { Food } from 'lib/interfaces';
import DeleteSizeModal from './DeleteSizeModal';
import MealName from './MealName';
import NewSizeModal from './NewSizeModal';
import Ratings from './Ratings';
import SizesSwitch from './SizesSwitch';
import UsedOnMenu from './UsedOnMenu';

interface HeaderProps {
	selectedFood: Food;
	foodWithAllSizes: Food[];
	setSelectedFood: (food: Food) => void;
	roles: any;
	setFoodWithAllSizes: (food: Food[]) => void;
	filteredFoodUsed: {
		type: 'mainMenu' | 'addonsMenu';
		date?: string | undefined;
		week?: number | undefined;
	}[];
	usedOnMenuButtonColor: string[];
	isDisabled?: boolean;
}

const Header = ({
	selectedFood,
	foodWithAllSizes,
	setSelectedFood,
	roles,
	setFoodWithAllSizes,
	filteredFoodUsed,
	usedOnMenuButtonColor,
	isDisabled
}: HeaderProps) => {
	const addMealsModalRef = useRef<ModalRef>();
	const deleteMealModalRef = useRef<ModalRef>();

	return (
		<Stack direction="column" justifyContent="space-between" spacing={2} sx={{ backgroundColor: caloTheme.palette.white }}>
			<Stack direction="row" justifyContent="space-between" spacing={2} sx={{ mx: 2, zIndex: 0 }}>
				<Link to={Routes.foodList}>
					<Stack direction="row" justifyContent="space-between" alignItems="center" spacing={1}>
						<Icon icon="fluent:chevron-left-24-filled" color={caloTheme.palette.neutral900} style={{ fontSize: '16px' }} />
						<Typography sx={{ fontSize: '16px', fontWeight: 600, lineHeight: '20px', color: caloTheme.palette.black }}>
							Back
						</Typography>
					</Stack>
				</Link>
				<Typography sx={{ fontSize: '16px', fontWeight: 400, lineHeight: '20px', color: caloTheme.palette.black, mr: 1 }}>
					{resolveCountry(selectedFood.country || Country.BH)}
				</Typography>
			</Stack>
			<Divider />
			<Stack direction="row" justifyContent="space-between" spacing={2} alignItems="center">
				<Stack direction="row" justifyContent="space-between" alignItems="center" spacing={2}>
					<MealName selectedFood={selectedFood} />
					<Typography variant="h6" className="text-center">
						{selectedFood.kitchen}
					</Typography>
					<Ratings selectedFood={selectedFood} foodWithAllSizes={foodWithAllSizes} />
					<UsedOnMenu filteredFoodUsed={filteredFoodUsed} usedOnMenuButtonColor={usedOnMenuButtonColor} />
				</Stack>
				<SizesSwitch selectedFood={selectedFood} foodWithAllSizes={foodWithAllSizes} setSelectedFood={setSelectedFood} />
				<Stack direction="row" justifyContent="space-between" alignItems="center" spacing={2}>
					{roles.includes(Permission.DELETE_FOOD) && (
						<IconButton disabled={isDisabled} onClick={() => deleteMealModalRef.current?.open()}>
							<Iconify color={isDisabled ? caloTheme.palette.neutral500 : caloTheme.palette.red} width={30} icon="uil:trash" />
						</IconButton>
					)}
					{roles.includes(Permission.CREATE_FOOD) && (
						<Button
							variant="outlined"
							disabled={isDisabled}
							sx={{
								color: caloTheme.palette.neutral900,
								fontSize: '16px',
								fontWeight: 600,
								textTransform: 'capitalize',
								borderColor: caloTheme.palette.neutral900,
								borderRadius: '8px',
								boxShadow: 'none',
								'&:hover': {
									borderColor: caloTheme.palette.neutral900,
									backgroundColor: caloTheme.palette.neutral900,
									color: caloTheme.palette.white,
									boxShadow: 'none'
								}
							}}
							onClick={() => addMealsModalRef.current?.open()}
						>
							Add meal size
						</Button>
					)}
				</Stack>
				<NewSizeModal
					selectedFood={selectedFood}
					foodWithAllSizes={foodWithAllSizes}
					setSelectedFood={setSelectedFood}
					setFoodWithAllSizes={setFoodWithAllSizes}
					ref={addMealsModalRef}
					close={() => addMealsModalRef.current?.close()}
				/>
				<DeleteSizeModal
					selectedFood={selectedFood}
					foodWithAllSizes={foodWithAllSizes}
					setSelectedFood={setSelectedFood}
					setFoodWithAllSizes={setFoodWithAllSizes}
					ref={deleteMealModalRef}
					close={() => deleteMealModalRef.current?.close()}
				/>
			</Stack>
		</Stack>
	);
};

export default Header;
