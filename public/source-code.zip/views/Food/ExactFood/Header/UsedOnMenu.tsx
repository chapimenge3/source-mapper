import { useRef } from 'react';

import WarningAmberRoundedIcon from '@mui/icons-material/WarningAmberRounded';
import { Box, IconButton } from '@mui/material';

import { caloTheme } from 'assets/images/theme/calo';
import { ModalRef } from 'components';
import MealUsedModal from './MealUsedModal';

interface UsedOnMenuProps {
	filteredFoodUsed: {
		type: 'mainMenu' | 'addonsMenu';
		date?: string | undefined;
		week?: number | undefined;
	}[];
	usedOnMenuButtonColor: string[];
}

const UsedOnMenu = ({ filteredFoodUsed, usedOnMenuButtonColor }: UsedOnMenuProps) => {
	const foodUsedOnMenuRef = useRef<ModalRef>();
	const getColor = (type: string) => {
		switch (type) {
			case 'backgroundColor':
				return usedOnMenuButtonColor.includes('red')
					? caloTheme.palette.secondaryRed100
					: usedOnMenuButtonColor.includes('yellow')
						? caloTheme.palette.secondaryYellow100
						: caloTheme.palette.white;
			case 'color':
				return usedOnMenuButtonColor.includes('red')
					? caloTheme.palette.red
					: usedOnMenuButtonColor.includes('yellow')
						? caloTheme.palette.secondaryYellow600
						: caloTheme.palette.white;
			default:
				return caloTheme.palette.white;
		}
	};
	return (
		<Box>
			{filteredFoodUsed && filteredFoodUsed.length > 0 && (
				<IconButton
					sx={{ backgroundColor: getColor('backgroundColor'), '&:hover': { backgroundColor: getColor('backgroundColor') } }}
					onClick={() => foodUsedOnMenuRef.current?.open()}
				>
					<WarningAmberRoundedIcon style={{ color: getColor('color') }} />
				</IconButton>
			)}
			<MealUsedModal
				filteredFoodUsed={filteredFoodUsed}
				ref={foodUsedOnMenuRef}
				close={() => foodUsedOnMenuRef.current?.close()}
			/>
		</Box>
	);
};

export default UsedOnMenu;
