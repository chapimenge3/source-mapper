import { forwardRef } from 'react';

import { toast } from 'react-toastify';

import { deleteFood } from 'actions';
import { Modal, Button as OButton } from 'components';
import { Routes } from 'lib/enums';
import history from 'lib/history';
import { Food } from 'lib/interfaces';

interface DeleteSizeModalProps {
	selectedFood: Food;
	foodWithAllSizes: Food[];
	setSelectedFood: (food: Food) => void;
	setFoodWithAllSizes: (food: Food[]) => void;
	close: () => void;
}

const DeleteSizeModal = forwardRef(
	({ selectedFood, foodWithAllSizes, setSelectedFood, setFoodWithAllSizes, close }: DeleteSizeModalProps, ref) => {
		const handleDeleteSize = async () => {
			if (selectedFood) {
				await deleteFood(selectedFood.id);
				const existingFood = foodWithAllSizes.filter((f) => f.id !== selectedFood.id);
				if (existingFood.length > 0) {
					setFoodWithAllSizes(existingFood);
					setSelectedFood(existingFood[0]);
				} else {
					history.push(Routes.foodList);
				}
				close();
			}
		};

		const handleDeleteMeal = async () => {
			await Promise.all(foodWithAllSizes.map((food) => deleteFood(food.id)));
			history.push(Routes.foodList);
			toast('Meal deleted successfully', { type: 'success', autoClose: 2000 });
			close();
		};

		return (
			<Modal ref={ref}>
				<div className="flex-row justify-between items-center mb-3">
					<h1 className="text-3xl font-bold">Delete Meal Size</h1>
					<OButton icon="fas fa-times fa-lg" onClick={() => close()} className="ml-4 w-4 h-auto border-none" />
				</div>
				<h2 className="mb-5 font-bold">Are you sure you would like to delete the Meal Size?</h2>
				<div className="flex flex-row justify-between">
					<OButton
						className="py-2 px-3 border-none outline-none"
						data-test="confirm_delete_meal"
						content="Delete Meal"
						onClick={handleDeleteMeal}
					/>
					<OButton
						className="py-2 px-3 rounded-lg border-2 border-green-500"
						data-test="confirm_delete_meal_size"
						content="Delete Meal Size"
						onClick={handleDeleteSize}
					/>
				</div>
			</Modal>
		);
	}
);

export default DeleteSizeModal;
