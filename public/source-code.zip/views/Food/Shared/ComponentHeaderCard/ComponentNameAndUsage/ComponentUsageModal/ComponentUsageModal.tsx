import cx from 'classnames';
import { differenceInDays, format, parseISO } from 'date-fns';
import { forwardRef, useState } from 'react';
import { Button, Modal } from '../../../../../../components';
import { addonsWithinThisWeek, handleWeekFormat } from '../../../../../../lib/helpers';
import { UsedOnMenuReq } from '../../../../../../lib/interfaces';

interface ComponentUsageModalProps {
	filteredFoodUsed: UsedOnMenuReq[];
	onClose: () => void;
}

const ComponentUsageModal = forwardRef(({ filteredFoodUsed, onClose }: ComponentUsageModalProps, ref) => {
	const [info, setInfo] = useState<UsedOnMenuReq>();
	const [showMoreData, setShowMoreData] = useState<number>(4);

	const handleCloseModal = () => {
		onClose();
		setInfo(undefined);
		setShowMoreData(4);
	};

	const handleInfoText = (date: any, type: string) => {
		if (type === 'addonsMenu') {
			return (
				<p className="bg-gray-100 text-center text-black w-8/12 mx-auto text-sm">
					This food component is part of an addon menu, changes will not be applied before the next addon menu generation, please
					coordinate with the operations team
				</p>
			);
		} else if (differenceInDays(date, Date.now()) <= 2) {
			return (
				<p className="bg-gray-100 text-center text-black w-8/12 mx-auto text-sm">
					Components & ingredients for this component are prepped or cooked already, please communicate directly with the
					Operations team before doing any changes
				</p>
			);
		} else {
			return (
				<p className="bg-gray-100 text-center text-black w-8/12 mx-auto text-sm">
					Ingredients & components for this component might have been purchased or prepped already, please double check with the
					Operations team
				</p>
			);
		}
	};

	return (
		<Modal ref={ref} onClose={handleCloseModal}>
			<section className="section is-title-bar -mt-8">
				<p className="font-bold uppercase text-center">Component Is used in the following Days</p>
			</section>
			<section>
				<div
					className={cx('', {
						'h-64 overflow-auto overflow-y-visible': showMoreData === filteredFoodUsed.length,
						'h-auto': showMoreData !== filteredFoodUsed.length
					})}
				>
					{(showMoreData === filteredFoodUsed.length ? filteredFoodUsed : filteredFoodUsed?.slice(0, 5)).map((r) => (
						<span key={r.date ? r.date : r.week}>
							<p
								className={cx('flex justify-center mt-4', {
									'text-red-500': r.date
										? differenceInDays(parseISO(r.date!), parseISO(format(+Date.now(), 'yyyy-MM-dd'))) <= 1
										: addonsWithinThisWeek(r.week!),
									'text-yellow-300':
										r.type === 'mainMenu' && differenceInDays(parseISO(r.date!), parseISO(format(+Date.now(), 'yyyy-MM-dd'))) > 1,
									'text-purple-600': r.type === 'addonsMenu' && !addonsWithinThisWeek(r.week!)
								})}
							>
								{r.date ? format(parseISO(r.date), 'eee dd/MM/yyyy') : handleWeekFormat(r.week!)}
								{
									<i
										key={r.date ? r.date : r.week}
										className="ml-3 mt-1 fa fa-info-circle cursor-pointer"
										onClick={() => (info && (info.date === r.date || info.week === r.week) ? setInfo(undefined) : setInfo(r))}
									/>
								}
							</p>
							<span className="flex">
								{r.type === 'mainMenu' &&
									(differenceInDays(parseISO(r.date!), parseISO(format(+Date.now(), 'yyyy-MM-dd'))) >= 0 ||
										differenceInDays(parseISO(r.date!), parseISO(format(+Date.now(), 'yyyy-MM-dd'))) <= 7) &&
									info &&
									info.date === r.date &&
									handleInfoText(parseISO(r.date!), 'mainMenu')}
								{r.type === 'addonsMenu' && info && info.week === r.week && handleInfoText(r.week!, 'addonsMenu')}
							</span>
						</span>
					))}
					{filteredFoodUsed.length > 4 && showMoreData === 4 && (
						<div className="flex justify-center mt-4" data-test="show_more_data_used_in_menu">
							{' '}
							<Button
								onClick={() => setShowMoreData(filteredFoodUsed.length)}
								className="rounded-md"
								primary
								content="show more"
							/>{' '}
						</div>
					)}
				</div>
			</section>
		</Modal>
	);
});

export default ComponentUsageModal;
