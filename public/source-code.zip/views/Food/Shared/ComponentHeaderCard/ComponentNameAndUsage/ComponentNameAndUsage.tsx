import { Stack, Typography } from '@mui/material';
import { useRef, useState } from 'react';
import { Icon, ModalRef } from '../../../../../components';
import { FoodComponent, UsedOnMenuReq } from '../../../../../lib/interfaces';
import ComponentUsageModal from './ComponentUsageModal';

import { differenceInDays, endOfWeek, format, parseISO, startOfWeek } from 'date-fns';
import { useEffect } from 'react';

interface ComponentNameAndUsageProps {
	foodComponent: FoodComponent | undefined;
	filteredFoodUsed: UsedOnMenuReq[];
	isDisabled: boolean;
}

const ComponentNameAndUsage = ({ foodComponent, filteredFoodUsed, isDisabled }: ComponentNameAndUsageProps) => {
	const foodUsedOnMenuRef = useRef<ModalRef>();

	const [usedOnMenuButtonColor, setUsedOnMenuButtonColor] = useState<string[]>([]);

	useEffect(() => {
		setUsedOnMenuButtonColor([]);
		filteredFoodUsed?.map((r) => {
			if (r.date) {
				return differenceInDays(parseISO(r.date!), parseISO(format(+Date.now(), 'yyyy-MM-dd'))) <= 1
					? setUsedOnMenuButtonColor((old) => [...old, 'red'])
					: setUsedOnMenuButtonColor((old) => [...old, 'yellow']);
			} else if (r.week) {
				const weekNumber = r.week!.toString().split('#');
				const date = new Date(+weekNumber[0], 0, 1 + +weekNumber[1] * 7);
				const weekDate = date;
				weekDate.setDate(date.getDate() - 7);
				return differenceInDays(+startOfWeek(weekDate), Date.now()) <= 2 &&
					differenceInDays(+endOfWeek(weekDate), Date.now()) >= 0
					? setUsedOnMenuButtonColor((old) => [...old, 'red'])
					: setUsedOnMenuButtonColor((old) => [...old, 'addons']);
			}
		});
	}, []);

	return (
		<>
			<Stack sx={{ display: 'flex', flexDirection: 'row', gap: '8px', alignItems: 'center', justifyContent: 'center' }}>
				<Typography sx={{ fontSize: '20px', fontWeight: 600 }}>{foodComponent?.name.en}</Typography>
				{filteredFoodUsed && filteredFoodUsed.length > 0 && (
					<Stack>
						<button
							className={
								isDisabled
									? 'ml-3 rounded-md mt-1 w-8 h-8 bg-red-500'
									: usedOnMenuButtonColor.includes('yellow')
										? ' ml-3 rounded-md mt-1 w-8 h-8 bg-yellow-300'
										: ' ml-3 rounded-md mt-1 w-8 h-8 bg-purple-500'
							}
							onClick={() => foodUsedOnMenuRef.current?.open()}
						>
							<Icon name="warning" size={5} className="mt-1 ml-1 text-white" />
						</button>
					</Stack>
				)}
			</Stack>
			<ComponentUsageModal
				ref={foodUsedOnMenuRef}
				filteredFoodUsed={filteredFoodUsed}
				onClose={() => foodUsedOnMenuRef.current?.close()}
			/>
		</>
	);
};

export default ComponentNameAndUsage;
