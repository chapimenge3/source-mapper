import { Permission } from '@calo/dashboard-types';
import { Card, Stack, TextField, Typography } from '@mui/material';
import { format } from 'date-fns';
import { FormikErrors } from 'formik';
import InputThemeProvider from '../../../../components/MUI/InputThemeProvider';
import { useUserRoles } from '../../../../lib/hooks';
import { IngredientFormData } from '../../../../lib/interfaces';
import { FormOperation, IngredientOperationValues } from '../../helpers';

type CostCardProps = {
	values: IngredientFormData;
	errors: FormikErrors<IngredientFormData>;
	handleChange: { (e: React.ChangeEvent<any>): void };
} & IngredientOperationValues;

const CostCard = ({ values, errors, handleChange, ...props }: CostCardProps) => {
	const userRoles = useUserRoles();

	return (
		<Card
			variant="outlined"
			sx={{
				marginTop: '16px',
				border: 'none',
				borderRadius: '16px',
				px: '12px',
				py: '20px'
			}}
		>
			<InputThemeProvider>
				<Stack sx={{ display: 'flex', flexDirection: 'row', gap: '12px', marginBottom: '20px' }}>
					<Typography variant="h5" sx={{ fontSize: '19px', fontWeight: 600 }}>
						Cost
					</Typography>
				</Stack>
				<TextField
					label={`Cost (per measurement unit)`}
					value={values.cost}
					name="cost"
					sx={{ width: '100%' }}
					onChange={handleChange}
					type="number"
					disabled={props.operation === FormOperation.update ? true : !userRoles.includes(Permission.CREATE_INGREDIENT)}
					error={!!errors.cost}
				/>
				<Stack sx={{ display: 'flex', flexDirection: 'row', gap: 2, marginTop: '24px' }}>
					<TextField
						label="Last Updated Date (Precoro)"
						value={
							props.operation === FormOperation.update && props.ingredient.costLastUpdated
								? format(new Date(props.ingredient.costLastUpdated), 'dd/MM/yyyy')
								: '--'
						}
						name="lastUpdatedDate"
						sx={{ width: '100%' }}
						onChange={handleChange}
						disabled
					/>
					<TextField
						label="Unit"
						value={props.operation === FormOperation.update ? props.ingredient.order?.convertedUnit : '--'}
						name="unit"
						sx={{ width: '100%' }}
						onChange={handleChange}
						disabled
					/>
				</Stack>
			</InputThemeProvider>
		</Card>
	);
};

export default CostCard;
