import { FoodComponentFilters, FoodComponentStatus } from '@calo/dashboard-types';
import { Brand, Country, Kitchen } from '@calo/types';
import { getListWithParams, toggleUISettings } from 'actions';
import { Input, QuickView, Select, Select2 } from 'components';
import { getAccessibleCountries, getKitchenOptions, handleSearch } from 'lib/helpers';
import { useUserKitchens } from 'lib/hooks';
import { AppState, Ingredient, Options } from 'lib/interfaces';
import { isNull, sortBy } from 'lodash';
import { useMemo, useState } from 'react';
import { useQuery } from 'react-query';
import { useDispatch, useSelector } from 'react-redux';

interface SettingsProps {
	onFilter: (values: FoodComponentFilters) => any;
	filters: FoodComponentFilters;
}

const Settings = ({ filters, onFilter }: SettingsProps) => {
	const { settingsVisible } = useSelector((state: AppState) => ({
		settingsVisible: state.ui.settings
	}));

	const userKitchens: string[] = useUserKitchens();
	const dispatch = useDispatch();
	const [allIngredients, setAllIngredients] = useState<Ingredient[]>([]);
	const [filterIngredients, setFilterIngredients] = useState<string>();

	const { isLoading: ingLoading } = useQuery<any, Error, { data: Ingredient[] }>(
		[
			'ingredients',
			{
				filters: {
					country: filters.country,
					brand: filters.brand || Brand.CALO,
					kitchen: filters.kitchen || Kitchen.BH1,
					name: filterIngredients || undefined,
					ids: !filterIngredients && filters.ingredientId ? filters.ingredientId : undefined
				}
			}
		],
		getListWithParams,
		{
			enabled: !!filterIngredients || !filters.ingredientId,
			onSuccess: (allIngredientList) => {
				setAllIngredients(allIngredientList?.data);
			}
		}
	);

	const ingredientOptions: Options<Ingredient>[] = useMemo(
		() =>
			sortBy(allIngredients, (ingredient) => `${ingredient.name.en}`).map((ingredient) => ({
				value: ingredient.id,
				data: { ...ingredient },
				label: `${ingredient.name.en} (${ingredient.internalName || ''})`
			})),
		[allIngredients]
	);

	return (
		<QuickView visible={settingsVisible} onClose={() => dispatch(toggleUISettings())}>
			<section className="section">
				<h5 className="title is-5">Filters</h5>
				<Select2
					label="Country"
					value={filters.country}
					onChange={(data) =>
						onFilter({
							...filters,
							country: data.target.value as Country,
							kitchen: userKitchens.find((k) => k.includes(data.target.value)) as Kitchen
						})
					}
					options={getAccessibleCountries(userKitchens).map((c) => ({
						value: c,
						label: Country[c]
					}))}
				/>
				<Select2
					label="Kitchen"
					value={filters.kitchen}
					onChange={(data) => onFilter({ ...filters, kitchen: data.target.value as Kitchen })}
					options={getKitchenOptions(userKitchens, filters.country!)}
					disabled={userKitchens.filter((r) => r.includes(filters.country!)).length === 0}
				/>
				<Input label="Name" value={filters.name} onChange={(e) => onFilter({ ...filters, name: e.target.value })} debounce />

				<Select
					label="Ingredient"
					isClearable
					value={filters.ingredientId}
					options={ingredientOptions}
					isLoading={ingLoading}
					onChange={(ingredient: Options<Ingredient> | null) => {
						if (isNull(ingredient)) {
							onFilter({ ...filters, ingredientId: undefined });
						} else {
							onFilter({ ...filters, ingredientId: ingredient.data.id });
						}
					}}
					onInputChange={(data: string, action: string) => handleSearch({ text: data, action, name: setFilterIngredients })}
				/>

				<Select
					label="Recipe Status"
					value={filters.status}
					onChange={(status: any) => onFilter({ ...filters, status: status.value })}
					options={[
						{
							value: undefined,
							label: 'Any'
						},
						...Object.entries(FoodComponentStatus).map(([key, value]) => ({
							value: key,
							label: value
						}))
					]}
				/>
			</section>
		</QuickView>
	);
};
export default Settings;
