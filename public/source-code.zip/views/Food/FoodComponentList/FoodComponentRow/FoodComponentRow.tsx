import { Permission } from '@calo/dashboard-types';
import { Link } from 'react-router-dom';

import { Routes } from 'lib/enums';
import { useUserRoles } from 'lib/hooks';
import { FoodComponent } from 'lib/interfaces';

interface FoodComponentRowProps {
	foodComponent: FoodComponent;
}

const FoodComponentRow = ({ foodComponent }: FoodComponentRowProps) => {
	const roles = useUserRoles();

	return (
		<tr>
			<td>
				{roles.includes(Permission.VIEW_FOOD_COMPONENTS) ? (
					<Link to={Routes.foodComponent.replace(':id', foodComponent.id)}>{foodComponent.name.en}</Link>
				) : (
					foodComponent.name.en
				)}
			</td>
			<td>{foodComponent.weight}</td>
			<td>{foodComponent.macros.cal}</td>
			<td>{foodComponent.macros.protein}</td>
			<td>{foodComponent.macros.carbs}</td>
			<td>{foodComponent.macros.fat}</td>
			<td>{foodComponent.cost}</td>
			<td></td>
		</tr>
	);
};

export default FoodComponentRow;
