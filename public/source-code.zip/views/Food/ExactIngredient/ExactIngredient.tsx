import { useEffect } from 'react';

import { useMutation, useQuery } from 'react-query';
import { useParams } from 'react-router';

import { getRecord, updateIngredient } from 'actions';
import { IngredientFormData, IngredientType } from 'lib/interfaces';
import { omit } from 'lodash';
import AllergenCategoryCard from '../Shared/AllergenCategoryCard';
import CostCard from '../Shared/CostCard';
import IngredientHeaderCard from '../Shared/IngredientHeaderCard';
import MeasurementGuideAndMacrosCard from '../Shared/MeasurementGuideAndMacrosCard';
import { FormOperation, calculateCalories } from '../helpers';
import IngredientInformationCard from './IngredientInformationCard';
import PrecoroInformationCard from './PrecoroInformationCard';
import useIngredientForm from './useIngredientForm';

const ExactIngredient = () => {
	const { id } = useParams<{ id: string }>();
	const { mutateAsync: updateMutation } = useMutation(updateIngredient);
	const isDisabled = false;

	const { data } = useQuery(['ingredients', id], getRecord, {
		suspense: true
	});
	const ingredient = data as IngredientType;

	const handleUpdateIngredient = async (values: IngredientFormData) => {
		await updateMutation({ id, ...omit(values, ['order']) });
		ingredient.name.en = values.name.en;
	};

	const { values, errors, isValid, isSubmitting, dirty, handleSubmit, handleChange, handleBlur, setFieldValue } =
		useIngredientForm(ingredient, handleUpdateIngredient);

	useEffect(() => {
		setFieldValue('macros.cal', calculateCalories(values.macros));
	}, [values.macros.carbs, values.macros.fat, values.macros.protein]);

	useEffect(() => {
		const calValue = calculateCalories(values.macros);
		if (values.macros.cal !== calValue) {
			setFieldValue('macros.cal', calValue);
		}
	}, []);

	return (
		<>
			<IngredientHeaderCard
				operation={FormOperation.update}
				ingredient={ingredient}
				dirty={dirty}
				isValid={isValid}
				isSubmitting={isSubmitting}
				handleSubmit={handleSubmit}
			/>
			<IngredientInformationCard
				values={values}
				errors={errors}
				handleChange={handleChange}
				handleBlur={handleBlur}
				setFieldValue={setFieldValue}
				isDisabled={isDisabled}
			/>
			<AllergenCategoryCard values={values} setFieldValue={setFieldValue} isDisabled={isDisabled} />
			<MeasurementGuideAndMacrosCard
				values={values}
				errors={errors}
				handleBlur={handleBlur}
				handleChange={handleChange}
				setFieldValue={setFieldValue}
				isDisabled={isDisabled}
			/>
			<CostCard
				operation={FormOperation.update}
				values={values}
				errors={errors}
				ingredient={ingredient}
				handleChange={handleChange}
			/>
			<PrecoroInformationCard ingredient={ingredient} handleChange={handleChange} />
		</>
	);
};

export default ExactIngredient;
