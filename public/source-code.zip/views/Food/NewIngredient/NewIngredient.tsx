import { createIngredient } from 'actions';
import { Routes } from 'lib/enums';
import { useEffect } from 'react';
import { useMutation } from 'react-query';
import { useHistory } from 'react-router-dom';
import useIngredientForm from './useIngredientForm';

import { IngredientFormData } from 'lib/interfaces';
import AllergenCategoryCard from '../Shared/AllergenCategoryCard';
import CostCard from '../Shared/CostCard';
import IngredientHeaderCard from '../Shared/IngredientHeaderCard';
import MeasurementGuideAndMacrosCard from '../Shared/MeasurementGuideAndMacrosCard';
import { FormOperation, calculateCalories } from '../helpers';
import IngredientInformationCard from './IngredientInformationCard';

const NewIngredient = () => {
	const { mutateAsync: createMutation } = useMutation(createIngredient);
	const history = useHistory();

	const handleNewIngredient = async (values: IngredientFormData) => {
		const ingredient = await createMutation(values);
		history.replace(Routes.ingredient.replace(':id', ingredient.id));
	};

	const { values, isSubmitting, isValid, dirty, touched, errors, handleBlur, handleSubmit, handleChange, setFieldValue } =
		useIngredientForm(handleNewIngredient);

	useEffect(() => {
		setFieldValue('macros.cal', calculateCalories(values.macros));
	}, [values.macros.carbs, values.macros.fat, values.macros.protein]);

	return (
		<>
			<IngredientHeaderCard
				dirty={dirty}
				isValid={isValid}
				isSubmitting={isSubmitting}
				operation={FormOperation.create}
				handleSubmit={handleSubmit}
			/>
			<IngredientInformationCard
				errors={errors}
				values={values}
				touched={touched}
				handleBlur={handleBlur}
				handleChange={handleChange}
				setFieldValue={setFieldValue}
			/>
			<AllergenCategoryCard values={values} setFieldValue={setFieldValue} />
			<MeasurementGuideAndMacrosCard
				values={values}
				errors={errors}
				handleBlur={handleBlur}
				handleChange={handleChange}
				setFieldValue={setFieldValue}
			/>
			<CostCard values={values} errors={errors} operation={FormOperation.create} handleChange={handleChange} />
		</>
	);
};

export default NewIngredient;
