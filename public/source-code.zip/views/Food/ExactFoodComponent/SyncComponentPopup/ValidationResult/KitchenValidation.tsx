import { Kitchen } from '@calo/types';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import { Box, Button, Stack, Typography } from '@mui/material';
import { caloTheme } from 'assets/images/theme/calo';
import { getKitchenShortCut } from 'lib/helpers';
import { useState } from 'react';

interface KitchenValidationProps {
	kitchen: Kitchen;
	validationData: { type: string; value: string }[] | undefined;
}

const KitchenValidation = ({ kitchen, validationData }: KitchenValidationProps) => {
	const [showValidationResult, setShowValidationResult] = useState(false);

	const ingredientsMissing = validationData?.filter((data) => data.type === 'ingredient').map((data) => data.value);
	const isComponentMissing = validationData?.find((data) => data.type === 'component');

	return (
		<Stack sx={{ display: 'flex', flexDirection: 'column', gap: 2, mb: '30px' }}>
			<Button
				variant="outlined"
				endIcon={showValidationResult ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
				onClick={() => setShowValidationResult((prev) => !prev)}
				sx={{
					backgroundColor: validationData ? '#FAEEEE' : caloTheme.palette.primary100,
					borderColor: caloTheme.palette.primary100,
					color: 'black',
					fontWeight: 600,
					fontSize: '14px',
					py: '10px',
					justifyContent: 'space-between',
					'&:hover': {
						backgroundColor: validationData ? '#FAEEEE' : caloTheme.palette.primary100,
						borderColor: caloTheme.palette.primary100
					}
				}}
			>
				{getKitchenShortCut(kitchen)}
			</Button>

			{showValidationResult && (
				<Box
					sx={{
						border: '2px solid ' + caloTheme.palette.neutral100,
						borderRadius: '8px',
						display: 'flex',
						flexDirection: 'column',
						gap: '10px',
						padding: '12px'
					}}
				>
					{ingredientsMissing &&
						ingredientsMissing.map((ingredient) => (
							<Typography sx={{ fontWeight: 600, fontSize: '14px' }} key={ingredient}>
								Ingredient "{ingredient}" does not exist. Please create ingredient for this MP to sync
							</Typography>
						))}
					{isComponentMissing && (
						<Typography sx={{ fontWeight: 600, fontSize: '14px' }}>
							This component "{isComponentMissing.value}" does not appear in MP database. Please create component in order to
							update it
						</Typography>
					)}
					{!validationData && (
						<>
							<Typography sx={{ fontWeight: 600, fontSize: '14px' }}>
								The component name in this MP matches the component we are trying to update
							</Typography>
							<Typography sx={{ fontWeight: 600, fontSize: '14px' }}>We found all the ingredients in this MP</Typography>
						</>
					)}
				</Box>
			)}
		</Stack>
	);
};

export default KitchenValidation;
