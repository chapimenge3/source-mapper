import { useMemo, useState } from 'react';

import { FormikErrors } from 'formik';
import { keyBy } from 'lodash-es';
import { useQuery } from 'react-query';

import { Permission } from '@calo/dashboard-types';
import AddIcon from '@mui/icons-material/Add';
import { Box, Button, Card, Stack, Typography } from '@mui/material';

import { getListWithParams } from 'actions';
import { caloTheme } from 'assets/images/theme/calo';
import IngredientPickerMUI from 'components/MUI/IngredientPickerMUI';
import { calculatePurchasingCost } from 'lib/helpers';
import { useUserRoles } from 'lib/hooks';
import { BaseOmit, FoodComponent, Ingredient, IngredientHeaderItem } from 'lib/interfaces';
import { findNumberOfIngredientHeaders } from '../helpers';

interface IngredientListProps {
	values: Omit<FoodComponent, BaseOmit>;
	foodComponent: FoodComponent;
	childCompIngData: any[];
	structuredIngredients: IngredientHeaderItem[];
	setValues: (
		values: React.SetStateAction<Omit<FoodComponent, BaseOmit>>,
		shouldValidate?: boolean | undefined
	) => Promise<void> | Promise<any>;
	setStructuredIngredients: React.Dispatch<React.SetStateAction<IngredientHeaderItem[]>>;
	setFieldValue: (
		field: string,
		value: any,
		shouldValidate?: boolean | undefined
	) => Promise<void> | Promise<FormikErrors<Omit<FoodComponent, BaseOmit>>>;
	isDisabled?: boolean;
}

const IngredientListCard = ({
	foodComponent,
	values,
	structuredIngredients,
	childCompIngData,
	setFieldValue,
	setValues,
	setStructuredIngredients,
	isDisabled
}: IngredientListProps) => {
	const userRoles = useUserRoles();

	const [ingredientName, setIngredientName] = useState('');

	const { data: ingredientsData } = useQuery<any, Error, { data: Ingredient[] }>(
		[
			'ingredients',
			{
				filters: {
					name: ingredientName,
					country: foodComponent?.country,
					brand: foodComponent?.brand,
					kitchen: foodComponent?.kitchen
				}
			}
		],
		getListWithParams,
		{
			enabled: !!ingredientName,
			keepPreviousData: true
		}
	);

	const handleIngredientsChange = (rows: Ingredient[]) => {
		setValues({
			...values,
			ingredients: rows,
			purchasingCost: +calculatePurchasingCost(
				rows.length > 0 ? rows : [],
				childCompIngData ? childCompIngData.map((child: any) => child.ingredients) : [],
				values.cookedRawFactor || 1
			)
		});
	};

	const newIngredient = useMemo(() => keyBy(ingredientsData?.data || [], 'id'), [values?.ingredients, ingredientsData]);
	const existingIngredient = useMemo(() => keyBy(values?.ingredients, 'id'), [values?.ingredients, ingredientsData]);

	const addHeaderClickHandler = () => {
		const numberOfHeaders = findNumberOfIngredientHeaders(structuredIngredients);
		setStructuredIngredients((prev) => [{ type: 'header', header: `Header  ${numberOfHeaders + 1}` }, ...prev]);
	};

	return (
		<Card
			variant="outlined"
			sx={{
				marginTop: '16px',
				border: 'none',
				borderRadius: '16px',
				py: '18px',
				overflow: 'visible',
				zIndex: 100
			}}
		>
			<Stack
				sx={{
					marginBottom: '10px',
					px: '16px',
					display: 'flex',
					flexDirection: 'row',
					justifyContent: 'space-between',
					alignItems: 'center'
				}}
			>
				<Typography sx={{ fontSize: '19px', fontWeight: 600 }}>Ingredients</Typography>
				<Button
					disabled={isDisabled}
					onClick={addHeaderClickHandler}
					startIcon={<AddIcon />}
					sx={{
						color: caloTheme.palette.primary500,
						fontSize: '16px',
						fontWeight: 600,
						textTransform: 'none'
					}}
				>
					Add Header
				</Button>
			</Stack>
			<Box sx={{ borderColor: 'white' }}>
				<IngredientPickerMUI
					newIngredient={newIngredient}
					list={ingredientsData?.data || []}
					onChange={handleIngredientsChange}
					ingredients={values.ingredients}
					structuredIngredients={structuredIngredients}
					setStructuredIngredients={setStructuredIngredients}
					setFieldValue={setFieldValue}
					ingredientName={ingredientName}
					setIngredientName={setIngredientName}
					existingIngredient={existingIngredient}
					isDisabled={!userRoles.includes(Permission.UPDATE_FOOD_COMPONENTS) || Boolean(isDisabled)}
				/>
			</Box>
		</Card>
	);
};

export default IngredientListCard;
