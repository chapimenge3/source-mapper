import { useEffect, useMemo, useState } from 'react';

import { FormikErrors } from 'formik';
import { compact, difference, flatten, isEqual, keyBy } from 'lodash-es';
import { useQuery } from 'react-query';

import { LinkedComponent, Permission } from '@calo/dashboard-types';
import { Macros, Micronutrients } from '@calo/types';
import { Box, Card, Typography } from '@mui/material';

import { getListWithParams } from 'actions';
import { FoodComponentPickerMUI } from 'components';
import { calculateMacrosFromIngredients, calculatePurchasingCost } from 'lib/helpers';
import { useUserRoles } from 'lib/hooks';
import { BaseOmit, FoodComponent, Ingredient } from 'lib/interfaces';

interface ChildComponentsProps {
	values: Omit<FoodComponent, BaseOmit>;
	foodComponent: FoodComponent;
	childCompIngData: any;
	setChildCompIngData: React.Dispatch<React.SetStateAction<any[]>>;
	setIsCalculatedMacrosDifferent: React.Dispatch<React.SetStateAction<boolean>>;
	setCalculatedMacrosFromIngredients: React.Dispatch<React.SetStateAction<Macros | undefined>>;
	setCalculatedMicronutrientsFromIngredients: React.Dispatch<React.SetStateAction<Micronutrients | undefined>>;
	setFieldValue: (
		field: string,
		value: any,
		shouldValidate?: boolean | undefined
	) => Promise<void> | Promise<FormikErrors<Omit<FoodComponent, BaseOmit>>>;
	setValues: (
		values: React.SetStateAction<Omit<FoodComponent, BaseOmit>>,
		shouldValidate?: boolean | undefined
	) => Promise<FormikErrors<Omit<FoodComponent, BaseOmit>>> | Promise<any>;
	isDisabled?: boolean;
}

const ChildComponentsCard = ({
	values,
	foodComponent,
	childCompIngData,
	setChildCompIngData,
	setValues,
	setFieldValue,
	setIsCalculatedMacrosDifferent,
	setCalculatedMicronutrientsFromIngredients,
	setCalculatedMacrosFromIngredients,
	isDisabled
}: ChildComponentsProps) => {
	const userRoles = useUserRoles();

	const [childCompIngId, setChildCompIngId] = useState<{ id: string; quantity: number }[]>([]);
	const [foodComponentListIDS, setFoodComponentListIDS] = useState<FoodComponent[]>([]);
	const [exFoodCompIds, setExFoodCompIds] = useState<string[]>([]);
	const [foodComponentName, setFoodComponentName] = useState('');

	useQuery<any, Error, { data: FoodComponent[] }>(
		[
			'food-components',
			{
				filters: {
					ids: exFoodCompIds,
					country: foodComponent?.country,
					brand: foodComponent?.brand,
					kitchen: foodComponent?.kitchen
				}
			}
		],
		getListWithParams,
		{
			suspense: false,
			keepPreviousData: true,
			enabled: !!exFoodCompIds.length && userRoles.includes(Permission.VIEW_FOOD_COMPONENTS),
			onSuccess: (data) => {
				setFoodComponentListIDS([...foodComponentListIDS, ...(data.data || [])]);
			}
		}
	);

	const { data: foodComponentList, isLoading: foodComponentLoading } = useQuery<any, Error, { data: FoodComponent[] }>(
		[
			'food-components',
			{
				filters: {
					name: foodComponentName,
					country: foodComponent?.country,
					brand: foodComponent?.brand,
					kitchen: foodComponent?.kitchen
				}
			}
		],
		getListWithParams,
		{
			enabled: !!foodComponentName,
			keepPreviousData: true
		}
	);

	const componentAPIIds = useMemo(() => keyBy(foodComponentListIDS!, 'id'), [foodComponentListIDS]);
	const componentAPI = useMemo(() => keyBy(foodComponentList?.data, 'id'), [foodComponentList?.data]);

	const [allComponents, setAllComponents] = useState<{ [x: string]: FoodComponent }>({});

	useQuery<any, Error, { data: Ingredient[] }>(
		[
			'ingredients',
			{
				filters: {
					ids: childCompIngId.map((comIng) => comIng?.id),
					country: foodComponent?.country,
					brand: foodComponent?.brand,
					kitchen: foodComponent?.kitchen
				}
			}
		],
		getListWithParams,
		{
			enabled: childCompIngId.length > 0,
			onSuccess: (data) => {
				setChildCompIngData([]);
				if (data.data.length > 0) {
					for (const row of data?.data || []) {
						setChildCompIngData((old) => [
							...old,
							{
								...row,
								quantity: childCompIngId.find((ing) => ing.id === row.id)?.quantity || 0
							}
						]);
					}
				}
			}
		}
	);

	useEffect(() => {
		setAllComponents({ ...componentAPI, ...componentAPIIds });
	}, [componentAPIIds, componentAPI]);

	useEffect(() => {
		setValues({
			...values,
			purchasingCost: +calculatePurchasingCost(
				values.ingredients,
				childCompIngData.length > 0 ? childCompIngData : [],
				values.cookedRawFactor || 0
			)
		});
	}, [childCompIngData]);

	useEffect(() => {
		if (values.cookedRawFactor) {
			setValues({
				...values,
				purchasingCost: +calculatePurchasingCost(
					values.ingredients,
					childCompIngData.length > 0 ? childCompIngData : [],
					values.cookedRawFactor || 0
				)
			});
		}
	}, [values.cookedRawFactor]);

	useEffect(() => {
		if (values.childComponents && values.childComponents.length > 0) {
			setChildCompIngId(
				compact(
					flatten(
						values.childComponents?.map((row) =>
							allComponents[row.id]?.ingredients?.map((ings) => ({
								id: ings.id,
								quantity: ings.quantity || 0
							}))
						)
					)
				)
			);
		}
	}, [allComponents]);

	useEffect(() => {
		const childCompIds = values.childComponents?.map((r) => r.id) || [];
		if (difference(childCompIds, Object.keys(allComponents)).length === 0) {
			const response = calculateMacrosFromIngredients(
				values.ingredients,
				values.childComponents || [],
				allComponents,
				values.cookedRawFactor || 1
			);
			if (response) {
				setCalculatedMacrosFromIngredients(response.macros);
				setCalculatedMicronutrientsFromIngredients(response.micronutrients);
				setIsCalculatedMacrosDifferent(
					!(isEqual(response.micronutrients, values.micronutrients) && isEqual(response.macros, values.macros))
				);
			}
		}
	}, [values, allComponents]);

	useEffect(() => {
		if (values.childComponents && values.childComponents.length > 0) {
			setExFoodCompIds(values.childComponents?.map((r) => r.id) || []);
			setChildCompIngId(
				compact(
					flatten(
						values.childComponents?.map((row) =>
							allComponents[row.id]?.ingredients?.map((ings) => ({
								id: ings.id,
								quantity: ings.quantity || 0
							}))
						)
					)
				)
			);
		} else {
			setExFoodCompIds([]);
			setChildCompIngId([]);
			setChildCompIngData([]);
		}
	}, [values.childComponents]);

	const handleChildComponents = (rows: LinkedComponent[]) => {
		setExFoodCompIds(rows.map((r) => r.id));
		setChildCompIngId(
			compact(
				flatten(
					rows.map((row) =>
						allComponents[row.id].ingredients.map((ings) => ({
							id: ings.id,
							quantity: ings.quantity || 0
						}))
					)
				)
			)
		);
		setValues({
			...values,
			childComponents: rows.map((row) => ({ id: row.id, quantity: row.quantity }))
		});
	};

	return (
		<Card
			variant="outlined"
			sx={{
				border: 'none',
				marginTop: '16px',
				borderRadius: '16px',
				py: '18px',
				zIndex: 90,
				overflow: 'visible'
			}}
		>
			<Typography sx={{ fontSize: '19px', px: '16px', fontWeight: 600, marginBottom: '10px' }}>Child Components</Typography>
			<Box sx={{ borderColor: 'white' }}>
				<FoodComponentPickerMUI
					childComp={true}
					name={foodComponentName}
					allComponents={allComponents}
					setFieldValue={setFieldValue}
					setName={setFoodComponentName}
					isLoading={foodComponentLoading}
					onChange={handleChildComponents}
					value={values.childComponents || []}
					list={foodComponentList?.data || []}
					isDisabled={
						!userRoles.includes(Permission.UPDATE_FOOD_COMPONENTS) ||
						!!(values.parentComponentIds && values.parentComponentIds.length > 0) ||
						Boolean(isDisabled)
					}
				/>
			</Box>
		</Card>
	);
};

export default ChildComponentsCard;
