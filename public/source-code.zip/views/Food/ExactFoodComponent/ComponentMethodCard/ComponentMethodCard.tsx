import { FormikErrors } from 'formik';

import { Permission } from '@calo/dashboard-types';
import { Card, Typography } from '@mui/material';

import { ComponentMethod } from 'components';
import { useUserRoles } from 'lib/hooks';
import { BaseOmit, FoodComponent } from 'lib/interfaces';

interface ComponentMethodCardProps {
	values: Omit<FoodComponent, BaseOmit>;
	errors: FormikErrors<Omit<FoodComponent, BaseOmit>>;
	isEdit: boolean;
	setIsEdit: React.Dispatch<React.SetStateAction<boolean>>;
	setFieldValue: (
		field: string,
		value: any,
		shouldValidate?: boolean | undefined
	) => Promise<FormikErrors<Omit<FoodComponent, BaseOmit>>> | Promise<any>;
	setValues: (
		values: React.SetStateAction<Omit<FoodComponent, BaseOmit>>,
		shouldValidate?: boolean | undefined
	) => Promise<FormikErrors<Omit<FoodComponent, BaseOmit>>> | Promise<any>;
	isDisabled?: boolean;
}

const ComponentMethodCard = ({ values, isEdit, setIsEdit, setValues, setFieldValue, isDisabled }: ComponentMethodCardProps) => {
	const userRoles = useUserRoles();

	return (
		<Card
			variant="outlined"
			sx={{
				marginTop: '16px',
				border: 'none',
				borderRadius: '16px',
				px: '18px',
				py: '18px'
			}}
		>
			<Typography sx={{ fontSize: '19px', fontWeight: 600, marginBottom: '10px' }}>Method</Typography>
			<ComponentMethod
				values={values}
				setValues={(v) => setValues(v)}
				setFieldValue={(data: any) => setFieldValue('method', data)}
				uploadImages={true}
				disabled={!userRoles.includes(Permission.UPDATE_FOOD_COMPONENTS) || Boolean(isDisabled)}
				isEdit={isEdit}
				setIsEdit={(value) => setIsEdit(value)}
			/>
		</Card>
	);
};

export default ComponentMethodCard;
