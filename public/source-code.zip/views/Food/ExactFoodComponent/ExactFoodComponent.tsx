import { useEffect, useRef, useState } from 'react';

import { isNil, sortBy } from 'lodash-es';
import { useMutation, useQuery } from 'react-query';
import { useParams } from 'react-router';

import { MeasurementUnit } from '@calo/dashboard-types';
import { Macros, Micronutrients } from '@calo/types';

import { getRecord, updateFoodComponent } from 'actions';
import { ModalRef } from 'components';
import FoodComponentCalculatedMacrosModal from 'components/FoodComponentCalculatedMacrosModal/FoodComponentCalculatedMacrosModal';
import { FoodComponent, Ingredient, IngredientHeaderItem } from 'lib/interfaces';
import ComponentHeaderCard from '../Shared/ComponentHeaderCard';
import { FormOperation } from '../helpers';
import ChildComponentsCard from './ChildComponentsCard';
import ComponentInformationCard from './ComponentInformationCard';
import ComponentMethodCard from './ComponentMethodCard';
import ComponentNameAndImageCard from './ComponentNameAndImageCard';
import CupsListCard from './CupsListCard';
import IngredientListCard from './IngredientListCard';
import MacrosMicrosInputCard from './MacrosMicrosInputCard';
import SyncComponentPopup from './SyncComponentPopup';
import { filterAndSortUsedOnMenu } from './helpers';
import useFoodComponentForm from './useFoodComponentForm';

const ExactFoodComponent = () => {
	const isDisabled = false;
	const { id } = useParams<{ id: string }>();
	const syncComponentsPopupRef = useRef<ModalRef>();
	const calculatedMacrosRef = useRef<ModalRef>();

	const [isEdit, setIsEdit] = useState<boolean>(false);
	const [childCompIngData, setChildCompIngData] = useState<any[]>([]);
	const [calculatedMacrosFromIngredients, setCalculatedMacrosFromIngredients] = useState<Macros | undefined>();
	const [calculatedMicronutrientsFromIngredients, setCalculatedMicronutrientsFromIngredients] = useState<
		Micronutrients | undefined
	>();
	const [isCalculatedMacrosDifferent, setIsCalculatedMacrosDifferent] = useState(false);
	const [structuredIngredients, setStructuredIngredients] = useState<IngredientHeaderItem[]>([]);

	const { data: foodComponent, isLoading } = useQuery<any, Error, FoodComponent>(['food-components', id], getRecord, {
		suspense: true,
		keepPreviousData: false
	});

	const { mutateAsync: updateMutation } = useMutation(updateFoodComponent);

	const handleUpdateFood = (values: Partial<FoodComponent>, structuredIngredients: IngredientHeaderItem[]) => {
		const updatedIngredients: Ingredient[] = [];
		let tempHeaderName: string | null = null;
		for (const structuredIngredient of structuredIngredients) {
			if (structuredIngredient.type === 'header') {
				tempHeaderName = structuredIngredient.header;
			} else {
				updatedIngredients.push({ ...structuredIngredient.ingredient, header: tempHeaderName ?? undefined });
			}
		}

		const { purchasingCost, ...rest } = values;
		return updateMutation({ id, ...rest, ingredients: updatedIngredients });
	};

	const filteredFoodUsed = filterAndSortUsedOnMenu(foodComponent);

	const submitValues = async (values: Partial<FoodComponent>) => {
		await handleUpdateFood(values, structuredIngredients);
	};

	const { handleSubmit, values, handleChange, handleBlur, isSubmitting, isValid, setFieldValue, setValues, errors } =
		useFoodComponentForm(foodComponent, submitValues);

	let currentHeader: string | null | undefined;
	useEffect(() => {
		const sortedIngredients = sortBy(values.ingredients, [(ingredient) => (isNil(ingredient.header) ? -1 : 0), 'header']);

		const updatedStructuredIngredients: IngredientHeaderItem[] = [];
		for (const ingredient of sortedIngredients) {
			if (ingredient.header !== currentHeader && ingredient.header !== null && ingredient.header !== undefined) {
				currentHeader = ingredient.header;
				updatedStructuredIngredients.push({ type: 'header', header: currentHeader });
			}
			updatedStructuredIngredients.push({ type: 'ingredient', ingredient });
		}

		setStructuredIngredients(updatedStructuredIngredients);
	}, [values.ingredients]);

	return (
		<>
			<ComponentHeaderCard
				operation={FormOperation.update}
				foodComponent={foodComponent}
				filteredFoodUsed={filteredFoodUsed}
				syncComponentsPopupRef={syncComponentsPopupRef}
				isValid={isValid}
				isSubmitting={isSubmitting}
				isEdit={isEdit}
				handleSubmit={handleSubmit}
				isDisabled={isDisabled}
			/>
			{foodComponent && (
				<>
					<ComponentNameAndImageCard
						foodComponent={foodComponent}
						values={values}
						errors={errors}
						isLoading={isLoading}
						handleChange={handleChange}
						isDisabled={isDisabled}
					/>
					<IngredientListCard
						childCompIngData={childCompIngData}
						values={values}
						foodComponent={foodComponent}
						structuredIngredients={structuredIngredients}
						setValues={setValues}
						setFieldValue={setFieldValue}
						setStructuredIngredients={setStructuredIngredients}
						isDisabled={isDisabled}
					/>
					<ChildComponentsCard
						values={values}
						foodComponent={foodComponent}
						childCompIngData={childCompIngData}
						setValues={setValues}
						setFieldValue={setFieldValue}
						setChildCompIngData={setChildCompIngData}
						setIsCalculatedMacrosDifferent={setIsCalculatedMacrosDifferent}
						setCalculatedMicronutrientsFromIngredients={setCalculatedMicronutrientsFromIngredients}
						setCalculatedMacrosFromIngredients={setCalculatedMacrosFromIngredients}
						isDisabled={isDisabled}
					/>
					<MacrosMicrosInputCard
						values={values}
						errors={errors}
						setValues={setValues}
						setFieldValue={setFieldValue}
						handleChange={handleChange}
						handleBlur={handleBlur}
						calculatedMacrosRef={calculatedMacrosRef}
						isCalculatedMacrosDifferent={isCalculatedMacrosDifferent}
						calculatedMacrosFromIngredients={calculatedMacrosFromIngredients}
						calculatedMicronutrientsFromIngredients={calculatedMicronutrientsFromIngredients}
						isDisabled={isDisabled}
					/>
					<ComponentInformationCard
						values={values}
						errors={errors}
						setFieldValue={setFieldValue}
						handleChange={handleChange}
						handleBlur={handleBlur}
						isDisabled={isDisabled}
					/>
					{values.measurementUnit === MeasurementUnit.cup && (
						<CupsListCard values={values} setValues={setValues} setFieldValue={setFieldValue} isDisabled={isDisabled} />
					)}
					<ComponentMethodCard
						values={values}
						errors={errors}
						isEdit={isEdit}
						setIsEdit={setIsEdit}
						setValues={setValues}
						setFieldValue={setFieldValue}
						isDisabled={isDisabled}
					/>
				</>
			)}
			<FoodComponentCalculatedMacrosModal
				calculatedMacrosFromIngredients={calculatedMacrosFromIngredients}
				calculatedMacrosRef={calculatedMacrosRef}
				calculatedMicronutrientsFromIngredients={calculatedMicronutrientsFromIngredients}
			/>
			{foodComponent && (
				<SyncComponentPopup
					id={id}
					componentName={foodComponent.name.en}
					currentKitchen={foodComponent.kitchen}
					closePopup={() => syncComponentsPopupRef.current?.close()}
					ref={syncComponentsPopupRef}
				/>
			)}
		</>
	);
};

export default ExactFoodComponent;
