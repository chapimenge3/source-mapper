import { Card, Stack, Typography } from '@mui/material';

import { FoodComponentStation, FoodComponentStatus, MeasurementUnit, Permission } from '@calo/dashboard-types';
import { FoodComponentType } from '@calo/types';
import { Checkbox, FormControlLabel, MenuItem, TextField } from '@mui/material';
import { caloTheme } from 'assets/images/theme/calo';
import InputThemeProvider from 'components/MUI/InputThemeProvider';
import { FormikErrors } from 'formik';
import { resolveMeasurementUnit } from 'lib/helpers';
import { useUserRoles } from 'lib/hooks';
import { BaseOmit, FoodComponent } from 'lib/interfaces';

interface ComponentInformationProps {
	values: Omit<FoodComponent, BaseOmit>;
	errors: FormikErrors<Omit<FoodComponent, BaseOmit>>;
	isDisabled?: boolean;
	setFieldValue: (
		field: string,
		value: any,
		shouldValidate?: boolean | undefined
	) => Promise<FormikErrors<Omit<FoodComponent, BaseOmit>>> | Promise<any>;
	handleBlur: {
		(e: React.FocusEvent<any, Element>): void;
		<T = any>(fieldOrEvent: T): T extends string ? (e: any) => void : void;
	};
	handleChange: {
		(e: React.ChangeEvent<any>): void;
		<T_1 = string | React.ChangeEvent<any>>(
			field: T_1
		): T_1 extends React.ChangeEvent<any> ? void : (e: string | React.ChangeEvent<any>) => void;
	};
}

const ComponentInformationCard = ({
	values,
	errors,
	isDisabled,
	setFieldValue,
	handleChange,
	handleBlur
}: ComponentInformationProps) => {
	const userRoles = useUserRoles();

	return (
		<Card
			variant="outlined"
			sx={{
				marginTop: '16px',
				border: 'none',
				borderRadius: '16px',
				px: '18px',
				py: '18px'
			}}
		>
			<Typography sx={{ fontSize: '19px', fontWeight: 600, marginBottom: '10px' }}>Additional Information</Typography>
			<InputThemeProvider>
				<Stack
					sx={{
						display: 'flex',
						flexDirection: 'column',
						gap: 1
					}}
				>
					<Stack
						sx={{
							display: 'flex',
							flexDirection: 'row',
							justifyContent: 'space-between',
							gap: 2
						}}
					>
						<TextField
							label="Cost*"
							value={values.cost}
							name="cost"
							onChange={handleChange}
							onBlur={handleBlur}
							type="number"
							disabled={!userRoles.includes(Permission.CREATE_FOOD_COMPONENTS) || isDisabled}
							error={!!errors.cost}
							sx={{ my: 1, zIndex: 0, width: '100%' }}
							inputProps={{ inputProps: { style: { borderRadius: 8, min: 0 } }, style: { borderRadius: 8 } }}
						/>
						<TextField
							label="Purchasing Cost"
							value={values.purchasingCost}
							name="purchasingCost"
							onChange={handleChange}
							onBlur={handleBlur}
							type="number"
							disabled
							error={!!errors.purchasingCost}
							sx={{ my: 1, width: '100%' }}
							inputProps={{ inputProps: { style: { borderRadius: 8, min: 0 } }, style: { borderRadius: 8 } }}
						/>
						<TextField
							label="Cooked Weight"
							value={values.weight}
							name="weight"
							onChange={handleChange}
							onBlur={handleBlur}
							type="number"
							disabled={!userRoles.includes(Permission.CREATE_FOOD_COMPONENTS) || isDisabled}
							sx={{ my: 1, width: '100%' }}
							inputProps={{ inputProps: { style: { borderRadius: 8, min: 0 } }, style: { borderRadius: 8 } }}
						/>
						<TextField
							label="Cooked > Raw Factor"
							value={values.cookedRawFactor}
							name="cookedRawFactor"
							onChange={handleChange}
							onBlur={handleBlur}
							disabled={!userRoles.includes(Permission.CREATE_FOOD_COMPONENTS) || isDisabled}
							sx={{ my: 1, width: '100%' }}
							inputProps={{ inputProps: { style: { borderRadius: 8, min: 0 } }, style: { borderRadius: 8 } }}
						/>
					</Stack>
					<Stack
						sx={{
							display: 'flex',
							flexDirection: 'row',
							gap: 2
						}}
					>
						<TextField
							select
							label="Measurement Unit"
							value={values.measurementUnit}
							placeholder="Select Unit"
							sx={{ my: 1, width: '100%' }}
							disabled={!userRoles.includes(Permission.CREATE_FOOD_COMPONENTS) || isDisabled}
							onChange={(data: any) => setFieldValue('measurementUnit', data.target.value)}
							InputProps={{ inputProps: { style: { borderRadius: 8 } }, style: { borderRadius: 8 } }}
						>
							{Object.values(MeasurementUnit).map((unit) => (
								<MenuItem key={unit} value={unit}>
									{unit}
								</MenuItem>
							))}
						</TextField>
						<TextField
							select
							label="Tags"
							value={values.tags}
							SelectProps={{
								multiple: true,
								value: values.tags,
								onChange: (e) => setFieldValue('tags', e.target.value)
							}}
							sx={{ my: 1, width: '100%' }}
							disabled={!userRoles.includes(Permission.CREATE_FOOD_COMPONENTS) || isDisabled}
							InputProps={{ inputProps: { style: { borderRadius: 8 } }, style: { borderRadius: 8 } }}
						>
							{Object.values(FoodComponentType).map((prepOrder) => (
								<MenuItem key={prepOrder} value={prepOrder}>
									{prepOrder}
								</MenuItem>
							))}
						</TextField>

						<TextField
							select
							label="Station"
							value={values.cookingStation}
							SelectProps={{
								multiple: true,
								value: values.cookingStation,
								onChange: (e) => setFieldValue('cookingStation', e.target.value)
							}}
							sx={{ my: 1, width: '100%' }}
							disabled={!userRoles.includes(Permission.CREATE_FOOD_COMPONENTS) || isDisabled}
							InputProps={{ inputProps: { style: { borderRadius: 8 } }, style: { borderRadius: 8 } }}
						>
							{Object.entries(FoodComponentStation).map(([key, value]) => (
								<MenuItem key={key} value={key}>
									{value}
								</MenuItem>
							))}
						</TextField>
						<TextField
							select
							name="status"
							label="Recipe Status"
							value={values.status}
							sx={{ my: 1, width: '100%' }}
							disabled={!userRoles.includes(Permission.CREATE_FOOD_COMPONENTS) || isDisabled}
							onChange={(data: any) => setFieldValue('status', data.target.value)}
							InputProps={{ inputProps: { style: { borderRadius: 8 } }, style: { borderRadius: 8 } }}
						>
							{Object.entries(FoodComponentStatus).map(([key, value]) => (
								<MenuItem key={key} value={key}>
									{value}
								</MenuItem>
							))}
						</TextField>
					</Stack>
					<TextField
						label={`Default ${resolveMeasurementUnit(values.measurementUnit)} Quantity*`}
						value={values.defaultWeight}
						name="defaultWeight"
						onChange={handleChange}
						onBlur={handleBlur}
						type="number"
						disabled={!userRoles.includes(Permission.CREATE_FOOD_COMPONENTS) || isDisabled}
						error={values.forCustomization && (!values.defaultWeight || values.defaultWeight === 0)}
						sx={{ my: 1, width: '24%' }}
						inputProps={{ inputProps: { style: { borderRadius: 8, min: 0 } }, style: { borderRadius: 8 } }}
					/>
				</Stack>
				<Stack
					sx={{
						width: '100%',
						height: '1px',
						marginTop: '6px',
						marginBottom: '12px',
						backgroundColor: caloTheme.palette.neutral100
					}}
				/>
				<FormControlLabel
					control={
						<Checkbox
							name="forCustomization"
							checked={values.forCustomization}
							onChange={(e) => setFieldValue('forCustomization', e.target.checked)}
							disabled={!userRoles.includes(Permission.CREATE_FOOD_COMPONENTS) || isDisabled}
						/>
					}
					label="Custom Meal"
				/>
			</InputThemeProvider>
		</Card>
	);
};

export default ComponentInformationCard;
