import { useEffect, useMemo, useState } from 'react';

import { FormikErrors } from 'formik';
import { compact, difference, flatten, isEqual, keyBy } from 'lodash-es';
import { useQuery } from 'react-query';

import { LinkedComponent, Permission } from '@calo/dashboard-types';
import { Macros, Micronutrients } from '@calo/types';
import { Box, Card, Typography } from '@mui/material';

import { getListWithParams } from 'actions';
import { FoodComponentPickerMUI } from 'components';
import { calculateMacrosFromIngredients, calculatePurchasingCost } from 'lib/helpers';
import { useUserRoles } from 'lib/hooks';
import { BaseOmit, FoodComponent, Ingredient } from 'lib/interfaces';

interface ChildComponentsProps {
	values: Omit<FoodComponent, BaseOmit>;
	childCompIngData: any;
	setChildCompIngData: React.Dispatch<React.SetStateAction<any[]>>;
	setIsCalculatedMacrosDifferent: React.Dispatch<React.SetStateAction<boolean>>;
	setCalculatedMacrosFromIngredients: React.Dispatch<React.SetStateAction<Macros | undefined>>;
	setCalculatedMicronutrientsFromIngredients: React.Dispatch<React.SetStateAction<Micronutrients | undefined>>;
	setFieldValue: (
		field: string,
		value: any,
		shouldValidate?: boolean | undefined
	) => Promise<void> | Promise<FormikErrors<Omit<FoodComponent, BaseOmit>>>;
	setValues: (
		values: React.SetStateAction<Omit<FoodComponent, BaseOmit>>,
		shouldValidate?: boolean | undefined
	) => Promise<FormikErrors<Omit<FoodComponent, BaseOmit>>> | Promise<any>;
}

const ChildComponentsCard = ({
	values,
	childCompIngData,
	setChildCompIngData,
	setValues,
	setFieldValue,
	setIsCalculatedMacrosDifferent,
	setCalculatedMicronutrientsFromIngredients,
	setCalculatedMacrosFromIngredients
}: ChildComponentsProps) => {
	const userRoles = useUserRoles();

	const [foodComponentName, setFoodComponentName] = useState('');
	const [foodCompIDS, setFoodCompIDS] = useState<string[]>([]);
	const [childCompIngId, setChildCompIngId] = useState<{ id: string; quantity: number }[]>([]);

	const { data: foodComponentListIDS } = useQuery<any, Error, { data: FoodComponent[] }>(
		['food-components', { filters: { ids: foodCompIDS, country: values.country, brand: values.brand, kitchen: values.kitchen } }],
		getListWithParams,
		{
			suspense: false,
			enabled: !!foodCompIDS.length
		}
	);

	const { data: foodComponentList, isLoading: foodComponentLoading } = useQuery<any, Error, { data: FoodComponent[] }>(
		[
			'food-components',
			{ filters: { name: foodComponentName, country: values.country, brand: values.brand, kitchen: values.kitchen } }
		],
		getListWithParams,
		{
			suspense: false,
			enabled: !!foodComponentName
		}
	);
	const componentAPI = useMemo(() => keyBy(foodComponentList?.data || [], 'id'), [foodComponentList]);
	const componentAPIIds = useMemo(() => keyBy(foodComponentListIDS?.data || [], 'id'), [foodComponentListIDS!]);
	const [allComponents, setAllComponents] = useState({ ...componentAPI, ...componentAPIIds });

	useEffect(() => {
		setAllComponents({ ...componentAPI, ...componentAPIIds });
	}, [componentAPI]);

	const handleChildComponents = (rows: LinkedComponent[]) => {
		setFoodCompIDS(rows.map((r) => r.id));
		setChildCompIngId(
			compact(
				flatten(
					rows.map((row) =>
						allComponents[row.id].ingredients.map((ings) => ({
							id: ings.id,
							quantity: ings.quantity || 0
						}))
					)
				)
			)
		);
		setValues({
			...values,
			childComponents: rows.map((row) => ({ id: row.id, quantity: row.quantity }))
		});
	};

	useQuery<any, Error, { data: Ingredient[] }>(
		[
			'ingredients',
			{
				filters: {
					ids: childCompIngId.map((comIng) => comIng?.id),
					country: values.country,
					brand: values.brand,
					kitchen: values.kitchen
				}
			}
		],
		getListWithParams,
		{
			enabled: childCompIngId.length > 0,
			onSuccess: (data) => {
				setChildCompIngData([]);
				if (data.data.length > 0) {
					for (const row of data?.data || []) {
						setChildCompIngData((old) => [
							...old,
							{
								...row,
								quantity: childCompIngId.find((ing) => ing.id === row.id)?.quantity || 0
							}
						]);
					}
				}
			}
		}
	);

	useEffect(() => {
		const childCompIds = values.childComponents?.map((r) => r.id) || [];
		if (difference(childCompIds, Object.keys(allComponents)).length === 0) {
			const response = calculateMacrosFromIngredients(
				values.ingredients,
				values.childComponents || [],
				allComponents,
				values.cookedRawFactor || 1
			);
			if (response) {
				setCalculatedMacrosFromIngredients(response.macros);
				setCalculatedMicronutrientsFromIngredients(response.micronutrients);
				setIsCalculatedMacrosDifferent(
					!(isEqual(response.micronutrients, values.micronutrients) && isEqual(response.macros, values.macros))
				);
			}
		}
	}, [values]);

	useEffect(() => {
		if (values.cookedRawFactor) {
			setValues({
				...values,
				purchasingCost: +calculatePurchasingCost(
					values.ingredients,
					childCompIngData.length > 0 ? childCompIngData : [],
					values.cookedRawFactor || 0
				)
			});
		}
	}, [values.cookedRawFactor]);

	useEffect(() => {
		setValues({
			...values,
			purchasingCost: +calculatePurchasingCost(
				values.ingredients,
				childCompIngData.length > 0 ? childCompIngData : [],
				values.cookedRawFactor || 0
			)
		});
	}, [childCompIngData]);

	return (
		<Card
			variant="outlined"
			sx={{
				border: 'none',
				marginTop: '16px',
				borderRadius: '16px',
				py: '18px',
				zIndex: 90,
				overflow: 'visible'
			}}
		>
			<Typography sx={{ fontSize: '19px', px: '16px', fontWeight: 600, marginBottom: '10px' }}>Child Components</Typography>
			<Box sx={{ borderColor: 'white' }}>
				<FoodComponentPickerMUI
					childComp={true}
					name={foodComponentName}
					allComponents={allComponents}
					setFieldValue={setFieldValue}
					setName={setFoodComponentName}
					isLoading={foodComponentLoading}
					onChange={handleChildComponents}
					value={values.childComponents || []}
					list={foodComponentList?.data || []}
					isDisabled={
						!userRoles.includes(Permission.UPDATE_FOOD_COMPONENTS) ||
						!!(values.parentComponentIds && values.parentComponentIds.length > 0)
					}
				/>
			</Box>
		</Card>
	);
};

export default ChildComponentsCard;
