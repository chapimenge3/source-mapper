import { Macros, Micronutrients } from '@calo/types';
import { Card } from '@mui/material';
import { FormikErrors } from 'formik';
import { ModalRef } from '../../../../components';
import { useUserRoles } from '../../../../lib/hooks';
import { BaseOmit, FoodComponent } from '../../../../lib/interfaces';

import { Permission } from '@calo/dashboard-types';
import { Stack, TextField } from '@mui/material';
import { useEffect } from 'react';
import { toast } from 'react-toastify';
import FoodComponentMacrosCalculator from '../../../../components/FoodComponentMacrosCalculator';
import InputThemeProvider from '../../../../components/MUI/InputThemeProvider';

interface MacrosMicrosInputProps {
	values: Omit<FoodComponent, BaseOmit>;
	errors: FormikErrors<Omit<FoodComponent, BaseOmit>>;
	calculatedMacrosFromIngredients: Macros | undefined;
	calculatedMicronutrientsFromIngredients: Micronutrients | undefined;
	isCalculatedMacrosDifferent: boolean;
	warningUsed?: boolean;
	calculatedMacrosRef: React.MutableRefObject<ModalRef | undefined>;
	setValues: (
		values: React.SetStateAction<Omit<FoodComponent, BaseOmit>>,
		shouldValidate?: boolean | undefined
	) => Promise<FormikErrors<Omit<FoodComponent, BaseOmit>>> | Promise<any>;
	setFieldValue: (
		field: string,
		value: any,
		shouldValidate?: boolean | undefined
	) => Promise<FormikErrors<Omit<FoodComponent, BaseOmit>>> | Promise<any>;
	handleBlur: {
		(e: React.FocusEvent<any, Element>): void;
		<T = any>(fieldOrEvent: T): T extends string ? (e: any) => void : void;
	};
	handleChange: {
		(e: React.ChangeEvent<any>): void;
		<T_1 = string | React.ChangeEvent<any>>(
			field: T_1
		): T_1 extends React.ChangeEvent<any> ? void : (e: string | React.ChangeEvent<any>) => void;
	};
}

const MacrosMicrosInputCard = ({
	values,
	errors,
	calculatedMacrosFromIngredients,
	calculatedMicronutrientsFromIngredients,
	isCalculatedMacrosDifferent,
	warningUsed,
	calculatedMacrosRef,
	setValues,
	setFieldValue,
	handleChange,
	handleBlur
}: MacrosMicrosInputProps) => {
	const userRoles = useUserRoles();

	useEffect(() => {
		const calValue = (values.macros?.fat || 0) * 9 + (values.macros?.carbs || 0) * 4 + (values.macros?.protein || 0) * 4;
		if (values.macros?.cal !== calValue) {
			setFieldValue('macros.cal', calValue);
		}
		if (!values.macros.fiber) {
			setFieldValue('macros.fiber', 0);
		}
	}, []);

	useEffect(() => {
		setFieldValue(
			'macros.cal',
			(values.macros?.fat || 0) * 9 + (values.macros?.carbs || 0) * 4 + (values.macros?.protein || 0) * 4
		);
	}, [values.macros?.carbs, values.macros?.fat, values.macros?.protein]);

	const applyCalculatedMacros = () => {
		if (calculatedMacrosFromIngredients && calculatedMicronutrientsFromIngredients) {
			setValues({
				...values,
				macros: {
					...values.macros,
					...calculatedMacrosFromIngredients
				},
				micronutrients: {
					...values.micronutrients,
					...calculatedMicronutrientsFromIngredients
				}
			});
		} else {
			toast(`There is no values from ingredients`, { type: 'error', autoClose: 2000 });
		}
	};

	return (
		<Card
			variant="outlined"
			sx={{
				marginTop: '16px',
				border: 'none',
				borderRadius: '16px',
				px: '14px',
				paddingTop: '12px',
				paddingBottom: '20px'
			}}
		>
			<FoodComponentMacrosCalculator
				applyCalculatedMacros={applyCalculatedMacros}
				calculatedMacrosRef={calculatedMacrosRef}
				isCalculatedMacrosDifferent={isCalculatedMacrosDifferent}
			/>
			<InputThemeProvider>
				<Stack sx={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between', gap: 2, marginTop: '16px' }}>
					<TextField
						label="Cal*"
						value={values.macros.cal}
						name="macros.cal"
						onChange={handleChange}
						onBlur={handleBlur}
						type="number"
						sx={{ width: '100%' }}
						disabled
						error={!!errors.macros?.cal}
					/>
					<TextField
						label="Protein*"
						value={values.macros.protein}
						name="macros.protein"
						onChange={handleChange}
						onBlur={handleBlur}
						type="number"
						sx={{ width: '100%' }}
						disabled={!userRoles.includes(Permission.CREATE_FOOD_COMPONENTS) || warningUsed}
						error={!!errors.macros?.protein}
					/>
					<TextField
						label="Carbs*"
						value={values.macros.carbs}
						name="macros.carbs"
						onChange={handleChange}
						type="number"
						onBlur={handleBlur}
						sx={{ width: '100%' }}
						disabled={!userRoles.includes(Permission.CREATE_FOOD_COMPONENTS) || warningUsed}
						error={!!errors.macros?.carbs}
					/>
					<TextField
						label="Fat*"
						value={values.macros.fat}
						name="macros.fat"
						onChange={handleChange}
						onBlur={handleBlur}
						type="number"
						sx={{ width: '100%' }}
						disabled={!userRoles.includes(Permission.CREATE_FOOD_COMPONENTS) || warningUsed}
						error={!!errors.macros?.fat}
					/>
					<TextField
						label="Fiber"
						value={values.macros.fiber}
						name="macros.fiber"
						onChange={handleChange}
						onBlur={handleBlur}
						type="number"
						sx={{ width: '100%' }}
						disabled={!userRoles.includes(Permission.CREATE_FOOD_COMPONENTS) || warningUsed}
					/>
				</Stack>
				<Stack sx={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between', gap: 2, marginTop: 2 }}>
					<TextField
						label="Saturated Fats"
						value={values.micronutrients?.saturatedFats}
						name="micronutrients.saturatedFats"
						onChange={handleChange}
						onBlur={handleBlur}
						type="number"
						disabled={!userRoles.includes(Permission.CREATE_FOOD_COMPONENTS) || warningUsed}
						sx={{ width: '100%' }}
						error={!!errors.micronutrients?.saturatedFats}
					/>
					<TextField
						label="Trans Fats"
						value={values.micronutrients?.transFats}
						name="micronutrients.transFats"
						onChange={handleChange}
						onBlur={handleBlur}
						type="number"
						disabled={!userRoles.includes(Permission.CREATE_FOOD_COMPONENTS) || warningUsed}
						sx={{ width: '100%' }}
						error={!!errors.micronutrients?.transFats}
					/>
					<TextField
						type="number"
						label="Sodium"
						onBlur={handleBlur}
						onChange={handleChange}
						name="micronutrients.sodium"
						sx={{ width: '100%' }}
						value={values.micronutrients?.sodium}
						error={!!errors.micronutrients?.sodium}
						disabled={!userRoles.includes(Permission.CREATE_FOOD_COMPONENTS) || warningUsed}
					/>
					<TextField
						label="Cholesterol"
						value={values.micronutrients?.cholesterol}
						name="micronutrients.cholesterol"
						onChange={handleChange}
						onBlur={handleBlur}
						type="number"
						disabled={!userRoles.includes(Permission.CREATE_FOOD_COMPONENTS) || warningUsed}
						sx={{ width: '100%' }}
						error={!!errors.micronutrients?.cholesterol}
					/>
					<TextField
						type="number"
						onBlur={handleBlur}
						label="Added sugar"
						name="micronutrients.addedSugar"
						onChange={handleChange}
						sx={{ width: '100%' }}
						value={values.micronutrients?.addedSugar}
						error={!!errors.micronutrients?.addedSugar}
						disabled={!userRoles.includes(Permission.CREATE_FOOD_COMPONENTS) || warningUsed}
					/>
					<TextField
						type="number"
						onBlur={handleBlur}
						label="Total sugar"
						name="micronutrients.totalSugar"
						onChange={handleChange}
						sx={{ width: '100%' }}
						value={values.micronutrients?.totalSugar}
						error={!!errors.micronutrients?.totalSugar}
						disabled={!userRoles.includes(Permission.CREATE_FOOD_COMPONENTS) || warningUsed}
					/>
				</Stack>
			</InputThemeProvider>
		</Card>
	);
};

export default MacrosMicrosInputCard;
