import { useEffect, useRef, useState } from 'react';

import { isNil, sortBy } from 'lodash-es';
import { useMutation } from 'react-query';
import { useHistory } from 'react-router-dom';

import { CreateFoodComponentReq, MeasurementUnit } from '@calo/dashboard-types';
import { Macros, Micronutrients } from '@calo/types';

import { createFoodComponent } from 'actions';
import { ModalRef } from 'components';
import { Routes } from 'lib/enums';
import { FoodComponent, Ingredient, IngredientHeaderItem } from 'lib/interfaces';
import ComponentHeaderCard from '../Shared/ComponentHeaderCard';
import { FormOperation } from '../helpers';
import AdditionalInformationCard from './AdditionalInformationCard';
import ChildComponentsCard from './ChildComponentsCard';
import ComponentInformationCard from './ComponentInformationCard';
import ComponentMethodCard from './ComponentMethodCard';
import CupsListCard from './CupsListCard';
import IngredientListCard from './IngredientListCard';
import MacrosMicrosInputCard from './MacrosMicrosInputCard';
import useFoodComponentForm from './useFoodComponentForm';

const NewFoodComponent = () => {
	const history = useHistory();
	const { mutateAsync: createMutation } = useMutation(createFoodComponent);

	const handleUpdateFood = (values: Partial<FoodComponent>, structuredIngredients: IngredientHeaderItem[]) => {
		const updatedIngredients: Ingredient[] = [];
		let tempHeaderName: string | null = null;
		for (const structuredIngredient of structuredIngredients) {
			if (structuredIngredient.type === 'header') {
				tempHeaderName = structuredIngredient.header;
			} else {
				updatedIngredients.push({ ...structuredIngredient.ingredient, header: tempHeaderName ?? undefined });
			}
		}

		const { ...rest } = values;
		return createMutation({ ...rest, ingredients: updatedIngredients } as CreateFoodComponentReq);
	};

	const handleCreateFoodComponent = async (values: CreateFoodComponentReq) => {
		const foodComponent = await handleUpdateFood(values, structuredIngredients);
		history.replace(Routes.foodComponent.replace(':id', foodComponent.id));
	};

	const { values, errors, touched, isValid, setValues, handleBlur, handleSubmit, handleChange, isSubmitting, setFieldValue } =
		useFoodComponentForm(handleCreateFoodComponent);

	const [childCompIngData, setChildCompIngData] = useState<any[]>([]);
	const [calculatedMacrosFromIngredients, setCalculatedMacrosFromIngredients] = useState<Macros | undefined>();
	const [calculatedMicronutrientsFromIngredients, setCalculatedMicronutrientsFromIngredients] = useState<
		Micronutrients | undefined
	>();
	const [isCalculatedMacrosDifferent, setIsCalculatedMacrosDifferent] = useState(false);
	const [structuredIngredients, setStructuredIngredients] = useState<IngredientHeaderItem[]>([]);
	const [isEdit, setIsEdit] = useState<boolean>(false);
	const calculatedMacrosRef = useRef<ModalRef>();

	let currentHeader: string | null | undefined;
	useEffect(() => {
		const sortedIngredients = sortBy(values.ingredients, [
			(ingredient) => (isNil(ingredient.header) ? -1 : 0), // Sort undefined headerName first
			'header' // Then sort by headerName alphabetically
		]);

		const updatedStructuredIngredients: IngredientHeaderItem[] = [];
		for (const ingredient of sortedIngredients) {
			if (ingredient.header !== currentHeader && ingredient.header !== null && ingredient.header !== undefined) {
				currentHeader = ingredient.header;
				updatedStructuredIngredients.push({ type: 'header', header: currentHeader });
			}
			updatedStructuredIngredients.push({ type: 'ingredient', ingredient });
		}

		setStructuredIngredients(updatedStructuredIngredients);
	}, [values.ingredients]);

	useEffect(() => {
		setFieldValue('ingredients', []);
		setFieldValue('purchasingCost', 0);
	}, [values.country, values.brand, values.kitchen]);

	return (
		<>
			<ComponentHeaderCard
				operation={FormOperation.create}
				isSubmitting={isSubmitting}
				isValid={isValid}
				isEdit={isEdit}
				handleSubmit={handleSubmit}
			/>
			<ComponentInformationCard
				touched={touched}
				errors={errors}
				handleBlur={handleBlur}
				handleChange={handleChange}
				setFieldValue={setFieldValue}
				isSubmitting={isSubmitting}
				values={values}
			/>
			<IngredientListCard
				childCompIngData={childCompIngData}
				setFieldValue={setFieldValue}
				setStructuredIngredients={setStructuredIngredients}
				setValues={setValues}
				structuredIngredients={structuredIngredients}
				values={values}
			/>
			<ChildComponentsCard
				childCompIngData={childCompIngData}
				setCalculatedMacrosFromIngredients={setCalculatedMacrosFromIngredients}
				setCalculatedMicronutrientsFromIngredients={setCalculatedMicronutrientsFromIngredients}
				setChildCompIngData={setChildCompIngData}
				setFieldValue={setFieldValue}
				setIsCalculatedMacrosDifferent={setIsCalculatedMacrosDifferent}
				setValues={setValues}
				values={values}
			/>
			<MacrosMicrosInputCard
				calculatedMicronutrientsFromIngredients={calculatedMicronutrientsFromIngredients}
				calculatedMacrosFromIngredients={calculatedMacrosFromIngredients}
				isCalculatedMacrosDifferent={isCalculatedMacrosDifferent}
				calculatedMacrosRef={calculatedMacrosRef}
				values={values}
				errors={errors}
				handleBlur={handleBlur}
				handleChange={handleChange}
				setFieldValue={setFieldValue}
				setValues={setValues}
			/>
			<AdditionalInformationCard
				errors={errors}
				values={values}
				handleBlur={handleBlur}
				handleChange={handleChange}
				setFieldValue={setFieldValue}
			/>
			{values.measurementUnit === MeasurementUnit.cup && (
				<CupsListCard setFieldValue={setFieldValue} setValues={setValues} values={values} />
			)}
			<ComponentMethodCard
				errors={errors}
				values={values}
				setFieldValue={setFieldValue}
				setValues={setValues}
				isEdit={isEdit}
				setIsEdit={setIsEdit}
			/>
		</>
	);
};

export default NewFoodComponent;
