import { useMemo, useState } from 'react';

import { FormikErrors } from 'formik';
import { keyBy } from 'lodash';
import { useQuery } from 'react-query';

import AddIcon from '@mui/icons-material/Add';
import { Box, Button, Card, Stack, Typography } from '@mui/material';

import { getListWithParams } from '../../../../actions';
import { caloTheme } from '../../../../assets/images/theme/calo';
import IngredientPickerMUI from '../../../../components/MUI/IngredientPickerMUI';
import { calculatePurchasingCost } from '../../../../lib/helpers';
import { BaseOmit, FoodComponent, Ingredient, IngredientHeaderItem } from '../../../../lib/interfaces';
import { findNumberOfIngredientHeaders } from '../../ExactFoodComponent/helpers';

interface IngredientListProps {
	values: Omit<FoodComponent, BaseOmit>;
	childCompIngData: any[];
	structuredIngredients: IngredientHeaderItem[];
	setValues: (
		values: React.SetStateAction<Omit<FoodComponent, BaseOmit>>,
		shouldValidate?: boolean | undefined
	) => Promise<void> | Promise<any>;
	setStructuredIngredients: React.Dispatch<React.SetStateAction<IngredientHeaderItem[]>>;
	setFieldValue: (
		field: string,
		value: any,
		shouldValidate?: boolean | undefined
	) => Promise<void> | Promise<FormikErrors<Omit<FoodComponent, BaseOmit>>>;
}

const IngredientListCard = ({
	values,
	structuredIngredients,
	childCompIngData,
	setFieldValue,
	setValues,
	setStructuredIngredients
}: IngredientListProps) => {
	const [ingredientName, setIngredientName] = useState('');

	const { data: ingData } = useQuery<any, Error, { data: Ingredient[] }>(
		['ingredients', { filters: { name: ingredientName, country: values.country, brand: values.brand, kitchen: values.kitchen } }],
		getListWithParams
	);

	const newIngredient = useMemo(() => keyBy(ingData?.data || [], 'id'), [ingData]);
	const existingIngredient = useMemo(() => keyBy(values?.ingredients, 'id'), [values?.ingredients]);

	const handleIngredientsChange = (rows: Ingredient[]) => {
		setValues({
			...values,
			ingredients: rows,
			purchasingCost: +calculatePurchasingCost(
				rows.length > 0 ? rows : [],
				childCompIngData ? childCompIngData.map((child: any) => child.ingredients) : [],
				values.cookedRawFactor || 1
			)
		});
	};

	const addHeaderClickHandler = () => {
		const numberOfHeaders = findNumberOfIngredientHeaders(structuredIngredients);
		setStructuredIngredients((prev) => [{ type: 'header', header: `Header  ${numberOfHeaders + 1}` }, ...prev]);
	};

	return (
		<Card
			variant="outlined"
			sx={{
				marginTop: '16px',
				border: 'none',
				borderRadius: '16px',
				py: '18px',
				overflow: 'visible',
				zIndex: 100
			}}
		>
			<Stack
				sx={{
					marginBottom: '10px',
					px: '16px',
					display: 'flex',
					flexDirection: 'row',
					justifyContent: 'space-between',
					alignItems: 'center'
				}}
			>
				<Typography sx={{ fontSize: '19px', fontWeight: 600 }}>Ingredients</Typography>
				<Button
					onClick={addHeaderClickHandler}
					startIcon={<AddIcon />}
					sx={{
						color: caloTheme.palette.primary500,
						fontSize: '16px',
						fontWeight: 600,
						textTransform: 'none'
					}}
				>
					Add Header
				</Button>
			</Stack>
			<Box sx={{ borderColor: 'white' }}>
				<IngredientPickerMUI
					isDisabled={false}
					ingredients={values.ingredients}
					structuredIngredients={structuredIngredients}
					setStructuredIngredients={setStructuredIngredients}
					list={ingData?.data || []}
					newIngredient={newIngredient}
					ingredientName={ingredientName}
					setFieldValue={setFieldValue}
					onChange={handleIngredientsChange}
					setIngredientName={setIngredientName}
					existingIngredient={existingIngredient}
				/>
			</Box>
		</Card>
	);
};

export default IngredientListCard;
