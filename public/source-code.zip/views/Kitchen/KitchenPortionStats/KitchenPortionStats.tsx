import { useCallback, useMemo, useState } from 'react';

import { format } from 'date-fns/fp';
import ExcelJS, { Column, Style } from 'exceljs';
import { saveAs } from 'file-saver';
import { chunk, flatten, sortBy } from 'lodash-es';
import { useQuery } from 'react-query';
import { useDispatch } from 'react-redux';
import { useLocation } from 'react-router-dom';
import { v4 as uuid } from 'uuid';

import { PortionStatsFilters } from '@calo/dashboard-types';
import { Brand, Kitchen } from '@calo/types';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import {
	Box,
	Button,
	Card,
	Checkbox,
	FormControlLabel,
	MenuItem,
	Select,
	Stack,
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableRow,
	Typography,
	styled,
	tableCellClasses
} from '@mui/material';

import { getListWithParams, toggleUISettings } from 'actions';
import { caloTheme } from 'assets/images/theme/calo';
import { CaloLoader, Icon } from 'components';
import { groupedAllMeals, resolveCountryFromKitchen } from 'lib';
import history from 'lib/history';
import { useUserKitchens, useUserRoles } from 'lib/hooks';
import { FoodComponent } from 'lib/interfaces';
import Settings from './Settings';

export interface FoodStatsComponent extends FoodComponent {
	quantity: number;
	size: string;
}

const border: Partial<Style> = {
	border: {
		top: { style: 'thin', color: { argb: 'D3D3D3' } },
		left: { style: 'thin', color: { argb: 'D3D3D3' } },
		bottom: { style: 'thin', color: { argb: 'D3D3D3' } },
		right: { style: 'thin', color: { argb: 'D3D3D3' } }
	}
};

const columns: Array<Partial<Column>> = [
	{ header: 'Name', width: 30, key: 'name', style: border },
	{ header: 'Size', width: 10, key: 'size', style: border },
	{ header: 'Quantity', width: 10, key: 'quantity', style: border },
	{ width: 4 },
	{ header: 'Name', width: 30, key: 'name2', style: border },
	{ header: 'Size', width: 10, key: 'size2', style: border },
	{ header: 'Quantity', width: 10, key: 'quantity2', style: border }
];

const KitchenPortionStats = () => {
	const location = useLocation();
	const dispatch = useDispatch();
	const userKitchen = useUserKitchens();
	const [requestTypefiltersMenuAnchorEl, setRequestTypefiltersMenuAnchorEl] = useState<null | HTMLElement>(null);
	const [filtersCheck, setFiltersCheck] = useState({ subscriptions: true, businesses: false, charity: false });
	const isRequestTypeFilterMenuOpened = Boolean(requestTypefiltersMenuAnchorEl);

	const searchParams = new URLSearchParams(location.search);
	const [filters, setFilters] = useState<PortionStatsFilters>({
		day: {
			gte: format('yyyy-MM-dd')(Date.now()),
			lte: format('yyyy-MM-dd')(Date.now())
		},
		country: resolveCountryFromKitchen((userKitchen && userKitchen[0]) || Kitchen.BH1),
		kitchen: (userKitchen && userKitchen[0]) || Kitchen.BH1,
		brand: Brand.CALO,
		...JSON.parse(searchParams.get('filters') || `{}`)
	});

	const {
		data: statsData,
		error,
		isLoading
	} = useQuery<any, Error, { data: FoodStatsComponent[]; charity: FoodStatsComponent[]; business: FoodStatsComponent[] }>(
		['/stats/kitchen-portion', filters],
		getListWithParams,
		{
			onSuccess: () => {
				searchParams.set('filters', JSON.stringify(filters));
				history.push({
					pathname: location.pathname,
					search: searchParams.toString()
				});
			}
		}
	);

	const filteredStatsData: FoodStatsComponent[] = useMemo(() => {
		const data = [];
		if (filtersCheck.subscriptions) {
			data.push(statsData ? statsData?.data : []);
		}
		if (filtersCheck.businesses) {
			data.push(statsData ? statsData?.business : []);
		}
		if (filtersCheck.charity) {
			data.push(statsData ? statsData?.charity : []);
		}

		return flatten(data);
	}, [filtersCheck, statsData]);
	const summedFoodData = Object.values(groupedAllMeals(filteredStatsData)) as FoodStatsComponent[];

	const onExport = useCallback(async () => {
		if (!summedFoodData) {
			return;
		}
		const workbook = new ExcelJS.Workbook();

		const worksheet = workbook.addWorksheet('meal-stats', {
			pageSetup: { fitToPage: true, orientation: 'portrait' }
		});
		worksheet.mergeCells('A1', 'G1');
		worksheet.mergeCells('A2', 'G2');
		worksheet.getRow(3).values = ['Name', 'Size', 'Quantity', ' ', 'Name', 'Size', 'Quantity'];
		worksheet.columns = columns;
		worksheet.getCell('A1').value = `production date: ${filters.day.gte} - ${filters.day.lte}`;
		worksheet.getCell('A2').value = `export day: ${format('dd-MM-yyyy')(Date.now())} - ${format('hh:mm aa')(Date.now())}`;
		worksheet.getCell('A1').font = { color: { argb: '0000' }, bold: true, size: 18 };
		worksheet.getCell('A1').alignment = {
			vertical: 'middle',
			horizontal: 'center'
		};
		worksheet.getCell('A2').font = { color: { argb: '0000' }, bold: true, size: 18 };
		worksheet.getCell('A2').alignment = {
			vertical: 'middle',
			horizontal: 'center'
		};
		for (const row of chunk(summedFoodData, 2)) {
			worksheet.addRow(
				{
					name: row[0].name,
					size: row[0].size,
					quantity: row[0].quantity,
					name2: row[1] ? row[1].name : '',
					size2: row[1] ? row[1].size : '',
					quantity2: row[1] ? row[1].quantity : ''
				},
				''
			);
		}

		const buffer = await workbook.xlsx.writeBuffer();
		const fileType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
		const fileExtension = '.xlsx';
		const blob = new Blob([buffer], { type: fileType });
		saveAs(blob, 'meal-stats' + fileExtension);
	}, [summedFoodData, filtersCheck]);

	const roles = useUserRoles();

	const StyledTableCell = styled(TableCell)(() => ({
		[`&.${tableCellClasses.head}`]: {
			border: 'none',
			fontFamily: 'Roboto',
			fontWeight: 600,
			fontSize: '12px',
			lineHeight: '14px'
		},
		[`&.${tableCellClasses.body}`]: {
			border: 'none',
			justifyContent: 'space-between',
			fontFamily: 'Roboto',
			fontSize: '16px',
			lineHeight: '19px',
			textTransform: 'capitalize'
		}
	}));

	return (
		<>
			<Card
				variant="outlined"
				sx={{
					width: 'full',
					mb: '14px',
					border: 'none',
					borderRadius: '8px',
					paddingBottom: '4px',
					[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
						flexDirection: 'column'
					}
				}}
			>
				<Box
					sx={{
						display: 'flex',
						padding: 2,
						[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
							flexDirection: 'column'
						}
					}}
				>
					<Stack
						display="flex"
						width="100%"
						flexDirection={'row'}
						justifyContent={'space-between'}
						sx={{
							[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
								flexDirection: 'column',
								textAlign: 'center'
							}
						}}
					>
						<Stack
							display={'flex'}
							flexDirection={'row'}
							sx={{
								width: '60%',
								[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
									flexDirection: 'column',
									textAlign: 'center',
									width: '100%'
								}
							}}
						>
							<Typography
								variant="h3"
								sx={{
									[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
										flexDirection: 'column',
										textAlign: 'center'
									},
									my: 'auto',
									textTransform: 'uppercase',
									textAlign: 'left',
									fontSize: '33px',
									lineHeight: '40px',
									fontFamily: caloTheme.typography.fontFamily,
									fontWeight: 400,
									color: caloTheme.palette.neutral900
								}}
							>
								Meal Stats
							</Typography>
						</Stack>
						<Stack display={'flex'} flexDirection={'row'}>
							<Button
								aria-label="filter-subscription-list"
								sx={{
									cursor: 'pointer',
									my: 'auto',
									'&:hover': {
										backgroundColor: 'white',
										borderColor: 'none'
									},
									color: caloTheme.palette.primary500,
									borderColor: caloTheme.palette.primary500,
									[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
										justifyItems: 'center',
										margin: 'auto',
										marginTop: 4,
										width: 'auto'
									}
								}}
								onClick={() => dispatch(toggleUISettings())}
							>
								{<Icon name="filter" size={6} className="w-10 h-18" />}
							</Button>

							<Button
								variant="outlined"
								disabled={summedFoodData.length === 0 || isLoading}
								aria-label="Download-subscription-list"
								sx={{
									textTransform: 'none',
									height: '45px',
									ml: 2,
									lineHeight: '17px',
									fontWeight: 600,
									fontSize: '14px',
									borderRadius: '8px',
									padding: '14px 20px 14px 20px',
									color: caloTheme.palette.primary500,
									borderColor: caloTheme.palette.primary500,
									'&:hover': {
										backgroundColor: caloTheme.palette.primary100,
										borderColor: caloTheme.palette.primary500
									},
									[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
										justifyItems: 'center',
										margin: 'auto',
										marginTop: 4,
										width: 'auto'
									}
								}}
								onClick={() => onExport()}
								startIcon={
									<Icon
										name="importFile"
										size={6}
										style={{
											stroke:
												summedFoodData.length === 0 || isLoading ? caloTheme.palette.neutral300 : caloTheme.palette.primary500
										}}
									/>
								}
							>
								Download
							</Button>
						</Stack>
					</Stack>
				</Box>
			</Card>
			<Card
				variant="outlined"
				sx={{
					width: 'full',
					mb: '14px',
					border: 'none',
					borderRadius: '8px',
					paddingBottom: '4px',
					[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
						flexDirection: 'column'
					}
				}}
			>
				<Box overflow="auto" width="100%" sx={{ padding: 2 }}>
					<Stack display={'flex'} flexDirection={'row'} justifyContent={'space-between'} sx={{ paddingRight: 2 }}>
						<Typography
							variant="h6"
							sx={{
								py: 2,
								textAlign: 'start',
								fontFamily: caloTheme.typography.fontFamily,
								fontWeight: 600,
								lineHeight: '23px',
								color: caloTheme.palette.neutral900,
								fontSize: '19px'
							}}
						>
							Meals
						</Typography>
						<Button
							onClick={(event) => {
								!requestTypefiltersMenuAnchorEl && setRequestTypefiltersMenuAnchorEl(event.currentTarget);
							}}
							variant="outlined"
							startIcon={
								<>
									<Typography
										style={{
											fontFamily: 'Roboto',
											fontSize: '18px',
											fontWeight: 400,
											lineHeight: '20px',
											textAlign: 'start',
											width: '70px'
										}}
									>
										Types
									</Typography>
									<Typography
										style={{ fontSize: '12px', margin: 'auto' }}
										sx={{
											fontFamily: 'Roboto',
											fontSize: '12px',
											fontWeight: 400,
											lineHeight: '20px',
											letterSpacing: '2%',
											textAlign: 'center',
											color: 'white',
											width: '20px',
											height: '20px',
											borderRadius: '120px',
											backgroundColor: caloTheme.palette.primary500
										}}
									>
										{Object.values(filtersCheck).filter(Boolean).length}
									</Typography>
								</>
							}
							endIcon={
								<>
									<ArrowDropDownIcon />
								</>
							}
							sx={{
								textTransform: 'capitalize',
								borderRadius: '8px',
								fontSize: '16px',
								width: '141px',
								color: caloTheme.palette.neutral900,
								height: '44px',
								borderColor: caloTheme.palette.neutral900
							}}
						>
							<Select
								id="demo-simple-select"
								open={isRequestTypeFilterMenuOpened}
								onClose={() => setRequestTypefiltersMenuAnchorEl(null)}
								label="session"
								sx={{ textTransform: 'capitalize', fontSize: '16px', visibility: 'hidden', width: 0, height: 0 }}
							>
								<MenuItem sx={{ fontWeight: 600 }}>
									<FormControlLabel
										control={
											<Checkbox
												checked={filtersCheck.businesses}
												disabled={filtersCheck.businesses && Object.values(filtersCheck).filter(Boolean).length === 1}
												onChange={() => setFiltersCheck({ ...filtersCheck, businesses: !filtersCheck.businesses })}
											/>
										}
										label="Businesses"
									/>
								</MenuItem>
								<MenuItem sx={{ fontWeight: 600 }}>
									<FormControlLabel
										control={
											<Checkbox
												checked={filtersCheck.subscriptions}
												disabled={filtersCheck.subscriptions && Object.values(filtersCheck).filter(Boolean).length === 1}
												onChange={() => setFiltersCheck({ ...filtersCheck, subscriptions: !filtersCheck.subscriptions })}
											/>
										}
										label="Subscriptions"
									/>
								</MenuItem>
								<MenuItem sx={{ fontWeight: 600 }}>
									<FormControlLabel
										control={
											<Checkbox
												checked={filtersCheck.charity}
												disabled={filtersCheck.charity && Object.values(filtersCheck).filter(Boolean).length === 1}
												onChange={() => setFiltersCheck({ ...filtersCheck, charity: !filtersCheck.charity })}
											/>
										}
										label="Charity"
									/>
								</MenuItem>
							</Select>
						</Button>
					</Stack>

					{isLoading ? (
						<Stack sx={{ width: '100%', justifyContent: 'center' }}>
							<CaloLoader />
						</Stack>
					) : (
						<>
							<Table
								sx={{
									marginY: '4px',
									minHeight: '120px',
									overflow: 'auto',
									width: '100%',
									[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
										flexDirection: 'column'
									}
								}}
							>
								<TableHead
									style={{ borderRadius: '8px' }}
									sx={{
										backgroundColor: caloTheme.palette.neutral50,
										color: 'black',
										flexWrap: 0,
										justifyContent: 'space-between',
										width: '100%',
										borderRadius: '8px'
									}}
								>
									<TableRow
										sx={{
											backgroundColor: caloTheme.palette.neutral50,
											color: 'black',
											width: '100%',
											flexWrap: 0,
											justifyContent: 'space-between'
										}}
									>
										<StyledTableCell style={{ width: '46%', borderTopLeftRadius: '8px', borderBottomLeftRadius: '8px' }}>
											Name
										</StyledTableCell>
										<StyledTableCell style={{ width: '27%' }}>Size</StyledTableCell>
										<StyledTableCell style={{ width: '27%', borderTopRightRadius: '8px', borderBottomRightRadius: '8px' }}>
											Quantity
										</StyledTableCell>
									</TableRow>
								</TableHead>
								{summedFoodData && summedFoodData.length === 0 ? (
									<StyledTableCell style={{ border: 0 }} colSpan={6}>
										<Typography
											sx={{
												mt: 3,
												textAlign: 'center',
												width: 'full',
												fontSize: '24px',
												color: caloTheme.palette.neutral400
											}}
										>
											No Stats
										</Typography>
									</StyledTableCell>
								) : (
									<TableBody>
										{sortBy(summedFoodData, 'name')?.map((row) => (
											<TableRow key={uuid()}>
												<StyledTableCell style={{ fontWeight: 600 }}>{row.name}</StyledTableCell>
												<StyledTableCell style={{ fontWeight: 400 }}>{row.size}</StyledTableCell>
												<StyledTableCell style={{ fontWeight: 400 }}>{row.quantity}</StyledTableCell>
											</TableRow>
										))}
									</TableBody>
								)}
							</Table>
						</>
					)}
				</Box>
			</Card>

			<Settings onFilter={setFilters} filters={filters} />
		</>
	);
};

export default KitchenPortionStats;
