import { FoodStatsFilters } from '@calo/dashboard-types';
import { Country, DeliveryTime, Kitchen } from '@calo/types';
import DateRangePicker from '@wojtekmaj/react-daterange-picker';
import { toggleUISettings } from 'actions';
import { QuickView, Select, Select2 } from 'components';
import { format, parseISO } from 'date-fns/fp';
import { getAccessibleCountries, getKitchenOptions } from 'lib';
import { useUserKitchens } from 'lib/hooks';
import { AppState } from 'lib/interfaces';
import { omit } from 'lodash-es';
import { useDispatch, useSelector } from 'react-redux';

interface SettingsProps {
	onFilter: (values: FoodStatsFilters) => any;
	filters: FoodStatsFilters;
}

const Settings = ({ filters, onFilter }: SettingsProps) => {
	const { settingsVisible } = useSelector((state: AppState) => ({
		settingsVisible: state.ui.settings
	}));

	const userKitchens: string[] = useUserKitchens();
	const dispatch = useDispatch();

	return (
		<QuickView visible={settingsVisible} onClose={() => dispatch(toggleUISettings())}>
			<section className="section">
				<h5 className="title is-5">Filters</h5>

				<Select2
					label="Country"
					value={filters.country}
					onChange={(data) =>
						onFilter({
							...filters,
							country: data.target.value as Country,
							kitchen: data.target.value
								? (userKitchens.find((k) => k.includes(data.target.value)) as Kitchen)
								: ('' as Kitchen) || undefined
						})
					}
					options={getAccessibleCountries(userKitchens).map((c) => ({
						value: c,
						label: Country[c]
					}))}
				/>
				<Select2
					label="Kitchen"
					value={filters.kitchen}
					onChange={(data) => onFilter({ ...filters, kitchen: data.target.value as Kitchen })}
					options={getKitchenOptions(userKitchens, filters.country!)}
					disabled={Object.values(Kitchen).filter((r) => r.includes(filters.country!)).length === 0 || !filters.country}
				/>
				<Select
					label="Delivery Time"
					value={filters.time}
					onChange={(v: any) =>
						onFilter({
							...omit(filters, ['time']),
							...(v.value && {
								time: v.value
							})
						})
					}
					options={[
						{
							value: '',
							label: 'Any'
						},
						{
							value: DeliveryTime.morning,
							label: 'Morning'
						},
						{
							value: DeliveryTime.evening,
							label: 'Evening'
						}
					]}
				/>
				<div className="field">
					<label className="label">Date range</label>
					<div className="control is-clearfix">
						<DateRangePicker
							clearIcon={null}
							onChange={(dates: any) =>
								onFilter({
									...filters,
									day: {
										gte: format('yyyy-MM-dd')(dates[0]),
										lte: format('yyyy-MM-dd')(dates[1])
									}
								})
							}
							selectRange
							returnValue="range"
							value={[parseISO(filters.day.gte), parseISO(filters.day.lte)]}
						/>
					</div>
				</div>
			</section>
		</QuickView>
	);
};

export default Settings;
