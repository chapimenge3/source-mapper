import { useCallback, useMemo, useState } from 'react';

import { format } from 'date-fns/fp';
import ExcelJS, { Column, Style } from 'exceljs';
import { saveAs } from 'file-saver';
import { flatten, sortBy } from 'lodash-es';
import { useQuery } from 'react-query';
import { useDispatch } from 'react-redux';
import { Link, useLocation } from 'react-router-dom';
import { v4 as uuid } from 'uuid';

import { FoodComponentStation, FoodStatsFilters, MeasurementUnit, Permission } from '@calo/dashboard-types';
import { Brand, Kitchen } from '@calo/types';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import {
	Box,
	Button,
	Card,
	Checkbox,
	FormControlLabel,
	MenuItem,
	Select,
	Stack,
	Switch,
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableRow,
	ThemeProvider,
	Typography,
	styled,
	tableCellClasses
} from '@mui/material';

import { getListWithParams, toggleUISettings } from 'actions';
import { caloTheme } from 'assets/images/theme/calo';
import { CaloLoader, Icon } from 'components';
import { groupedAllFoodComponents, resolveCountryFromKitchen } from 'lib';
import { theme } from 'lib/componentStyles';
import { Routes } from 'lib/enums';
import history from 'lib/history';
import { useUserKitchens, useUserRoles } from 'lib/hooks';
import { FoodComponent } from 'lib/interfaces';
import Settings from './Settings';

export interface StatsFoodComponent extends FoodComponent {
	quantity: number;
	weightAsChildComponent?: number;
	stats: {
		quantity: number;
		cookedWeight: number;
		rawWeight: number;
		childQuantity: number;
		childWeight: number;
		removedQuantity: number;
		removedCookedWeight: number;
		removedRawWeight: number;
	};
}

const border: Partial<Style> = {
	font: { size: 12 },
	border: {
		top: { style: 'thin', color: { argb: 'D3D3D3' } },
		left: { style: 'thin', color: { argb: 'D3D3D3' } },
		bottom: { style: 'thin', color: { argb: 'D3D3D3' } },
		right: { style: 'thin', color: { argb: 'D3D3D3' } }
	}
};

const columns: Array<Partial<Column>> = [
	{ width: 2, style: border },
	{ header: 'Name', width: 25, key: 'name', style: border },
	{ header: 'Country', width: 8, key: 'country', style: border },
	{ header: 'Brand', width: 8, key: 'brand', style: border },
	{ header: 'Weight', width: 10, key: 'weight', style: border },
	{ header: 'Cooked weight', width: 15, key: 'cookedWeight', style: border },
	{ header: 'Child weight', width: 15, key: 'childWeight', style: border },
	{ header: 'Unit', width: 8, key: 'unit', style: border },
	{ header: 'Cooked weight in measurement unit', width: 15, key: 'cookedWMU', style: border },
	{ header: 'Measurement Unit', width: 12, key: 'measurementUnit', style: border },
	{ header: '*', width: 2, key: '*', style: border },
	{ header: '_', width: 2, key: '_', style: border },
	{ header: 'C', width: 2, key: 'C', style: border },
	{ header: 'D', width: 2, key: 'D', style: border }
];

const getRowData = (row: StatsFoodComponent) => ({
	name: row.name.en,
	country: row.country,
	brand: row.brand,
	weight: getTotalRawWeight(row).toString(),
	cookedWeight: getTotalCookedWeight(row, false).toString(),
	childWeight: Math.ceil(row.stats.childWeight).toString(),
	unit: row.measurementUnit === MeasurementUnit.ml ? MeasurementUnit.ml : MeasurementUnit.g,
	cookedWMU: getTotalCookedWeight(row, true).toString(),
	measurementUnit: row.measurementUnit
});

const getTotalRawWeight = (row: StatsFoodComponent) => Math.ceil(row.stats.rawWeight - row.stats.removedRawWeight);
const getTotalCookedWeight = (row: StatsFoodComponent, switchUnit: boolean) =>
	switchUnit
		? Math.round((row.stats.quantity - row.stats.removedQuantity + Number.EPSILON) * 100) / 100
		: Math.ceil(row.stats.cookedWeight - row.stats.removedCookedWeight);

const KitchenComponentStats = () => {
	const userKitchen = useUserKitchens();
	const location = useLocation();
	const searchParams = new URLSearchParams(location.search);
	const [switchUnit, setSwitchUnit] = useState<boolean>(false);

	const [requestTypefiltersMenuAnchorEl, setRequestTypefiltersMenuAnchorEl] = useState<null | HTMLElement>(null);
	const [filtersCheck, setFiltersCheck] = useState({ subscriptions: true, businesses: false, charity: false });
	const isRequestTypeFilterMenuOpened = Boolean(requestTypefiltersMenuAnchorEl);
	const dispatch = useDispatch();

	const [filters, setFilters] = useState<FoodStatsFilters>({
		day: {
			gte: format('yyyy-MM-dd')(Date.now()),
			lte: format('yyyy-MM-dd')(Date.now())
		},
		brand: Brand.CALO,
		country: resolveCountryFromKitchen((userKitchen && userKitchen[0]) || Kitchen.BH1),
		kitchen: (userKitchen && userKitchen[0]) || Kitchen.BH1,
		...JSON.parse(searchParams.get('filters') || `{}`)
	});

	const roles = useUserRoles();
	const { data: statsData, isLoading } = useQuery<
		any,
		Error,
		{
			data: StatsFoodComponent[];
			charity: StatsFoodComponent[];
			business: StatsFoodComponent[];
		}
	>(['/stats/kitchen-food', filters], getListWithParams, {
		onSuccess: () => {
			searchParams.set('filters', JSON.stringify(filters));
			history.push({
				pathname: location.pathname,
				search: searchParams.toString()
			});
		}
	});

	const filteredStatsData: StatsFoodComponent[] = useMemo(() => {
		const data = [];
		if (filtersCheck.subscriptions) {
			data.push(statsData ? statsData?.data : []);
		}
		if (filtersCheck.businesses) {
			data.push(statsData ? statsData?.business : []);
		}
		if (filtersCheck.charity) {
			data.push(statsData ? statsData?.charity : []);
		}

		return flatten(data);
	}, [filtersCheck, statsData]);

	const summedComponentData = Object.values(groupedAllFoodComponents(filteredStatsData)) as StatsFoodComponent[];

	const onExport = useCallback(async () => {
		if (!summedComponentData) {
			return;
		}
		const workbook = new ExcelJS.Workbook();

		const dData = sortBy(summedComponentData, 'name.en').map((food) => food);
		const ws = workbook.addWorksheet('all-stats', {
			pageSetup: { fitToWidth: 1, fitToHeight: 0, pageOrder: 'overThenDown', orientation: 'portrait' }
		});
		const footer = '&C &15 All Stations Page (&P) of (&N)';
		ws.headerFooter.oddFooter = ws.headerFooter.evenFooter = footer;

		ws.mergeCells('A1', 'M1');
		ws.mergeCells('A2', 'M2');
		ws.mergeCells('A3', 'M3');
		ws.getRow(4).values = [
			' ',
			'Name',
			'Country',
			'Brand',
			'Raw Weight',
			'Cooked weight',
			'Child weight',
			'Unit',
			'Cooked weight in measurement unit',
			'Measurement Unit',
			'*',
			'_',
			'C',
			'D',
			''
		];
		ws.columns = columns;
		ws.addRows(dData.map(getRowData));
		ws.getCell('A1').value = 'All Stations';
		ws.getCell('A2').value = `production date: ${filters.day.gte} - ${filters.day.lte}`;
		ws.getCell('A3').value = `export date: ${format('dd-MM-yyyy')(Date.now())} - ${format('hh:mm aa')(Date.now())}`;
		ws.getCell('A1').font = { color: { argb: '0000' }, bold: true, size: 18 };
		ws.getCell('A1').alignment = {
			vertical: 'middle',
			horizontal: 'center'
		};
		ws.getCell('A2').font = { color: { argb: '0000' }, bold: true, size: 18 };
		ws.getCell('A2').alignment = {
			vertical: 'middle',
			horizontal: 'center'
		};
		ws.getCell('A3').font = { color: { argb: '0000' }, bold: true, size: 18 };
		ws.getCell('A3').alignment = {
			vertical: 'middle',
			horizontal: 'center'
		};
		for (const [key, value] of Object.entries(FoodComponentStation)) {
			const rows = sortBy(summedComponentData, 'name.en').filter((r) => r.cookingStation?.includes(key as FoodComponentStation));
			if (rows.length > 0) {
				const ws = workbook.addWorksheet(`${value}-stats`, {
					pageSetup: { fitToWidth: 1, fitToHeight: 0, pageOrder: 'overThenDown', orientation: 'portrait' }
				});
				const footer = `&C &15 ${value}-station Page (&P) of (&N)`;
				ws.headerFooter.oddFooter = ws.headerFooter.evenFooter = footer;
				ws.mergeCells('A1', 'M1');
				ws.mergeCells('A2', 'M2');
				ws.mergeCells('A3', 'M3');
				ws.getRow(4).values = [
					' ',
					'Name',
					'Country',
					'Brand',
					'Raw Weight',
					'Cooked weight',
					'Child weight',
					'Unit',
					'Cooked weight in measurement unit',
					'Measurement Unit',
					'*',
					'_',
					'C',
					'D',
					''
				];
				ws.columns = columns;
				ws.addRows(rows.map(getRowData));
				ws.getCell('A1').value = `${value}`;
				ws.getCell('A2').value = `production date: ${filters.day.gte} - ${filters.day.lte}`;
				ws.getCell('A3').value = `export day: ${format('dd-MM-yyyy')(Date.now())} - ${format('hh:mm aa')(Date.now())}`;
				ws.getCell('A1').font = { color: { argb: '0000' }, bold: true, size: 18 };
				ws.getCell('A1').alignment = {
					vertical: 'middle',
					horizontal: 'center'
				};
				ws.getCell('A2').font = { color: { argb: '0000' }, bold: true, size: 18 };
				ws.getCell('A2').alignment = {
					vertical: 'middle',
					horizontal: 'center'
				};
				ws.getCell('A3').font = { color: { argb: '0000' }, bold: true, size: 18 };
				ws.getCell('A3').alignment = {
					vertical: 'middle',
					horizontal: 'center'
				};
			}
		}

		const buffer = await workbook.xlsx.writeBuffer();
		const fileType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
		const fileExtension = '.xlsx';
		const blob = new Blob([buffer], { type: fileType });
		saveAs(blob, 'component-stats' + fileExtension);
	}, [summedComponentData, filtersCheck]);

	const StyledTableCell = styled(TableCell)(() => ({
		[`&.${tableCellClasses.head}`]: {
			border: 'none',
			fontFamily: 'Roboto',
			fontWeight: 600,
			fontSize: '12px',
			lineHeight: '14px'
		},
		[`&.${tableCellClasses.body}`]: {
			border: 'none',
			justifyContent: 'space-between',
			fontFamily: 'Roboto',
			fontSize: '16px',
			lineHeight: '19px',
			textTransform: 'none'
		}
	}));

	return (
		<>
			<Card
				variant="outlined"
				sx={{
					width: 'full',
					mb: '14px',
					border: 'none',
					borderRadius: '8px',
					paddingBottom: '4px',
					[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
						flexDirection: 'column'
					}
				}}
			>
				<Box
					sx={{
						display: 'flex',
						padding: 2,
						[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
							flexDirection: 'column'
						}
					}}
				>
					<Stack
						display="flex"
						width="100%"
						flexDirection={'row'}
						justifyContent={'space-between'}
						sx={{
							[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
								flexDirection: 'column',
								textAlign: 'center'
							}
						}}
					>
						<Stack
							display={'flex'}
							flexDirection={'row'}
							sx={{
								width: '60%',
								[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
									flexDirection: 'column',
									textAlign: 'center',
									width: '100%'
								}
							}}
						>
							<Typography
								variant="h3"
								sx={{
									[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
										flexDirection: 'column',
										textAlign: 'center'
									},
									my: 'auto',
									textTransform: 'uppercase',
									textAlign: 'left',
									fontSize: '33px',
									lineHeight: '40px',
									fontFamily: caloTheme.typography.fontFamily,
									fontWeight: 400,
									color: caloTheme.palette.neutral900
								}}
							>
								Component Stats
							</Typography>
						</Stack>
						<Stack display={'flex'} flexDirection={'row'}>
							<Button
								aria-label="filter-subscription-list"
								sx={{
									cursor: 'pointer',
									my: 'auto',
									'&:hover': {
										backgroundColor: 'white',
										borderColor: 'none'
									},
									color: caloTheme.palette.primary500,
									borderColor: caloTheme.palette.primary500,
									[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
										justifyItems: 'center',
										margin: 'auto',
										marginTop: 4,
										width: 'auto'
									}
								}}
								onClick={() => dispatch(toggleUISettings())}
							>
								{<Icon name="filter" size={6} className="w-10 h-18" />}
							</Button>
							{roles.includes(Permission.EXPORT_FOOD_STATS) && (
								<Button
									variant="outlined"
									disabled={filteredStatsData.length === 0 || isLoading}
									aria-label="Download-subscription-list"
									sx={{
										textTransform: 'none',
										height: '45px',
										ml: 2,
										lineHeight: '17px',
										fontWeight: 600,
										fontSize: '14px',
										borderRadius: '8px',
										padding: '14px 20px 14px 20px',
										color: caloTheme.palette.primary500,
										borderColor: caloTheme.palette.primary500,
										'&:hover': {
											backgroundColor: caloTheme.palette.primary100,
											borderColor: caloTheme.palette.primary500
										},
										[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
											justifyItems: 'center',
											margin: 'auto',
											marginTop: 4,
											width: 'auto'
										}
									}}
									onClick={() => onExport()}
									startIcon={
										<Icon
											name="importFile"
											size={6}
											style={{
												stroke:
													filteredStatsData.length === 0 || isLoading
														? caloTheme.palette.neutral300
														: caloTheme.palette.primary500
											}}
										/>
									}
								>
									Download
								</Button>
							)}
						</Stack>
					</Stack>
				</Box>
			</Card>
			<Card
				variant="outlined"
				sx={{
					width: 'full',
					mb: '14px',
					border: 'none',
					borderRadius: '8px',
					paddingBottom: '4px',
					[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
						flexDirection: 'column'
					}
				}}
			>
				<Box overflow="auto" width="100%" sx={{ padding: 2 }}>
					<Stack display={'flex'} flexDirection={'row'} justifyContent={'space-between'} sx={{ paddingRight: 2 }}>
						<Typography
							variant="h6"
							sx={{
								py: 2,
								textAlign: 'start',
								fontFamily: caloTheme.typography.fontFamily,
								fontWeight: 600,
								lineHeight: '23px',
								color: caloTheme.palette.neutral900,
								fontSize: '19px'
							}}
						>
							Food Components
						</Typography>
						<Button
							onClick={(event) => {
								!requestTypefiltersMenuAnchorEl && setRequestTypefiltersMenuAnchorEl(event.currentTarget);
							}}
							variant="outlined"
							startIcon={
								<>
									<Typography
										style={{
											fontFamily: 'Roboto',
											fontSize: '18px',
											fontWeight: 400,
											lineHeight: '20px',
											textAlign: 'start',
											width: '70px'
										}}
									>
										Types
									</Typography>
									<Typography
										style={{ fontSize: '12px', margin: 'auto' }}
										sx={{
											fontFamily: 'Roboto',
											fontSize: '12px',
											fontWeight: 400,
											lineHeight: '20px',
											letterSpacing: '2%',
											textAlign: 'center',
											color: 'white',
											width: '20px',
											height: '20px',
											borderRadius: '120px',
											backgroundColor: caloTheme.palette.primary500
										}}
									>
										{Object.values(filtersCheck).filter(Boolean).length}
									</Typography>
								</>
							}
							endIcon={
								<>
									<ArrowDropDownIcon />
								</>
							}
							sx={{
								textTransform: 'capitalize',
								borderRadius: '8px',
								fontSize: '16px',
								width: '141px',
								color: caloTheme.palette.neutral900,
								height: '44px',
								borderColor: caloTheme.palette.neutral900
							}}
						>
							<Select
								id="demo-simple-select"
								open={isRequestTypeFilterMenuOpened}
								onClose={() => setRequestTypefiltersMenuAnchorEl(null)}
								label="session"
								sx={{ textTransform: 'capitalize', fontSize: '16px', visibility: 'hidden', width: 0, height: 0 }}
							>
								<MenuItem sx={{ fontWeight: 600 }}>
									<FormControlLabel
										control={
											<Checkbox
												checked={filtersCheck.businesses}
												disabled={filtersCheck.businesses && Object.values(filtersCheck).filter(Boolean).length === 1}
												onChange={() => setFiltersCheck({ ...filtersCheck, businesses: !filtersCheck.businesses })}
											/>
										}
										label="Businesses"
									/>
								</MenuItem>
								<MenuItem sx={{ fontWeight: 600 }}>
									<FormControlLabel
										control={
											<Checkbox
												checked={filtersCheck.subscriptions}
												disabled={filtersCheck.subscriptions && Object.values(filtersCheck).filter(Boolean).length === 1}
												onChange={() => setFiltersCheck({ ...filtersCheck, subscriptions: !filtersCheck.subscriptions })}
											/>
										}
										label="Subscriptions"
									/>
								</MenuItem>
								<MenuItem sx={{ fontWeight: 600 }}>
									<FormControlLabel
										control={
											<Checkbox
												checked={filtersCheck.charity}
												disabled={filtersCheck.charity && Object.values(filtersCheck).filter(Boolean).length === 1}
												onChange={() => setFiltersCheck({ ...filtersCheck, charity: !filtersCheck.charity })}
											/>
										}
										label="Charity"
									/>
								</MenuItem>
							</Select>
						</Button>
					</Stack>

					{isLoading ? (
						<Stack sx={{ width: '100%', justifyContent: 'center' }}>
							<CaloLoader />
						</Stack>
					) : (
						<>
							<Table
								sx={{
									marginY: '4px',
									minHeight: '120px',
									overflow: 'auto',
									width: '100%',
									[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
										flexDirection: 'column'
									}
								}}
							>
								<TableHead
									style={{ borderRadius: '8px' }}
									sx={{
										backgroundColor: caloTheme.palette.neutral50,
										color: 'black',
										flexWrap: 0,
										justifyContent: 'space-between',
										width: '100%',
										borderRadius: '8px'
									}}
								>
									<TableRow
										sx={{
											backgroundColor: caloTheme.palette.neutral50,
											color: 'black',
											width: '100%',
											flexWrap: 0,
											justifyContent: 'space-between'
										}}
									>
										<StyledTableCell style={{ width: '20%', borderTopLeftRadius: '8px', borderBottomLeftRadius: '8px' }}>
											Name
										</StyledTableCell>
										<StyledTableCell style={{ width: '10%' }}>Country</StyledTableCell>
										<StyledTableCell style={{ width: '10%' }}>Kitchen</StyledTableCell>
										<StyledTableCell style={{ width: '10%' }}>Raw Weight</StyledTableCell>
										<StyledTableCell style={{ width: '10%' }}>Cooked Weight</StyledTableCell>
										<StyledTableCell style={{ width: '10%' }}>Child Weight</StyledTableCell>
										<StyledTableCell style={{ width: '10%' }}>Removed Raw Weight</StyledTableCell>
										<StyledTableCell style={{ width: '10%' }}>Removed Cooked Weight</StyledTableCell>
										<StyledTableCell style={{ width: '10%' }}>Measurement Unit</StyledTableCell>
										<StyledTableCell style={{ width: '10%', borderTopRightRadius: '8px', borderBottomRightRadius: '8px' }}>
											<ThemeProvider theme={theme}>
												<Box display={'flex'} flexDirection={'row'}>
													<Typography
														sx={{
															color: caloTheme.palette.neutral900,
															fontSize: '12px',
															lineHeight: '14px',
															mx: '6px',
															mt: switchUnit ? '4px' : '12px',
															fontFamily: 'Roboto',
															fontWeight: 600
														}}
													>
														{switchUnit ? 'All Units' : 'gram/ml'}
													</Typography>
													<Switch
														onChange={() => {
															setSwitchUnit(!switchUnit);
														}}
														sx={{ color: 'white' }}
														checked={switchUnit}
													/>
												</Box>
											</ThemeProvider>
										</StyledTableCell>
									</TableRow>
								</TableHead>
								{summedComponentData && summedComponentData.length === 0 ? (
									<StyledTableCell style={{ border: 0 }} colSpan={12}>
										<Typography
											sx={{
												mt: 3,
												textAlign: 'center',
												width: 'full',
												fontSize: '24px',
												color: caloTheme.palette.neutral400
											}}
										>
											No Stats
										</Typography>
									</StyledTableCell>
								) : (
									<TableBody>
										{summedComponentData.map((row) => (
											<TableRow key={uuid()}>
												<StyledTableCell style={{ fontWeight: 600, textTransform: 'capitalize' }}>
													{roles.includes(Permission.VIEW_COMPONENT_SCALED_RECIPE) ? (
														<Link to={{ pathname: Routes.kitchenComponentScaledRecipe.replace(':id', row.id) }}>
															{row.name.en}
														</Link>
													) : (
														row.name.en
													)}
												</StyledTableCell>
												<StyledTableCell style={{ fontWeight: 400 }}>{row.country}</StyledTableCell>
												<StyledTableCell style={{ fontWeight: 400 }}>{row.kitchen}</StyledTableCell>
												<StyledTableCell style={{ fontWeight: 400 }}>{getTotalRawWeight(row)}</StyledTableCell>
												<StyledTableCell style={{ fontWeight: 400 }}>{getTotalCookedWeight(row, switchUnit)}</StyledTableCell>
												<StyledTableCell style={{ fontWeight: 400 }}>{Math.ceil(row.stats.childWeight)}</StyledTableCell>
												<StyledTableCell style={{ fontWeight: 400 }}>{Math.ceil(row.stats.removedRawWeight)}</StyledTableCell>
												<StyledTableCell style={{ fontWeight: 400 }}>
													{switchUnit
														? Math.round((row.stats.removedQuantity + +Number.EPSILON) * 100) / 100
														: Math.ceil(row.stats.removedCookedWeight)}
												</StyledTableCell>
												<StyledTableCell colSpan={2} style={{ fontWeight: 400 }}>
													{switchUnit
														? row.measurementUnit
														: row.measurementUnit === MeasurementUnit.ml
															? MeasurementUnit.ml
															: MeasurementUnit.g}
												</StyledTableCell>
											</TableRow>
										))}
									</TableBody>
								)}
							</Table>
						</>
					)}
				</Box>
			</Card>
			<Settings onFilter={setFilters} filters={filters} />
		</>
	);
};

export default KitchenComponentStats;
