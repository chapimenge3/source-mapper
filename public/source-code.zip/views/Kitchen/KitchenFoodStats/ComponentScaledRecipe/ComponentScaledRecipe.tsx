import { FoodStatsFilters, MeasurementUnit } from '@calo/dashboard-types';
import { Kitchen } from '@calo/types';
import { getListWithParams } from 'actions';
import { Button, ComponentMethod } from 'components';
import { format } from 'date-fns/fp';
import ExcelJS, { Column, Style } from 'exceljs';
import { saveAs } from 'file-saver';
import { resolveCountryFromKitchen } from 'lib';
import { useUserKitchens } from 'lib/hooks';
import { FoodComponent } from 'lib/interfaces';
import { useCallback, useState } from 'react';
import { useQuery } from 'react-query';
import { useParams } from 'react-router';
import Settings from '../Settings';

interface StatsFoodComponent extends FoodComponent {
	quantity: number;
}
const ComponentScaledRecipe = () => {
	const { id } = useParams<{ id: string }>();
	const userKitchen = useUserKitchens();
	const [isEdit, setIsEdit] = useState<boolean>(false);

	const [filters, setFilters] = useState<FoodStatsFilters>({
		day: {
			gte: format('yyyy-MM-dd')(Date.now()),
			lte: format('yyyy-MM-dd')(Date.now())
		},
		kitchen: (userKitchen && userKitchen[0]) || Kitchen.BH1,
		country: resolveCountryFromKitchen((userKitchen && userKitchen[0]) || Kitchen.BH1)
	});
	const { data: allstatsData } = useQuery<any, Error, StatsFoodComponent>(
		[`/stats/kitchen-food/${id}`, filters],
		getListWithParams
	);
	const statsData = allstatsData && allstatsData!;
	const onExport = useCallback(async () => {
		if (!statsData) {
			return;
		}
		const border: Partial<Style> = {
			border: {
				top: { style: 'medium', color: { argb: 'D3D3D3' } },
				left: { style: 'medium', color: { argb: 'D3D3D3' } },
				bottom: { style: 'medium', color: { argb: 'D3D3D3' } },
				right: { style: 'medium', color: { argb: 'D3D3D3' } }
			}
		};

		const columns: Array<Partial<Column>> = [
			{ width: 2, style: border },
			{ header: 'Ingredient Name', width: 25, key: 'Iname', style: border },
			{ header: 'Prepped Weight', width: 25, key: 'pweight', style: border },
			{ header: 'Raw Weight', width: 25, key: 'rweight', style: border },
			{ header: 'Unit', width: 25, key: 'unit', style: border }
		];

		const workbook = new ExcelJS.Workbook();

		const worksheet = workbook.addWorksheet('food-list', {
			pageSetup: { fitToPage: true, orientation: 'portrait' }
		});
		worksheet.mergeCells('B1', 'E1');
		worksheet.mergeCells('B2', 'E2');
		worksheet.mergeCells('B3', 'E3');

		worksheet.getRow(5).values = [' ', 'Ingredient Name', 'Prepped Weight', 'Raw Weight', 'Unit'];
		worksheet.columns = columns;

		worksheet.getCell('B1').value = `${statsData?.name.en}`;
		worksheet.getCell('B2').value = `Consumption Date: ${filters.day.gte} - ${filters.day.lte}`;
		worksheet.getCell('B3').value =
			`Target Total Chilled Weight = ${statsData.weight} ${statsData.measurementUnit === MeasurementUnit.ml ? MeasurementUnit.ml : MeasurementUnit.g}`;

		for (const row of statsData.ingredients as any) {
			worksheet.addRow(
				{
					Iname: `${row.name.en} (${row?.internalName || ''})`,
					pweight: Math.ceil(
						statsData.quantity * (statsData.weight || 1) * (statsData.cookedRawFactor || 1) * 1.1 * (row?.quantity || 1)
					),
					rweight: Math.ceil(
						statsData.quantity *
							(statsData.weight || 1) *
							(statsData.cookedRawFactor || 1) *
							1.1 *
							(row?.quantity || 1) *
							(row.wastage || 1)
					),
					unit: row.measurmentUnit || 'g'
				},
				''
			);
		}
		worksheet.getCell(`B${statsData.ingredients.length + 8}`).value = 'Method: ';
		worksheet.mergeCells(`B${statsData.ingredients.length + 9}`, `E${statsData.ingredients.length + 17}`);
		worksheet.getCell(`B${statsData.ingredients.length + 9}`).alignment = { wrapText: true };
		worksheet.getCell(`B${statsData.ingredients.length + 9}`).value = `${statsData?.method || ''}`;

		const buffer = await workbook.xlsx.writeBuffer();
		const fileType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
		const fileExtension = '.xlsx';
		const blob = new Blob([buffer], { type: fileType });
		saveAs(blob, 'food-list' + fileExtension);
	}, [statsData]);

	return (
		<>
			<section className="section is-title-bar">
				<div className="level">
					<div className="level-left">
						<div className="level-item">
							<span className="title w-full">Component Scaled Recipe</span>
						</div>
					</div>
					<div className="level-right">
						<div className="level-item">
							<Button icon="fas fa-file-export" onClick={() => onExport()} className="mr-4" />
						</div>
					</div>
				</div>
			</section>
			<section className="hero is-hero-bar">
				<div className="hero-body">
					<h1 className="title capitalize">{statsData?.name.en}</h1>
					<h3 className="subtitle">Consumption Date: {`${filters.day.gte} - ${filters.day.lte}`}</h3>
					<p>
						Component Raw Weight ={' '}
						{statsData && statsData.quantity
							? Math.ceil(statsData.quantity * (statsData.weight || 1) * (statsData!.cookedRawFactor || 1) * 1.1)
							: '--'}{' '}
						{statsData?.measurementUnit === MeasurementUnit.ml ? MeasurementUnit.ml : MeasurementUnit.g}
					</p>
				</div>
			</section>
			<div>
				<div className="card has-table has-table-container-upper-radius mx-4">
					<div className="card-content">
						<div className="table-container">
							<table className="table is-fullwidth is-striped is-hoverable is-sortable">
								<thead>
									<tr className="bg-black">
										<th style={{ color: 'white' }}>Ingredient Name</th>
										<th style={{ color: 'white' }}>Prepped Weight</th>
										<th style={{ color: 'white' }}>Raw Weight</th>
										<th style={{ color: 'white' }}>Unit</th>
									</tr>
								</thead>
								<tbody>
									{statsData &&
										statsData.ingredients.map((r: any) => (
											<tr key={r.id}>
												<td>
													{r.name.en} ({r?.internalName || ''})
												</td>
												<td>
													{statsData.quantity
														? Math.ceil(
																statsData.quantity *
																	(statsData.weight || 1) *
																	(statsData.cookedRawFactor || 1) *
																	1.1 *
																	(r?.quantity || 1)
															)
														: '--'}
												</td>
												<td>
													{statsData.quantity
														? Math.ceil(
																statsData.quantity *
																	(statsData.weight || 1) *
																	(statsData.cookedRawFactor || 1) *
																	1.1 *
																	(r?.quantity || 1) *
																	(r.wastage || 1)
															)
														: '--'}
												</td>
												<td>{r.measurementUnit === MeasurementUnit.ml ? MeasurementUnit.ml : MeasurementUnit.g}</td>
											</tr>
										))}
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
			{statsData?.method && (
				<span className="mt-6 mx-4">
					<label className="label">Method</label>
					<ComponentMethod
						values={statsData}
						setValues={() => []}
						uploadImages={false}
						disabled={true}
						isEdit={isEdit}
						setIsEdit={(value) => setIsEdit(value)}
						setFieldValue={() => null}
					/>
				</span>
			)}
			<Settings onFilter={setFilters} filters={filters} />
		</>
	);
};

export default ComponentScaledRecipe;
