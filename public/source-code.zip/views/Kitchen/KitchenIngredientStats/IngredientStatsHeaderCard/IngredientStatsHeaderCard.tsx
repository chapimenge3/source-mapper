import { useCallback } from 'react';

import ExcelJS from 'exceljs';
import { saveAs } from 'file-saver';
import { chunk } from 'lodash-es';
import { useDispatch } from 'react-redux';

import { IngredientStatsReq, MeasurementUnit } from '@calo/dashboard-types';
import { Box, Button, Card, Stack, Typography } from '@mui/material';

import { toggleUISettings } from 'actions';
import { caloTheme } from 'assets/images/theme/calo';
import { Icon } from 'components';
import { columns, IngredientStatsAfterPrep } from '../helpers';

interface IngredientStatsHeaderCardProps {
	isLoading: boolean;
	filters: IngredientStatsReq;
	summedComponentData: IngredientStatsAfterPrep[];
	filtersCheck: { subscriptions: boolean; businesses: boolean; charity: boolean };
}

const IngredientStatsHeaderCard = ({ summedComponentData, isLoading, filters, filtersCheck }: IngredientStatsHeaderCardProps) => {
	const dispatch = useDispatch();

	const findDisplayWeights = (ingredient: IngredientStatsAfterPrep | undefined) => {
		if (!ingredient) {
			return { quantityBeforePrep: '', quantityAfterPrep: '' };
		}

		if (ingredient.measurementUnit === MeasurementUnit.g) {
			return { quantityBeforePrep: ingredient.quantity, quantityAfterPrep: ingredient.quantityAfterPrep };
		}

		return {
			quantityBeforePrep: `${ingredient.quantity * (ingredient.weight || 1)} (${ingredient.quantity} ${ingredient.measurementUnit})`,
			quantityAfterPrep: `${ingredient.quantityAfterPrep * (ingredient.weight || 1)} (${ingredient.quantityAfterPrep} ${ingredient.measurementUnit})`
		};
	};

	const onExport = useCallback(async () => {
		if (!summedComponentData) {
			return;
		}
		const workbook = new ExcelJS.Workbook();

		const worksheet = workbook.addWorksheet('ingredient-stats', {
			pageSetup: { fitToPage: true, orientation: 'portrait' }
		});
		worksheet.mergeCells('A1', 'G1');
		worksheet.getCell('A1').value = `${filters.day.gte} - ${filters.day.lte}`;
		worksheet.getCell('A1').font = { color: { argb: '0000' }, bold: true, size: 18 };
		worksheet.getCell('A1').alignment = {
			vertical: 'middle',
			horizontal: 'center'
		};
		worksheet.getRow(2).values = [
			'Name',
			'Internal Name',
			'Quantity (in grams)',
			'Quantity after Prep (in grams)',
			' ',
			'Name',
			'Internal Name',
			'Quantity (in grams)',
			'Quantity after Prep (in grams)'
		];
		worksheet.columns = columns;

		for (const row of chunk(summedComponentData, 2)) {
			const firstIngredient = findDisplayWeights(row[0]);
			const secondIngredient = findDisplayWeights(row[1]);
			worksheet.addRow(
				{
					name: row[0].name.en,
					internalName: row[0].internalName,
					quantity: firstIngredient.quantityBeforePrep,
					quantityAfterPrep: firstIngredient.quantityAfterPrep,
					name2: row[1] ? row[1].name.en : '',
					internalName2: row[1] ? row[1].internalName : '',
					quantity2: secondIngredient.quantityBeforePrep,
					quantityAfterPrep2: secondIngredient.quantityAfterPrep
				},
				''
			);
		}

		const buffer = await workbook.xlsx.writeBuffer();
		const fileType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
		const fileExtension = '.xlsx';
		const blob = new Blob([buffer], { type: fileType });
		saveAs(blob, 'ingredient-stats' + fileExtension);
	}, [summedComponentData, filtersCheck]);

	return (
		<Card
			variant="outlined"
			sx={{
				width: 'full',
				mb: '14px',
				border: 'none',
				borderRadius: '16px',
				paddingBottom: '4px',
				[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
					flexDirection: 'column'
				}
			}}
		>
			<Box
				sx={{
					display: 'flex',
					padding: 2,
					[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
						flexDirection: 'column'
					}
				}}
			>
				<Stack
					display="flex"
					width="100%"
					flexDirection={'row'}
					justifyContent={'space-between'}
					sx={{
						[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
							flexDirection: 'column',
							textAlign: 'center'
						}
					}}
				>
					<Stack
						display={'flex'}
						flexDirection={'row'}
						sx={{
							width: '60%',
							[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
								flexDirection: 'column',
								textAlign: 'center',
								width: '100%'
							}
						}}
					>
						<Typography
							variant="h3"
							sx={{
								[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
									flexDirection: 'column',
									textAlign: 'center'
								},
								my: 'auto',
								textTransform: 'none',
								textAlign: 'left',
								fontSize: '33px',
								lineHeight: '40px',
								fontFamily: caloTheme.typography.fontFamily,
								fontWeight: 400,
								color: caloTheme.palette.neutral900
							}}
						>
							Ingredient Stats
						</Typography>
					</Stack>
					<Stack display={'flex'} flexDirection={'row'}>
						<Button
							aria-label="filter-subscription-list"
							sx={{
								cursor: 'pointer',
								my: 'auto',
								'&:hover': {
									backgroundColor: 'white',
									borderColor: 'none'
								},
								color: caloTheme.palette.primary500,
								borderColor: caloTheme.palette.primary500,
								[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
									justifyItems: 'center',
									margin: 'auto',
									marginTop: 4,
									width: 'auto'
								}
							}}
							onClick={() => dispatch(toggleUISettings())}
						>
							{<Icon name="filter" size={6} className="w-10 h-18" />}
						</Button>

						<Button
							variant="outlined"
							disabled={summedComponentData.length === 0 || isLoading}
							aria-label="Download-subscription-list"
							sx={{
								textTransform: 'none',
								height: '45px',
								ml: 2,
								lineHeight: '17px',
								fontWeight: 600,
								fontSize: '14px',
								borderRadius: '8px',
								padding: '14px 20px 14px 20px',
								color: caloTheme.palette.primary500,
								borderColor: caloTheme.palette.primary500,
								'&:hover': {
									backgroundColor: caloTheme.palette.primary100,
									borderColor: caloTheme.palette.primary500
								},
								[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
									justifyItems: 'center',
									margin: 'auto',
									marginTop: 4,
									width: 'auto'
								}
							}}
							onClick={() => onExport()}
							startIcon={
								<Icon
									name="importFile"
									size={6}
									style={{
										stroke:
											summedComponentData.length === 0 || isLoading ? caloTheme.palette.neutral300 : caloTheme.palette.primary500
									}}
								/>
							}
						>
							Download
						</Button>
					</Stack>
				</Stack>
			</Box>
		</Card>
	);
};

export default IngredientStatsHeaderCard;
