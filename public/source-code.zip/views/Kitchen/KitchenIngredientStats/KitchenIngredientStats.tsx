import { useMemo, useState } from 'react';

import { format } from 'date-fns/fp';
import { flatten, isInteger, sortBy } from 'lodash-es';
import { useQuery } from 'react-query';
import { useLocation } from 'react-router-dom';
import { v4 as uuid } from 'uuid';

import { IngredientStatsReq } from '@calo/dashboard-types';
import { Kitchen } from '@calo/types';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import {
	Box,
	Button,
	Card,
	Checkbox,
	FormControlLabel,
	MenuItem,
	Select,
	Stack,
	styled,
	Switch,
	Table,
	TableBody,
	TableCell,
	tableCellClasses,
	TableHead,
	TableRow,
	Typography
} from '@mui/material';

import { getListWithParams } from 'actions';
import { caloTheme } from 'assets/images/theme/calo';
import { CaloLoader } from 'components';
import { resolveCountryFromKitchen } from 'lib';
import history from 'lib/history';
import { useUserKitchens } from 'lib/hooks';
import { IngredientStats } from 'lib/interfaces';
import ComponentsDrawer from './ComponentsDrawer';
import { grouppedAllIngredients } from './helpers';
import IngredientStatsHeaderCard from './IngredientStatsHeaderCard';
import Settings from './Settings';

const KitchenIngredientStats = () => {
	const location = useLocation();
	const userKitchen = useUserKitchens();
	const searchParams = new URLSearchParams(location.search);

	const [filters, setFilters] = useState<IngredientStatsReq>({
		country: resolveCountryFromKitchen((userKitchen && userKitchen[0]) || Kitchen.BH1),
		kitchen: (userKitchen && userKitchen[0]) || Kitchen.BH1,
		day: {
			gte: format('yyyy-MM-dd')(Date.now()),
			lte: format('yyyy-MM-dd')(Date.now())
		},
		...JSON.parse(searchParams.get('filters') || `{}`)
	});

	const [requestTypefiltersMenuAnchorEl, setRequestTypefiltersMenuAnchorEl] = useState<null | HTMLElement>(null);
	const [filtersCheck, setFiltersCheck] = useState({ subscriptions: true, businesses: false, charity: false });
	const [showAllUnits, setShowAllUnits] = useState(false);

	const isRequestTypeFilterMenuOpened = Boolean(requestTypefiltersMenuAnchorEl);
	const [isOpen, setIsOpen] = useState(false);
	const [ingredient, setIngredient] = useState<IngredientStats | undefined>(undefined);

	const {
		data: statsData,
		error,
		isLoading
	} = useQuery<any, Error, { data: IngredientStats[]; charity: IngredientStats[]; business: IngredientStats[] }>(
		['/stats/kitchen-ingredient', filters],
		getListWithParams,
		{
			onSuccess: () => {
				searchParams.set('filters', JSON.stringify(filters));
				history.push({
					pathname: location.pathname,
					search: searchParams.toString()
				});
			}
		}
	);

	const filteredStatsData: IngredientStats[] = useMemo(() => {
		const data: IngredientStats[][] = [];
		if (filtersCheck.subscriptions) {
			data.push(statsData ? statsData?.data : []);
		}
		if (filtersCheck.businesses) {
			data.push(statsData ? statsData?.business : []);
		}
		if (filtersCheck.charity) {
			data.push(statsData ? statsData?.charity : []);
		}

		return flatten(data);
	}, [filtersCheck, statsData]);

	const summedComponentData = Object.values(grouppedAllIngredients(filteredStatsData));

	const StyledTableCell = styled(TableCell)(() => ({
		[`&.${tableCellClasses.head}`]: {
			border: 'none',
			fontFamily: 'Roboto',
			fontWeight: 600,
			fontSize: '12px',
			lineHeight: '14px'
		},
		[`&.${tableCellClasses.body}`]: {
			border: 'none',
			justifyContent: 'space-between',
			fontFamily: 'Roboto',
			fontSize: '16px',
			lineHeight: '19px',
			textTransform: 'capitalize'
		}
	}));

	return (
		<>
			<IngredientStatsHeaderCard
				summedComponentData={summedComponentData}
				isLoading={isLoading}
				filters={filters}
				filtersCheck={filtersCheck}
			/>
			<Card
				variant="outlined"
				sx={{
					width: 'full',
					mb: '14px',
					border: 'none',
					borderRadius: '16px',
					paddingBottom: '4px',
					[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
						flexDirection: 'column'
					}
				}}
			>
				<Box overflow="auto" width="100%" sx={{ padding: 2 }}>
					<Stack display={'flex'} flexDirection={'row'} justifyContent={'space-between'} sx={{ paddingRight: 2 }}>
						<Typography
							variant="h6"
							sx={{
								py: 2,
								textAlign: 'start',
								fontFamily: caloTheme.typography.fontFamily,
								fontWeight: 600,
								lineHeight: '23px',
								color: caloTheme.palette.neutral900,
								fontSize: '19px'
							}}
						>
							Ingredients
						</Typography>
						<Button
							onClick={(event) => {
								!requestTypefiltersMenuAnchorEl && setRequestTypefiltersMenuAnchorEl(event.currentTarget);
							}}
							variant="outlined"
							startIcon={
								<>
									<Typography
										style={{
											fontFamily: 'Roboto',
											fontSize: '18px',
											fontWeight: 400,
											lineHeight: '20px',
											textAlign: 'start',
											width: '70px'
										}}
									>
										Types
									</Typography>
									<Typography
										style={{ fontSize: '12px', margin: 'auto' }}
										sx={{
											fontFamily: 'Roboto',
											fontSize: '12px',
											fontWeight: 400,
											lineHeight: '20px',
											letterSpacing: '2%',
											textAlign: 'center',
											color: 'white',
											width: '20px',
											height: '20px',
											borderRadius: '120px',
											backgroundColor: caloTheme.palette.primary500
										}}
									>
										{Object.values(filtersCheck).filter(Boolean).length}
									</Typography>
								</>
							}
							endIcon={
								<>
									<ArrowDropDownIcon />
								</>
							}
							sx={{
								textTransform: 'capitalize',
								borderRadius: '8px',
								fontSize: '16px',
								width: '141px',
								color: caloTheme.palette.neutral900,
								height: '44px',
								borderColor: caloTheme.palette.neutral900
							}}
						>
							<Select
								id="demo-simple-select"
								open={isRequestTypeFilterMenuOpened}
								onClose={() => setRequestTypefiltersMenuAnchorEl(null)}
								label="session"
								sx={{ textTransform: 'capitalize', fontSize: '16px', visibility: 'hidden', width: 0, height: 0 }}
							>
								<MenuItem sx={{ fontWeight: 600 }}>
									<FormControlLabel
										control={
											<Checkbox
												checked={filtersCheck.businesses}
												disabled={filtersCheck.businesses && Object.values(filtersCheck).filter(Boolean).length === 1}
												onChange={() => setFiltersCheck({ ...filtersCheck, businesses: !filtersCheck.businesses })}
											/>
										}
										label="Businesses"
									/>
								</MenuItem>
								<MenuItem sx={{ fontWeight: 600 }}>
									<FormControlLabel
										control={
											<Checkbox
												checked={filtersCheck.subscriptions}
												disabled={filtersCheck.subscriptions && Object.values(filtersCheck).filter(Boolean).length === 1}
												onChange={() => setFiltersCheck({ ...filtersCheck, subscriptions: !filtersCheck.subscriptions })}
											/>
										}
										label="Subscriptions"
									/>
								</MenuItem>
								<MenuItem sx={{ fontWeight: 600 }}>
									<FormControlLabel
										control={
											<Checkbox
												checked={filtersCheck.charity}
												disabled={filtersCheck.charity && Object.values(filtersCheck).filter(Boolean).length === 1}
												onChange={() => setFiltersCheck({ ...filtersCheck, charity: !filtersCheck.charity })}
											/>
										}
										label="Charity"
									/>
								</MenuItem>
							</Select>
						</Button>
					</Stack>

					{isLoading ? (
						<Stack sx={{ width: '100%', justifyContent: 'center' }}>
							<CaloLoader />
						</Stack>
					) : (
						<>
							<Table
								sx={{
									marginY: '4px',
									minHeight: '120px',
									overflow: 'auto',
									width: '100%',
									[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
										flexDirection: 'column'
									}
								}}
							>
								<TableHead
									style={{ borderRadius: '8px' }}
									sx={{
										backgroundColor: caloTheme.palette.neutral50,
										color: 'black',
										flexWrap: 0,
										justifyContent: 'space-between',
										width: '100%',
										borderRadius: '8px'
									}}
								>
									<TableRow
										sx={{
											backgroundColor: caloTheme.palette.neutral50,
											color: 'black',
											width: '100%',
											flexWrap: 0,
											justifyContent: 'space-between'
										}}
									>
										<StyledTableCell style={{ width: '20%', borderTopLeftRadius: '8px', borderBottomLeftRadius: '8px' }}>
											Name
										</StyledTableCell>
										<StyledTableCell style={{ width: '20%', borderTopLeftRadius: '8px', borderBottomLeftRadius: '8px' }}>
											Internal Name
										</StyledTableCell>
										<StyledTableCell style={{ width: '15%' }}>
											Quantity
											<span className="text-xs text-yellow-300">
												<br />
												Includes child components
											</span>
										</StyledTableCell>
										<StyledTableCell style={{ width: '15%' }}>Quantity after Prep</StyledTableCell>
										<StyledTableCell style={{ width: '12%', borderTopRightRadius: '8px', borderBottomRightRadius: '8px' }}>
											Removed Quantity
										</StyledTableCell>
										<StyledTableCell style={{ width: '12%' }}>Measurement Unit</StyledTableCell>
										<StyledTableCell>
											<Stack
												sx={{ display: 'flex', flexDirection: 'row', gap: 1, alignItems: 'center', justifyContent: 'center' }}
											>
												<Typography sx={{ fontSize: '12px', fontWeight: 600 }}>{showAllUnits ? 'All units' : 'gram'}</Typography>
												<Switch
													onChange={() => {
														setShowAllUnits((prev) => !prev);
													}}
													sx={{ color: 'white' }}
													checked={showAllUnits}
												/>
											</Stack>
										</StyledTableCell>
									</TableRow>
								</TableHead>
								{summedComponentData && summedComponentData.length === 0 ? (
									<StyledTableCell style={{ border: 0 }} colSpan={6}>
										<Typography
											sx={{
												mt: 3,
												textAlign: 'center',
												width: 'full',
												fontSize: '24px',
												color: caloTheme.palette.neutral400
											}}
										>
											No Stats
										</Typography>
									</StyledTableCell>
								) : (
									<TableBody>
										{summedComponentData &&
											sortBy(summedComponentData, 'name.en')?.map((row) => {
												const quantityBeforePrep = row.quantity / (showAllUnits && row.weight ? row.weight : 1);
												const quantityAfterPrep = row.quantityAfterPrep / (showAllUnits && row.weight ? row.weight : 1);
												return (
													<TableRow key={uuid()}>
														<StyledTableCell style={{ fontWeight: 600 }}>
															<Button
																variant="text"
																sx={{
																	color: caloTheme.palette.hyperlink,
																	textTransform: 'capitalize',
																	fontSize: '16px',
																	fontWeight: 600,
																	lineHeight: '19px'
																}}
																onClick={() => {
																	setIngredient(row);
																	setIsOpen(true);
																}}
															>
																{row.name.en}
															</Button>
														</StyledTableCell>
														<StyledTableCell style={{ fontWeight: 400 }}>{row.internalName}</StyledTableCell>
														<StyledTableCell style={{ fontWeight: 400 }}>
															{isInteger(quantityBeforePrep) ? quantityBeforePrep : quantityBeforePrep.toFixed(1)}
														</StyledTableCell>
														<StyledTableCell style={{ fontWeight: 400 }}>
															{isInteger(quantityAfterPrep) ? quantityAfterPrep : quantityAfterPrep.toFixed(1)}
														</StyledTableCell>
														<StyledTableCell style={{ fontWeight: 400 }}>{row.removedQuantity}</StyledTableCell>
														<StyledTableCell style={{ fontWeight: 400, textTransform: 'none' }}>
															{showAllUnits ? row.measurementUnit : 'g'}
														</StyledTableCell>
													</TableRow>
												);
											})}
									</TableBody>
								)}
							</Table>
						</>
					)}
				</Box>
			</Card>
			<Settings onFilter={setFilters} filters={filters} />
			<ComponentsDrawer
				isOpen={isOpen}
				setIsOpen={setIsOpen}
				ingredient={ingredient}
				filters={filters}
				showAllUnits={showAllUnits}
			/>
		</>
	);
};

export default KitchenIngredientStats;
