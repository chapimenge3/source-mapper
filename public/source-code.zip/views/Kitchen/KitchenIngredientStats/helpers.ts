import { Column, Style } from 'exceljs';
import { IngredientComponentStats, IngredientStats } from 'lib/interfaces';
import { Dictionary, keyBy, sortBy } from 'lodash';

export interface IngredientStatsAfterPrep extends IngredientStats {
	quantityAfterPrep: number;
}

interface GroupedIngredientData {
	[key: string]: IngredientStatsAfterPrep;
}

export const grouppedAllIngredients = (selectedStatsData: IngredientStats[]) => {
	const groupedData: GroupedIngredientData = {};
	for (const item of selectedStatsData) {
		if (groupedData[item.id]) {
			groupedData[item.id] = {
				...item,
				keyedComponents: groupKeyedComponents(item, groupedData[item.id]),
				quantity: groupedData[item.id].quantity + Math.ceil((item.quantity - item.removedQuantity) * item.wastage),
				quantityAfterPrep: groupedData[item.id].quantityAfterPrep + Math.ceil(item.quantity - item.removedQuantity),
				removedQuantity: groupedData[item.id].removedQuantity + Math.ceil(item.removedQuantity * item.wastage)
			};
		} else {
			groupedData[item.id] = {
				...item,
				quantity: Math.ceil((item.quantity - item.removedQuantity) * item.wastage),
				quantityAfterPrep: Math.ceil(item.quantity - item.removedQuantity),
				removedQuantity: Math.ceil(item.removedQuantity * item.wastage)
			};
		}
	}
	return groupedData;
};

const groupKeyedComponents = (ingStats: IngredientStats, groupedIng: IngredientStatsAfterPrep) => {
	const newKeyedComponents: Dictionary<IngredientComponentStats> = { ...groupedIng.keyedComponents };
	for (const [compId, ingredientCompStats] of Object.entries(ingStats.keyedComponents)) {
		if (!newKeyedComponents[compId]) {
			newKeyedComponents[compId] = {
				id: ingredientCompStats.id,
				name: ingredientCompStats.name,
				cookedRawFactor: ingredientCompStats.cookedRawFactor,
				childComponentRawWeight: 0,
				neededIngredientFromChild: 0,
				neededIngredientFromParent: 0,
				parentComponentRawWeight: 0,
				removedComponentRawWeight: 0,
				removedNeededIngredient: 0
			};
		}

		const current = newKeyedComponents[compId];
		newKeyedComponents[compId] = {
			...newKeyedComponents[compId],
			childComponentRawWeight: current.childComponentRawWeight + ingredientCompStats.childComponentRawWeight,
			neededIngredientFromChild: current.neededIngredientFromChild + ingredientCompStats.neededIngredientFromChild,
			neededIngredientFromParent: current.neededIngredientFromParent + ingredientCompStats.neededIngredientFromParent,
			parentComponentRawWeight: current.parentComponentRawWeight + ingredientCompStats.parentComponentRawWeight,
			removedComponentRawWeight: current.removedComponentRawWeight + ingredientCompStats.removedComponentRawWeight,
			removedNeededIngredient: current.removedNeededIngredient + ingredientCompStats.removedNeededIngredient
		};
	}

	const keyedComponentsList = Object.values(newKeyedComponents);
	const sortedList = sortBy(keyedComponentsList, ['name.en']);

	return keyBy(sortedList, 'id');
};

const border: Partial<Style> = {
	border: {
		top: { style: 'thin', color: { argb: 'D3D3D3' } },
		left: { style: 'thin', color: { argb: 'D3D3D3' } },
		bottom: { style: 'thin', color: { argb: 'D3D3D3' } },
		right: { style: 'thin', color: { argb: 'D3D3D3' } }
	}
};

export const columns: Array<Partial<Column>> = [
	{ width: 30, key: 'name', style: border },
	{ width: 30, key: 'internalName', style: border },
	{ width: 10, key: 'quantity', style: border },
	{ width: 10, key: 'quantityAfterPrep', style: border },
	{ width: 4 },
	{ width: 30, key: 'name2', style: border },
	{ width: 30, key: 'internalName2', style: border },
	{ width: 10, key: 'quantity2', style: border },
	{ width: 10, key: 'quantityAfterPrep2', style: border }
];
