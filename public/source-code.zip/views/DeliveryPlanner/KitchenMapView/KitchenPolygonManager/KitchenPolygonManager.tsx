import { useContext, useEffect, useState } from 'react';

import { flatten } from 'lodash';
import { useMutation, useQuery } from 'react-query';
import { toast } from 'react-toastify';

import { LatLng } from '@calo/driver-types';
import { Country } from '@calo/types';
import { DrawingManager, InfoWindow } from '@react-google-maps/api';

import { getList, updateKitchen } from 'actions';
import { Kitchen } from 'lib/interfaces';
import PolygonContext from '../../MapView/PolygonContext';
import CityAreaForm from '../CityAreaForm';

interface KitchenPolygonManagerProps {
	polygonState: KitchenPolygonState;
	isEditing: boolean;
	setIsEditing: (e: boolean) => void;
	closePopUp: () => void;
	country: Country;
	kitchenID: string;
	setKitchenID: (value: string) => void;
	addressView: boolean;
}

const polygonOptions: google.maps.PolygonOptions = {
	clickable: false,
	editable: false,
	fillOpacity: 1,
	strokeWeight: 0.3,
	zIndex: 50
};

const polygonOptionsEdit: google.maps.PolygonOptions = {
	fillOpacity: 1,
	editable: false,
	clickable: true,
	strokeWeight: 1,
	zIndex: 50
};

const getPolygonCenter = (polygon: google.maps.Polygon | any) => {
	if (polygon.polygon) {
		const bounds = new google.maps.LatLngBounds();
		polygon.polygon
			.getPath()
			.getArray()
			.forEach((path: any) => {
				bounds.extend(path);
			});
		const centerLng = bounds.getCenter().lng();
		const lat = bounds.getNorthEast().lat();
		return { lat, lng: centerLng };
	} else {
		const bounds = polygon.polygon ? polygon.polygon : polygon.bounds;
		const centerLng = bounds.lng;
		const lat = bounds.lat;
		return { lat, lng: centerLng };
	}
};

const KitchenPolygonManager = ({
	addressView,
	kitchenID,
	setKitchenID,
	polygonState,
	isEditing,
	setIsEditing,
	closePopUp,
	country
}: KitchenPolygonManagerProps) => {
	const dispatch = useContext(PolygonContext);
	const { mutateAsync: updateMutation } = useMutation(updateKitchen);
	const { data: kitchenList, refetch } = useQuery<string, Error, { data: Kitchen[] }>('kitchens', getList, {
		suspense: true
	});

	const [countryKitchen, setCountryKitchen] = useState<boolean>();
	const kitchen = kitchenList?.data.find((r) => r.country === country && r.id === kitchenID);

	const { selectedPolygon } = polygonState;

	useEffect(() => {
		polygonState.polygons.forEach((row: any) => {
			row.polygon.setEditable(isEditing);
			const options: google.maps.PolygonOptions = {
				...(isEditing ? polygonOptionsEdit : polygonOptions),
				fillColor: row.color || 'rgba(0, 0, 0, 0.5)',
				fillOpacity: isEditing ? 10 : 0,
				strokeColor: addressView
					? (row.color || 'rgba(0, 0, 0, 0.5)').replace('0.5', '0')
					: isEditing
						? (row.color || 'rgba(0, 0, 0, 0.5)').replace('0.5', '1')
						: 'black'
			};
			row.polygon.setOptions(options);
		});
	}, [isEditing, polygonState.polygons, country]);

	useEffect(() => {
		if (kitchenList?.data.find((r) => r.country === country && r.id === kitchenID)) {
			setKitchenID(kitchen!.id);
			setCountryKitchen(true);
		} else {
			toast("Kitchen doesn't exist for this country", { type: 'error', autoClose: 2000 });
			setIsEditing(false);
			setCountryKitchen(false);
		}
	}, [country]);

	useEffect(() => {
		if (selectedPolygon != null) {
			if (selectedPolygon.polygon.getEditable()) {
				selectedPolygon.polygon.setOptions({ editable: false });
				closePopUp();
			} else {
				polygonState.polygons?.forEach((p: any) => {
					if (p.polygon?.getEditable()) {
						p.polygon?.setOptions({ editable: false });
					}
				});
				selectedPolygon.polygon?.setOptions({ editable: true });
			}
		}
	}, [selectedPolygon]);

	const onKitchenDelete = (row: KitchenPolygonRowState) => {
		dispatch!({
			type: 'delete',
			payload: row
		});
	};

	const onSaveKitchenArea = async (row: KitchenPolygonRowState) => {
		dispatch!({
			type: 'update',
			payload: row
		});
		closePopUp();
	};

	const saveMap = async () => {
		const x = polygonState.polygons.map((r: any) => [
			{
				name: r.name,
				bounds: r.polygon
					.getPath()
					.getArray()
					.map((row: any) => row.toJSON()) as LatLng[]
			}
		]);
		await updateMutation({
			areas: flatten(x).filter((p) => p.bounds.length > 3),
			country,
			id: kitchen!.id
		});
		refetch();
	};

	const handlePolygonClick = (polygon: google.maps.Polygon) => {
		dispatch!({
			type: 'select',
			payload: { polygon }
		});
	};

	const onPolygonComplete = (polygon: google.maps.Polygon) => {
		if (polygon.getPath().getArray().length < 4) {
			toast(`Polygon needs to have at least 4 points, please edit this one or it will not be included on save`, {
				type: 'error',
				autoClose: 5000
			});
		}
		dispatch!({
			type: 'select',
			payload: null
		});
		const newPoly = new google.maps.Polygon({
			paths: polygon.getPaths(),
			...polygonOptionsEdit
		});
		newPoly.setMap(polygon.getMap());
		newPoly.addListener('click', () => handlePolygonClick(newPoly));
		dispatch!({
			type: 'add',
			payload: {
				polygon: newPoly,
				name: '',
				bounds: polygon
					.getPath()
					.getArray()
					.map((row) => row.toJSON()) as LatLng[]
			}
		});
		handlePolygonClick(newPoly);
		// onPolygonLoaded(newPoly);
		polygon.setMap(null);
		// polygon.setMap(null);
	};

	const onLoaded = (dm: google.maps.drawing.DrawingManager) => {
		dm.setDrawingMode(null);

		dispatch!({
			type: 'set',
			payload: (kitchen?.areas || []).map((area) => {
				const polygon = new google.maps.Polygon({
					paths: area.bounds,
					...polygonOptionsEdit
				});
				polygon.setMap(dm.getMap());
				polygon.addListener('click', () =>
					dispatch!({
						type: 'select',
						payload: { polygon: polygon, name: area.name, bounds: area.bounds }
					})
				);

				return { polygon: polygon, name: area.name, bounds: area.bounds };
			})
		});
	};
	const onUnloaded = (dm: google.maps.drawing.DrawingManager) => {
		dm.setDrawingMode(null);
		dispatch!({
			type: 'reset'
		});
	};

	return (
		<>
			{!addressView && (
				<div className="absolute top-10 right-2 bg-white p-2 flex flex-row">
					{isEditing ? (
						<>
							<span className="has-tooltip-left mx-2" data-tooltip="Save">
								<i className="far fa-save" onClick={() => saveMap()} />
							</span>
						</>
					) : (
						<i className="fas fa-edit" onClick={() => (countryKitchen ? setIsEditing(true) : undefined)} />
					)}
				</div>
			)}
			<DrawingManager
				key={`${country}-${kitchen?.id}`}
				onLoad={onLoaded}
				onUnmount={onUnloaded}
				onPolygonComplete={onPolygonComplete}
				options={{
					drawingControl: countryKitchen ? isEditing : false,
					drawingControlOptions: {
						position: google.maps.ControlPosition.TOP_RIGHT,
						drawingModes: [google.maps.drawing.OverlayType.POLYGON]
					},
					polygonOptions: polygonOptionsEdit
				}}
			/>
			{selectedPolygon && (
				<InfoWindow position={getPolygonCenter(selectedPolygon)} onCloseClick={closePopUp}>
					<CityAreaForm
						allPolygons={polygonState.polygons || []}
						polygonRow={selectedPolygon}
						onChange={onSaveKitchenArea}
						onDelete={onKitchenDelete}
					/>
				</InfoWindow>
			)}
		</>
	);
};

export default KitchenPolygonManager;
