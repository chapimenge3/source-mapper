import { createContext, Dispatch } from 'react';

export default createContext<Dispatch<PolygonAction> | null>(null);
