import { Permission } from '@calo/dashboard-types';
import { WeekDay } from '@calo/types';
import { Box, Button, Divider, Stack, ToggleButton, ToggleButtonGroup, Typography } from '@mui/material';
import { DriverPicker } from 'components';
import { AreaColors, dayMappings } from 'lib/enums';
import { useUserRoles } from 'lib/hooks';
import React, { Suspense, useEffect, useState } from 'react';
import { caloTheme } from '../../../../assets/images/theme/calo';
import styles from './styles';

interface AreaFormProps {
	closePopUp: () => void;
	polygonRow: PolygonRowState;
	onChange: (polygonRow: PolygonRowState) => void;
	onDelete: (polygonRow: PolygonRowState) => void;
}

const AreaForm = ({ polygonRow, onDelete, onChange }: AreaFormProps) => {
	const roles = useUserRoles();
	const [selectedDay, setSelectedDay] = useState<number>(new Date().getDay());
	const [selectedColor, setSelectedColor] = useState<string>(polygonRow.color);
	const [isSoftLaunchEnabled, setIsSoftLaunchEnabled] = useState<boolean>(polygonRow.isSoftLaunchEnabled);
	const [driversPerWeek, setDriversPerWeek] = useState(
		polygonRow.drivers?.length ? polygonRow.drivers : Array.from({ length: 7 }).fill('')
	);
	useEffect(() => {
		const updatedDrivers = driversPerWeek?.slice();
		while (updatedDrivers?.length < 7) updatedDrivers?.push('');
		setDriversPerWeek(updatedDrivers);
		setSelectedColor(polygonRow.color);
		setIsSoftLaunchEnabled(polygonRow.isSoftLaunchEnabled);
	}, [polygonRow, polygonRow.polygon]);

	const handleDriverChange = (driverId: string) => {
		const updatedDrivers = driversPerWeek?.map((driver, index) => (index === selectedDay ? driverId : driver));
		setDriversPerWeek(updatedDrivers);
	};

	const handleDaysChange = (event: React.MouseEvent<HTMLElement>, newDayIndex: number) => {
		setSelectedDay(newDayIndex);
	};

	const handleApply = () => {
		onChange({
			...polygonRow,
			drivers: driversPerWeek as any,
			color: selectedColor,
			isSoftLaunchEnabled
		});
	};

	const isAnyDayMissingDriver = () => {
		return driversPerWeek?.some((driver) => driver === '');
	};

	return (
		<Box sx={{ width: '100%' }}>
			{roles.includes(Permission.GET_DRIVER_USERS) && (
				<Box style={{ flexDirection: 'column' }}>
					<Stack flexDirection={'row'} justifyContent={'space-between'} sx={{ mb: 1 }}>
						<Typography
							sx={{
								lineHeight: '20px',
								fontSize: '16px',
								fontWeight: 600,
								fontFamily: 'Roboto',
								color: caloTheme.palette.neutral900
							}}
						>
							Assigned Driver
						</Typography>
					</Stack>
					<ToggleButtonGroup exclusive value={selectedDay.toString()} onChange={handleDaysChange}>
						{Object.entries(dayMappings).map(([longDay, shortDay], index) => (
							<ToggleButton
								key={index}
								value={index}
								aria-label={shortDay}
								style={{
									...styles.toggleStyle,
									backgroundColor: selectedDay === parseInt(index.toString(), 10) ? caloTheme.palette.primary500 : 'white'
								}}
							>
								<Typography
									sx={{
										...styles.shortDayText,
										color: selectedDay === parseInt(index.toString(), 10) ? 'white' : caloTheme.palette.neutral900
									}}
								>
									{shortDay}
								</Typography>
							</ToggleButton>
						))}
					</ToggleButtonGroup>
					<Suspense fallback={null}>
						<DriverPicker
							value={driversPerWeek?.[selectedDay] as any}
							selectedDay={Object.values(WeekDay)[selectedDay]}
							onChange={handleDriverChange}
						/>
					</Suspense>
					<Divider style={styles.divider} />
					<Box sx={{ mx: '5px' }}>
						<Typography sx={{ fontWeight: 600, lineHeight: '16px', fontSize: '14px' }}>Zone </Typography>
						<Stack sx={{ flexDirection: 'row', mt: 1 }}>
							{Object.values(AreaColors).map((c, i) => (
								<div
									key={i}
									onClick={() => setSelectedColor(c)}
									className=" flex w-6 h-6 rounded-full mr-2 cursor-pointer justify-center items-center"
									style={{
										backgroundColor: c,
										borderWidth: 0.5,
										borderColor: selectedColor === c ? 'green' : c.replace('0.5', '1')
									}}
								>
									{selectedColor === c && <i className="fas fa-check text-green-600"></i>}
								</div>
							))}
						</Stack>
					</Box>

					<Divider sx={styles.divider} />
					<Box>
						<Stack
							direction="row"
							alignItems="start"
							sx={{ backgroundColor: caloTheme.palette.neutral50, borderRadius: '12px', p: '4px', width: '240px' }}
						>
							<Button
								variant={'contained'}
								disabled={polygonRow.isSoftLaunchEnabled === false || polygonRow.isSoftLaunchEnabled === undefined}
								sx={[
									styles.softLaunchButton,
									{
										color: isSoftLaunchEnabled ? caloTheme.palette.white : caloTheme.palette.neutral400,
										backgroundColor: isSoftLaunchEnabled ? caloTheme.palette.primary500 : caloTheme.palette.neutral50,
										zIndex: isSoftLaunchEnabled ? 1 : 0
									}
								]}
								onClick={() => setIsSoftLaunchEnabled(true)}
							>
								Soft Launch
							</Button>
							<Button
								variant={'contained'}
								sx={[
									styles.fullLaunchButton,
									{
										color: isSoftLaunchEnabled ? caloTheme.palette.neutral600 : caloTheme.palette.white,
										backgroundColor:
											isSoftLaunchEnabled === false || isSoftLaunchEnabled === undefined
												? caloTheme.palette.primary500
												: caloTheme.palette.neutral50,
										zIndex: isSoftLaunchEnabled ? 0 : 1
									}
								]}
								onClick={() => setIsSoftLaunchEnabled(false)}
							>
								Full Launch
							</Button>
						</Stack>
					</Box>
					{isSoftLaunchEnabled === false && (polygonRow.isSoftLaunchEnabled || polygonRow.isSoftLaunchEnabled === undefined) && (
						<Typography sx={styles.warningText}>Cannot move from full launch to Soft Launch after saving</Typography>
					)}

					<Stack sx={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between', marginTop: 2 }}>
						<Button variant="text" sx={styles.deleteButton} onClick={() => onDelete(polygonRow)}>
							Delete
						</Button>
						<Button
							size="small"
							variant="contained"
							onClick={handleApply}
							sx={styles.applyButton}
							disabled={isAnyDayMissingDriver()}
						>
							Apply
						</Button>
					</Stack>
				</Box>
			)}
		</Box>
	);
};
export default AreaForm;
