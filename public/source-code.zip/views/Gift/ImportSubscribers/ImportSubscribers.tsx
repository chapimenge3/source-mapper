import { Subscription } from '@calo/types';
import { Icon } from 'components';
import ExcelJS from 'exceljs';
import { uniq } from 'lodash';
import { useDropzone } from 'react-dropzone';
import { toast } from 'react-toastify';

interface ImportSubscribersProps {
	isDisabled: boolean;
	selected: Subscription[];
	validateSubscribers: (value: Subscription[]) => void;
}

const ImportSubscribers = ({ selected, isDisabled, validateSubscribers }: ImportSubscribersProps) => {
	const accept = ['.csv', '.xls', '.xlsx'];
	const { getRootProps, getInputProps } = useDropzone({ accept });

	const readExcel = (file: any) => {
		const wb = new ExcelJS.Workbook();
		const fileReader = new FileReader();
		fileReader.readAsArrayBuffer(file);

		fileReader.addEventListener('load', () => {
			const buffer = fileReader.result! as any;
			wb.xlsx.load(buffer).then((workbook) => {
				const dataRow: any = [];
				workbook.eachSheet((sheet) => {
					sheet.eachRow((row: any) => {
						if (!dataRow.includes(row.values.slice(1).toString())) {
							dataRow.push(row.values.slice(1).toString());
						}
					});
					if (dataRow.length >= 1000) {
						toast('Limit is 1000 subscribers', { type: 'error', autoClose: 2000 });
					} else {
						const check = dataRow && uniq([...selected.map((r) => r.id), ...dataRow].map((r) => ({ id: r })));
						if (check.length >= 1000) {
							toast('Limit is 1000 subscribers', { type: 'error', autoClose: 2000 });
						} else {
							check.length > 0 && validateSubscribers(check as any);
						}
					}
				});
			});
		});
	};

	return (
		<div className="file " {...getRootProps()}>
			<div className="file-label">
				<input
					className="file-input"
					disabled={isDisabled}
					{...getInputProps()}
					onChange={(e) => {
						const file = e.target.files && e.target.files[0];
						readExcel(file);
					}}
				/>
				<span className="flex mt-1">
					<Icon name="importFile" size={8} />
					<p className="text-green-500 text-lg">Import</p>
				</span>
			</div>
		</div>
	);
};
export default ImportSubscribers;
