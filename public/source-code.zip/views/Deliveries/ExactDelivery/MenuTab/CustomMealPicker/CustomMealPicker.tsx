import { Permission } from '@calo/dashboard-types';
import { PermissionService } from '@calo/services';
import { Delivery } from '@calo/types';
import cx from 'classnames';
import { Button, Icon } from 'components';
import { useUserRoles } from 'lib/hooks';
import { MenuFood } from 'lib/interfaces';
import { flatten } from 'lodash';
interface CustomMealPickerProps {
	food: MenuFood;
	customMeal: any;
	delivery: Delivery;
	onPick: (food: any) => void;
	setCustomFood: (value: any) => void;
	setCustomMealAction: (value: string) => void;
	customFoodComponent: any;
}

const CustomMealPicker = ({
	delivery,
	customFoodComponent,
	setCustomMealAction,
	food,
	onPick,
	customMeal,
	setCustomFood
}: CustomMealPickerProps) => {
	const roles = useUserRoles();

	const handleCustomMealComponents = (data: any) => {
		const customComponentData = data?.map((comp: any) => customFoodComponent?.filter((r: any) => comp.id === r.id));
		return (
			<span>
				{customComponentData
					? flatten(customComponentData).map(
							(comp: any, index) => `${comp?.name.en} ${index === customComponentData.length - 1 ? '' : ','}`
						)
					: ''}
			</span>
		);
	};

	return (
		<>
			<tr key={customMeal.id} className="z-10 bg-gray-100 rounded-xl w-full min-h-16">
				<td style={{ width: '6rem' }}>
					{' '}
					<span>{customMeal.name.en}</span>
				</td>
				<td>{handleCustomMealComponents(customMeal.components)}</td>
				<td className="right-0" style={{ width: '7rem' }}>
					{roles.includes(Permission.UPDATE_DELIVERY_CUSTOM_FOOD) && (
						<span className="flex flex-row mt-2">
							<button
								onClick={() => {
									setCustomMealAction('update');
									setCustomFood(customMeal);
								}}
								className="has-tooltip-danger"
								disabled={!PermissionService.deliveryCanBeEdited(delivery)}
								data-tooltip={
									PermissionService.deliveryCanBeEdited(delivery) ? undefined : 'You cannot update after the lock-up time'
								}
							>
								<span className="text-green-400">
									<Icon name="editPen" size={4} className="cursor-pointer" />
									Edit Meal
								</span>
							</button>
						</span>
					)}
				</td>
				<td className="right-0" style={{ width: '5rem' }}>
					<span className="">
						<Button
							onClick={() => (food?.name.en === customMeal?.name.en ? null : onPick(customMeal))}
							content={food?.name.en === customMeal?.name.en ? 'Selected' : 'Select'}
							className={cx(' -ml-4 w-20 border-green-500 focus:border-green-500', {
								'cursor-not-allowed bg-green-500 text-white hover:text-white focus:text-white':
									food?.name.en === customMeal?.name.en,
								'hover:text-green-500 text-green-500 focus:text-green-500  hover:border-green-500':
									food?.name.en !== customMeal?.name.en
							})}
						/>
					</span>
				</td>
			</tr>
		</>
	);
};
export default CustomMealPicker;
