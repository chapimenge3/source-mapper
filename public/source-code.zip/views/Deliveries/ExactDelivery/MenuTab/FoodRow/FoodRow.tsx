import cx from 'classnames';

import { Permission } from '@calo/dashboard-types';
import { PermissionService } from '@calo/services';
import { Food } from '@calo/types';

import { skipMeal, unSkipMeal } from 'actions';
import { Button } from 'components';
import FoodDietTypeTags from 'components/FoodDietTypeTags';
import { useUserRoles } from 'lib/hooks';
import { Delivery, FoodWithPosition } from 'lib/interfaces';

interface FoodRowProps {
	item: FoodWithPosition;
	delivery: Delivery;
	removeFromList: (food: Food) => void;
	selectRow: (food: FoodWithPosition) => void;
	disableEditButton?: boolean;
	setCustomMeal?: (value: Food) => void;
	setSwapMeal: (value: boolean) => void;
}

const FoodRow = ({ delivery, setSwapMeal, item, selectRow, removeFromList, disableEditButton, setCustomMeal }: FoodRowProps) => {
	const handleEditMeal = (item: FoodWithPosition) => {
		if (item.isCustom) {
			setCustomMeal!(item);
			selectRow(item);
		} else {
			selectRow(item);
		}
	};

	const roles = useUserRoles();

	const onSkip = async () => {
		await (item.skipped
			? unSkipMeal({ deliveryId: delivery.id, foodId: item.id })
			: skipMeal({ deliveryId: delivery.id, foodId: item.id }));
	};

	return (
		<tr>
			<td>
				{item.skipped && (
					<b
						className={cx('', {
							'text-cRed': item.skipped
						})}
					>
						{' '}
						SKIPPED
					</b>
				)}{' '}
				{`${item.isGiftedItem ? `(Gift) ${item.name?.en}` : `${item.name?.en}`}`}{' '}
			</td>
			<td>{item.size}</td>
			<td>{item.type?.join(', ')}</td>
			<td>{item.macros?.cal}</td>
			<td>{item.macros?.protein}</td>
			<td>{item.macros?.carbs}</td>
			<td>{item.macros?.fat}</td>
			<td>
				{item.tags?.length > 0 && (
					<div className="tags capitalize">
						{item.tags.map((type, i) => (
							<FoodDietTypeTags key={i} tag={type} />
						))}
					</div>
				)}
			</td>
			<td>
				{roles.includes(Permission.REPLACE_FOOD_DELIVERY_MENU) && !item.skipped && (
					<Button
						icon="fas fa-edit"
						onClick={() => {
							setSwapMeal(true);
							handleEditMeal(item);
						}}
						className="mr-4"
						disabled={disableEditButton}
					/>
				)}
				{roles.includes(Permission.DELETE_FOOD_DELIVERY_MENU) && !item.skipped && (
					<Button
						icon="fas fa-trash"
						disabled={(!PermissionService.deliveryCanBeEdited(delivery) && !disableEditButton) || item.isGiftedItem}
						onClick={() => removeFromList(item)}
						className="has-tooltip-danger mr-4"
						data-tooltip={
							!PermissionService.deliveryCanBeEdited(delivery) && !disableEditButton
								? 'You cannot delete after the lock-up time'
								: undefined
						}
					/>
				)}
				{roles.includes(Permission.DELETE_FOOD_DELIVERY_MENU) && (
					<Button
						content={item.skipped ? 'Un-Skip' : 'Skip'}
						disabled={(!PermissionService.deliveryCanBeEdited(delivery) && !disableEditButton) || item.isGiftedItem}
						onClick={onSkip}
						className="has-tooltip-danger font-bold"
						data-tooltip={
							!PermissionService.deliveryCanBeEdited(delivery) && !disableEditButton
								? 'You cannot skip a meal after the lock-up time'
								: undefined
						}
					/>
				)}
			</td>
		</tr>
	);
};

export default FoodRow;
