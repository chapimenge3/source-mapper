import { forwardRef } from 'react';

import { Permission, UpdateFoodReq } from '@calo/dashboard-types';
import { Dictionary, FoodComponentType, FoodDietType } from '@calo/types';
import { Stack, Typography } from '@mui/material';

import { caloTheme } from 'assets/images/theme/calo';
import { FoodComponent } from 'lib/interfaces';
import { FoodComponentPickerMUI } from '../MUI';

interface ComponentsProps {
	roles: any;
	name: string;
	foodComponents: FoodComponent[];
	isDisabled: boolean;
	values: UpdateFoodReq;
	isLoading: boolean;
	allComponents: Dictionary<FoodComponent>;
	handleComponentsChange: (value: any) => void;
	setFieldValue: (field: string, value: any, shouldValidate?: boolean | undefined) => void;
	setName: (value: string) => void;
}

const Components = forwardRef(
	(
		{
			values,
			isDisabled,
			foodComponents,
			isLoading,
			allComponents,
			setFieldValue,
			handleComponentsChange,
			roles,
			setName,
			name
		}: ComponentsProps,
		ref
	) => {

		const getOrderedComponents = (components: any[], allComponents: Dictionary<FoodComponent>) => {
			let availableComponents = [...components];
			const orderedComponents: any[] = [];
			const orderByNames = [FoodComponentType.base, FoodComponentType.side, FoodComponentType.protein, FoodComponentType.topping, FoodComponentType.sauce]
			for (const order of orderByNames) {
				const filtered = availableComponents.filter(comp => (allComponents[comp.id]?.tags || []).includes(order))
				orderedComponents.push(...filtered)
				availableComponents = availableComponents.filter(comp => !allComponents[comp.id] || !(allComponents[comp.id]?.tags || []).includes(order))
			}
			orderedComponents.push(...availableComponents);
			return orderedComponents
		}
		return (
			<>
				{roles.includes(Permission.VIEW_FOOD_COMPONENTS) && (
					<Stack
						direction="column"
						justifyContent="flex-start"
						alignItems="flex-start"
						ref={ref}
						sx={{ backgroundColor: caloTheme.palette.white, borderRadius: '16px' }}
					>
						<Typography
							sx={{
								m: 2,
								color: caloTheme.palette.neutral900,
								textTransform: 'capitalize',
								fontSize: '19px',
								fontWeight: 600,
								lineHeight: '23px'
							}}
						>
							Components
						</Typography>
						<FoodComponentPickerMUI
							name={name}
							setName={setName}
							childComp={false}
							isLoading={isLoading}
							list={foodComponents}
							isDisabled={isDisabled}
							value={getOrderedComponents(values.components!, allComponents)}
							allComponents={allComponents}
							setFieldValue={setFieldValue}
							onChange={handleComponentsChange}
							isPreBuildCustom={Boolean(values.tags?.includes(FoodDietType.preBuiltCustom))}
						/>
					</Stack>
				)}
			</>
		);
	}
);

export default Components;
