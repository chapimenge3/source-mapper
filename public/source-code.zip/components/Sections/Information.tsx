import { FormikErrors } from 'formik';

import { UpdateFoodReq } from '@calo/dashboard-types';
import { FoodDietType } from '@calo/types';
import { Box, InputLabel, Stack, Typography } from '@mui/material';

import { caloTheme } from 'assets/images/theme/calo';
import { Food, UpdateFoodReqWithIndex } from 'lib/interfaces';
import { IOSSwitch, InputMUI } from '../MUI';
import FoodInformationForm from '../MUI/FoodInformationForm';

interface InformationProps {
	values: UpdateFoodReq;
	setFieldValue: (field: string, value: any, shouldValidate?: boolean | undefined) => void;
	errors: FormikErrors<UpdateFoodReqWithIndex>;
	handleBlur: (e: React.ChangeEvent<any>) => void;
	roles: string[];
	food: Food;
	isDisabled: boolean;
	allSizesFood: Food[];
	getTotalCost: () => string;
	purchasingCostFood: number;
	handleLastUpdatedCost: () => string | undefined;
}

const Information = ({
	values,
	setFieldValue,
	errors,
	handleBlur,
	roles,
	food,
	isDisabled,
	allSizesFood,
	getTotalCost,
	purchasingCostFood,
	handleLastUpdatedCost
}: InformationProps) => {
	return (
		<Stack
			direction="column"
			justifyContent="flex-start"
			alignItems="flex-start"
			sx={{ backgroundColor: caloTheme.palette.white, borderRadius: '16px', pb: '30px' }}
		>
			<Typography
				sx={{
					m: 2,
					color: caloTheme.palette.neutral900,
					textTransform: 'capitalize',
					fontSize: '19px',
					fontWeight: 600,
					lineHeight: '23px'
				}}
			>
				Information
			</Typography>
			<FoodInformationForm
				roles={roles}
				errors={errors}
				values={values}
				formType="update"
				brand={food.brand}
				handleBlur={handleBlur}
				isDisabled={isDisabled}
				allSizesFood={allSizesFood}
				setFieldValue={setFieldValue}
				isPreBuildCustom={Boolean(values.tags?.includes(FoodDietType.preBuiltCustom))}
			/>
			<Stack direction="row" justifyContent="space-between" alignItems="stretch" spacing={2} sx={{ mt: '5px' }}>
				<Stack direction="column" justifyContent="flex-start" alignItems="flex-start" spacing={2} sx={{ width: '55%', ml: 2 }}>
					<Typography sx={{ color: caloTheme.palette.neutral700, fontSize: '12px', lineHeight: '14px' }}>
						Assembly Required
					</Typography>
					<Box>
						<IOSSwitch
							onChange={() => setFieldValue('assemblyRequired', !values.assemblyRequired)}
							sx={{ color: 'white' }}
							checked={values.assemblyRequired}
						/>
					</Box>
				</Stack>
				<Stack direction="column" justifyContent="flex-start" alignItems="flex-start" sx={{ width: '100%' }}>
					<InputMUI
						label="Total Cost"
						placeholder="Total Cost"
						name="price"
						type="number"
						debounce
						sx={{ width: '100%' }}
						value={getTotalCost()}
						onBlur={handleBlur}
						disabled
						inputProps={{ style: { borderRadius: 8, min: 0 } }}
					/>
				</Stack>
				<Stack direction="column" justifyContent="flex-start" alignItems="flex-start" sx={{ width: '100%' }}>
					<InputMUI
						label="Purchasing Cost"
						placeholder="Total Cost"
						name="price"
						type="number"
						debounce
						sx={{ width: '100%' }}
						value={purchasingCostFood}
						disabled
						inputProps={{ style: { borderRadius: 8, min: 0 } }}
					/>
					<InputLabel
						size="small"
						sx={{ mt: '-15px', fontSize: '12px', color: caloTheme.palette.neutral700, whiteSpace: 'normal' }}
					>
						last updated at: {handleLastUpdatedCost()}
					</InputLabel>
				</Stack>
			</Stack>
		</Stack>
	);
};

export default Information;
