import { forwardRef, useState } from 'react';

import { FormikErrors } from 'formik';

import { KitchenLogType, Permission, UpdateFoodReq } from '@calo/dashboard-types';
import { FormHelperText, Stack, Typography } from '@mui/material';

import { getImageUploadLink } from 'actions';
import { caloTheme } from 'assets/images/theme/calo';
import { format, parseISO } from 'date-fns/fp';
import { hasValidCharactersForLanguage } from 'lib/helpers';
import { Food, UpdateFoodReqWithIndex } from 'lib/interfaces';
import { ImageUploaderMUI, InputMUI } from '../';

interface MealInformationProps {
	roles: any;
	food: Food;
	isDisabled: boolean;
	values: UpdateFoodReq;
	errors: FormikErrors<UpdateFoodReqWithIndex>;
	setFieldValue: (field: string, value: any, shouldValidate?: boolean | undefined) => void;
}

const MealInformation = forwardRef(({ values, errors, food, isDisabled, roles, setFieldValue }: MealInformationProps, ref) => {
	const [langAlert, setLangAlert] = useState({ AR: false, EN: false, value: '' });

	const handleInformationFieldChange = (field: string, data: string, lang: 'AR' | 'EN') => {
		const allowSpecialChar = field.includes('description');
		if (hasValidCharactersForLanguage(data, lang, allowSpecialChar) || data === '') {
			setFieldValue(field, data);
			setLangAlert({ ...langAlert, [`${lang}`]: false, value: field });
		} else {
			setFieldValue(field, '');
			setLangAlert({ ...langAlert, [`${lang}`]: true, value: field });
		}
	};

	return (
		<Stack
			direction="column"
			justifyContent="flex-start"
			alignItems="flex-start"
			ref={ref}
			sx={{ backgroundColor: caloTheme.palette.white, borderRadius: '16px' }}
		>
			<Stack direction="row" justifyContent="flex-start" alignItems="flex-start">
				<Typography
					sx={{
						m: 2,
						mb: 3,
						color: caloTheme.palette.neutral900,
						textTransform: 'capitalize',
						fontSize: '19px',
						fontWeight: 600,
						lineHeight: '23px'
					}}
				>
					Meal Information
				</Typography>
				{food.createdAt && (
					<Typography
						sx={{
							my: 3,
							color: caloTheme.palette.neutral900,
							textTransform: 'capitalize',
							fontSize: '12px',
							fontWeight: 400,
							lineHeight: '14px'
						}}
					>
						{`Created on ${format('dd/MM/yyyy')(parseISO(food.createdAt))}`}
					</Typography>
				)}
			</Stack>
			<Stack
				direction="row"
				justifyContent="space-between"
				alignItems="center"
				sx={{ p: '20px', pr: 0, mt: '-30px', width: '100%' }}
			>
				<ImageUploaderMUI
					key={food.id}
					values={{ name: food.name.en, id: food.id, type: KitchenLogType.food }}
					uploadLink={() => getImageUploadLink(`food/${food.id}`)}
					image={`${process.env.REACT_APP_BUCKET_URL}/food/${food.id}/square@1x.jpg`}
					disabled={roles.includes(Permission.UPLOAD_IMAGE)}
				/>
				<Stack direction="column" justifyContent="space-between" alignItems="center" sx={{ width: '40%', ml: 2 }}>
					<Stack direction="column" justifyContent="space-between" alignItems="flex-start" sx={{ width: '100%' }}>
						<InputMUI
							label="Meal Name (English)"
							name="name.en"
							placeholder="Enter Meal Name"
							value={values.name?.en}
							debounce
							InputLabelProps={{
								shrink: true
							}}
							onChange={(data) => {
								handleInformationFieldChange('name.en', data.target.value, 'EN');
							}}
							error={!!(errors.name as any)?.en || (langAlert.EN && langAlert.value === 'name.en')}
							disabled={!roles.includes(Permission.UPDATE_FOOD) || isDisabled}
							sx={{
								width: '100%',
								mb:
									(langAlert.EN && langAlert.value === 'name.en') ||
									(values.name?.en && values.name.en.length > 0 && values.name.en.length < 3)
										? 0
										: '20px'
							}}
							inputProps={{ style: { borderRadius: 8 } }}
						/>
						<FormHelperText id="name.en-error" sx={{ color: caloTheme.palette.red }}>
							{langAlert.EN && langAlert.value === 'name.en' && 'letters should be in English only'}
							{values.name?.en && values.name.en.length > 0 && values.name.en.length < 3 && 'Minimum 3 characters'}
						</FormHelperText>
					</Stack>
					<Stack direction="column" justifyContent="space-between" alignItems="flex-start" sx={{ width: '100%' }}>
						<InputMUI
							label="Description (English - Sticker)"
							name="description.en"
							placeholder="Enter Description"
							value={values.description!.en}
							debounce
							InputLabelProps={{
								shrink: true
							}}
							onChange={(data) => handleInformationFieldChange('description.en', data.target.value, 'EN')}
							disabled={!roles.includes(Permission.UPDATE_FOOD) || isDisabled}
							error={!!(errors.description as any)?.en || (langAlert.EN && langAlert.value === 'description.en')}
							sx={{ width: '100%', mb: langAlert.EN && langAlert.value === 'description.en' ? 0 : '20px' }}
							inputProps={{ style: { borderRadius: 8 } }}
						/>
						<FormHelperText id="description.en-error" sx={{ color: caloTheme.palette.red }}>
							{langAlert.EN && langAlert.value === 'description.en' && 'Letters should be in English only'}
						</FormHelperText>
					</Stack>
					<Stack direction="column" justifyContent="space-between" alignItems="flex-start" sx={{ width: '100%' }}>
						<InputMUI
							label="Long Description (English)"
							name="longDescription.en"
							placeholder="Enter Long Description"
							value={values.longDescription?.en}
							debounce
							InputLabelProps={{
								shrink: true
							}}
							onChange={(data) => setFieldValue('longDescription.en', data.target.value)}
							disabled={!roles.includes(Permission.UPDATE_FOOD) || isDisabled}
							error={!!(errors.longDescription as any)?.en || (langAlert.EN && langAlert.value === 'longDescription.en')}
							sx={{ width: '100%', mb: langAlert.EN && langAlert.value === 'longDescription.en' ? 0 : '20px' }}
							inputProps={{ style: { borderRadius: 8 } }}
							rows={4}
							multiline
						/>
						<FormHelperText id="longDescription.en-error" sx={{ color: caloTheme.palette.red }}>
							{langAlert.EN && langAlert.value === 'longDescription.en' && 'Letters should be in English only'}
						</FormHelperText>
					</Stack>
				</Stack>
				<Stack direction="column" justifyContent="space-between" alignItems="center" sx={{ width: '40%', mx: 2 }}>
					<Stack direction="column" justifyContent="space-between" alignItems="flex-start" sx={{ width: '100%' }}>
						<InputMUI
							label="Meal Name (Arabic)"
							name="name.ar"
							placeholder="Enter Meal Name"
							value={values.name?.ar}
							debounce
							InputLabelProps={{
								shrink: true
							}}
							onChange={(data) => handleInformationFieldChange('name.ar', data.target.value, 'AR')}
							error={!!(errors.name as any)?.ar || (langAlert.AR && langAlert.value === 'name.ar')}
							disabled={!roles.includes(Permission.UPDATE_FOOD) || isDisabled}
							sx={{
								width: '100%',
								mb:
									(langAlert.AR && langAlert.value === 'name.ar') ||
									(values.name?.ar && values.name.ar.length > 0 && values.name.ar.length < 3)
										? 0
										: '20px'
							}}
							inputProps={{ style: { borderRadius: 8 } }}
						/>
						<FormHelperText id="name.ar-error" sx={{ color: caloTheme.palette.red }}>
							{langAlert.AR && langAlert.value === 'name.ar' && 'Letters should be in Arabic only'}
							{values.name?.ar && values.name.ar.length > 0 && values.name.ar.length < 3 && 'Minimum 3 characters'}
						</FormHelperText>
					</Stack>
					<Stack direction="column" justifyContent="space-between" alignItems="flex-start" sx={{ width: '100%' }}>
						<InputMUI
							label="Description (Arabic - Sticker)"
							name="description.ar"
							placeholder="Enter Description"
							value={values.description!.ar}
							debounce
							InputLabelProps={{
								shrink: true
							}}
							onChange={(data) => handleInformationFieldChange('description.ar', data.target.value, 'AR')}
							error={!!(errors.description as any)?.ar || (langAlert.AR && langAlert.value === 'description.ar')}
							disabled={!roles.includes(Permission.UPDATE_FOOD) || isDisabled}
							sx={{ width: '100%', mb: langAlert.AR && langAlert.value === 'description.ar' ? 0 : '20px' }}
							inputProps={{ style: { borderRadius: 8 } }}
						/>
						<FormHelperText id="description.ar-error" sx={{ color: caloTheme.palette.red }}>
							{langAlert.AR && langAlert.value === 'description.ar' && 'Letters should be in Arabic only'}
						</FormHelperText>
					</Stack>
					<Stack direction="column" justifyContent="space-between" alignItems="flex-start" sx={{ width: '100%' }}>
						<InputMUI
							label="Long Description (Arabic)"
							name="longDescription.ar"
							placeholder="Enter Long Description"
							value={values.longDescription?.ar}
							debounce
							InputLabelProps={{
								shrink: true
							}}
							onChange={(data) => setFieldValue('longDescription.ar', data.target.value)}
							error={!!(errors.longDescription as any)?.ar || (langAlert.AR && langAlert.value === 'longDescription.ar')}
							disabled={!roles.includes(Permission.UPDATE_FOOD) || isDisabled}
							sx={{ width: '100%', mb: langAlert.AR && langAlert.value === 'longDescription.ar' ? 0 : '20px' }}
							inputProps={{ style: { borderRadius: 8 } }}
							rows={4}
							multiline
						/>
						<FormHelperText id="longDescription.ar-error" sx={{ color: caloTheme.palette.red }}>
							{langAlert.AR && langAlert.value === 'longDescription.ar' && 'Letters should be in Arabic only'}
						</FormHelperText>
					</Stack>
				</Stack>
			</Stack>
		</Stack>
	);
});

export default MealInformation;
