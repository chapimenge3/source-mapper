import React, { forwardRef } from 'react';

import { FormikErrors } from 'formik';

import { Permission, UpdateFoodReq } from '@calo/dashboard-types';
import { Stack, Typography } from '@mui/material';

import { caloTheme } from 'assets/images/theme/calo';
import { UpdateFoodReqWithIndex } from 'lib/interfaces';
import { InputMUI } from '../MUI';

interface PortioningNotesProps {
	roles: any;
	values: UpdateFoodReq;
	errors: FormikErrors<UpdateFoodReqWithIndex>;
	isDisabled: boolean;
	handleChange: (e: React.ChangeEvent<any>) => void;
}

const PortioningNotes = forwardRef(({ errors, values, roles, isDisabled, handleChange }: PortioningNotesProps, ref) => {
	return (
		<Stack
			direction="column"
			justifyContent="flex-start"
			alignItems="flex-start"
			ref={ref}
			sx={{ backgroundColor: caloTheme.palette.white, borderRadius: '16px' }}
		>
			<Typography
				sx={{
					m: 2,
					color: caloTheme.palette.neutral900,
					textTransform: 'capitalize',
					fontSize: '19px',
					fontWeight: 600,
					lineHeight: '23px'
				}}
			>
				Portioning Notes
			</Typography>
			<Stack direction="row" alignItems="flex-start" sx={{ width: '99%' }}>
				<InputMUI
					label="Portioning Steps"
					name="portioningURL"
					placeholder="Add Link"
					value={values.portioningURL}
					debounce
					InputLabelProps={{
						shrink: true
					}}
					onChange={handleChange}
					error={!!errors.portioningURL}
					disabled={!roles.includes(Permission.UPDATE_FOOD) || isDisabled}
					sx={{ width: '100%', ml: 2, mr: 1, my: 2 }}
					inputProps={{ style: { borderRadius: 8 } }}
					rows={1}
					multiline
				/>
				<InputMUI
					label="Note"
					name="notes"
					placeholder="Add Note"
					value={values.notes}
					debounce
					InputLabelProps={{
						shrink: true
					}}
					onChange={handleChange}
					error={!!errors.notes}
					disabled={!roles.includes(Permission.UPDATE_FOOD) || isDisabled}
					sx={{ width: '100%', ml: 1, mr: 1, my: 2 }}
					inputProps={{ style: { borderRadius: 8 } }}
					rows={1}
					multiline
				/>
			</Stack>
		</Stack>
	);
});

export default PortioningNotes;
