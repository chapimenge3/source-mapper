import { useEffect, useMemo, useRef, useState } from 'react';

import { format } from 'date-fns/fp';
import { flatten, startCase, unionBy } from 'lodash-es';

import { BaseFoodTags, CreateMenuReq, FoodCategory, ProteinFoodTags, TasteFoodTags, UpdateMenuReq } from '@calo/dashboard-types';
import { FoodDietType, FoodType, Kitchen, MenuTagValue } from '@calo/types';
import DateFnsAdapter from '@date-io/date-fns';
import { Autocomplete, Box, LinearProgress, Button as MUIButton, MenuItem, Stack, TextField, Typography } from '@mui/material';
import { DesktopDatePicker, LocalizationProvider } from '@mui/x-date-pickers';

import CloseIcon from '@mui/icons-material/Close';
import { caloTheme } from 'assets/images/theme/calo';
import { handleMealCost } from 'lib/helpers';
import { Food, MenuFood } from 'lib/interfaces';
import InfiniteScroll from 'react-infinite-scroll-component';
import FoodDietTypeTags from '../FoodDietTypeTags';
import Icon from '../Icon';
import { ModalRef } from '../Modal';
import Popup from '../Popup';
import ConfirmationPopup from './ConfirmationPopup';

export interface selectedMenuFilters {
	type: string;
	plan: string;
	protein: string;
	taste: string;
	category: string;
	sandwich: any;
	base: string;
	lastUsed: string;
}

interface AddMealsByFiltersProps {
	foodIds: string[];
	filtersOn: boolean;
	isLoading: boolean;
	hasNextPage: boolean;
	confirmation?: boolean;
	isFetchingNextPage: boolean;
	foodListFilters: Food[];
	addMealsByFiltersRef: any;
	handleClosePopup: () => void;
	values: CreateMenuReq | UpdateMenuReq;
	setFiltersOn: (value: boolean) => void;
	selectedMenuFilters: selectedMenuFilters;
	handleReplaceFood: (food: Food[]) => void;
	replaceFood: { open: boolean; name: string; data?: MenuFood };
	handleFoodChanges: (food: Food[], tags: any) => void;
	setSelectedMenuFilters: (value: selectedMenuFilters) => void;
	fetchNextPage: any;
}

const AddMealsByFilters = ({
	confirmation = false,
	hasNextPage,
	isFetchingNextPage,
	fetchNextPage,
	foodIds,
	handleReplaceFood,
	handleFoodChanges,
	handleClosePopup,
	foodListFilters,
	isLoading,
	filtersOn,
	setFiltersOn,
	values,
	replaceFood,
	setSelectedMenuFilters,
	selectedMenuFilters
}: AddMealsByFiltersProps) => {
	const confirmationRef = useRef<ModalRef>();
	const allFoodList = useMemo(() => {
		const validSizes = ['XS', 'S', 'M', 'L'];
		const unifiedFoodList = unionBy(foodListFilters, 'name.en');
		return unifiedFoodList.filter((food) => validSizes.includes(food.size));
	}, [foodListFilters]);
	const replaceFoodList =
		replaceFood.open && replaceFood.name.length > 0
			? allFoodList.filter((food) => food.name.en !== replaceFood.name)
			: allFoodList;
	const [foodTags, setFoodTags] = useState<MenuTagValue | string>();
	const [selectedFoodReplace, setSelectedFoodReplace] = useState<Food | undefined>(undefined);
	const [searchTerm, setSearchTerm] = useState<string>('');
	const handleAddingMeal = (food: Food) => {
		const allFood = foodListFilters.filter(
			(allFood) => food.name.en === allFood.name.en && ['XS', 'S', 'M', 'L'].includes(allFood.size)
		);
		const tags = allFood.map((f) => {
			const isPreBuiltFood = f.tags.includes(FoodDietType.preBuiltCustom);
			const value = [];
			if (isPreBuiltFood) {
				value.push(MenuTagValue.CUSTOMIZABLE);
			}
			if (foodTags) {
				value.push(foodTags);
			}
			return [{ foodId: f.id, value }];
		});
		handleFoodChanges(allFood as any, flatten(tags));
		setFoodTags('');
	};

	const handleCalculateMealCost = (meal: any) => handleMealCost(meal.name.en, foodListFilters, values.kitchen || Kitchen.BH1);

	const observer = useRef<IntersectionObserver | null>(null);
	const lastFoodElementRef = useRef<HTMLDivElement | null>(null);

	const handleObserver = (entities: any) => {
		const target = entities[0];
		if (target?.isIntersecting && hasNextPage) {
			fetchNextPage();
		}
	};

	useEffect(() => {
		observer.current = new IntersectionObserver(handleObserver, {
			threshold: 1.0
		});
		if (lastFoodElementRef.current) {
			observer.current.observe(lastFoodElementRef.current);
		}
		return () => {
			if (lastFoodElementRef.current) {
				observer.current?.unobserve(lastFoodElementRef.current);
			}
		};
	}, [replaceFoodList.length]);

	const handleAction = (food: Food) => {
		if (replaceFood.open) {
			if (confirmation) {
				setSelectedFoodReplace(food);
				confirmationRef.current?.open();
			} else {
				handleReplaceFood(
					foodListFilters.filter((allFood) => food.name.en === allFood.name.en && ['XS', 'S', 'M', 'L'].includes(allFood.size))
				);
			}
		} else {
			handleAddingMeal(food);
		}
	};

	console.log(replaceFood.data ?? '');

	return (
		<Box>
			<Box
				display={'flex'}
				flexDirection={'column'}
				sx={{
					[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
						flexDirection: 'column',
						mt: 2
					},
					[caloTheme.breakpoints.down(caloTheme.breakpoints.values.md)]: {
						flexDirection: 'column',
						mt: 2
					}
				}}
			>
				<Stack
					display={'flex'}
					flexDirection={'row'}
					justifyContent={'space-between'}
					sx={{
						mb: 1,
						mt: 1,
						[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
							flexDirection: 'row'
						}
					}}
				>
					<TextField
						select
						type="text"
						label="Type"
						data-test="menu-new-type-select"
						value={selectedMenuFilters.type === undefined ? 'Any' : selectedMenuFilters.type}
						placeholder="Select Type"
						id="menu-new-type-filters-select"
						sx={{
							width: '100%',
							mr: 2,
							[caloTheme.breakpoints.down(caloTheme.breakpoints.values.md)]: {
								mb: 1
							}
						}}
						onChange={(data: any) =>
							setSelectedMenuFilters({
								...selectedMenuFilters,
								type: data.target.value === 'Any' ? undefined : data.target.value
							})
						}
						InputProps={{ inputProps: { style: { borderRadius: 8 }, placeholder: 'Choose' }, style: { borderRadius: 8 } }}
					>
						<MenuItem key={'Any'} value={'Any'}>
							{startCase('Any')}
						</MenuItem>
						{Object.values(FoodType).map((type) => (
							<MenuItem key={type} value={type}>
								{startCase(type)}
							</MenuItem>
						))}
					</TextField>

					<TextField
						select
						type="text"
						label="Plan"
						data-test="menu-new-plan-select"
						value={selectedMenuFilters.plan === undefined ? 'Any' : selectedMenuFilters.plan}
						placeholder="Select Plan"
						id="menu-new-plan-filters-select"
						sx={{
							width: '100%',
							mr: 2,
							[caloTheme.breakpoints.down(caloTheme.breakpoints.values.md)]: {
								mb: 1
							}
						}}
						onChange={(data: any) =>
							setSelectedMenuFilters({
								...selectedMenuFilters,
								plan: data.target.value === 'Any' ? undefined : data.target.value
							})
						}
						InputProps={{ inputProps: { style: { borderRadius: 8 } }, style: { borderRadius: 8 } }}
					>
						<MenuItem key={'Any'} value={'Any'}>
							{startCase('Any')}
						</MenuItem>

						{Object.values(FoodDietType).map((plan) => (
							<MenuItem key={plan} value={plan}>
								{startCase(plan)}
							</MenuItem>
						))}
					</TextField>

					<LocalizationProvider dateAdapter={DateFnsAdapter} sx={{ width: '100%' }}>
						<DesktopDatePicker
							inputFormat="dd/MM/yyyy"
							label={'Last Used (Optional)'}
							value={selectedMenuFilters.lastUsed || null}
							onChange={(date: any) =>
								setSelectedMenuFilters({ ...selectedMenuFilters, lastUsed: format('yyyy-MM-dd')(date as Date) })
							}
							renderInput={(params) => <TextField {...params} style={{ width: '100%', marginRight: '16px', borderRadius: 12 }} />}
						/>
					</LocalizationProvider>
				</Stack>

				<Stack
					display={'flex'}
					flexDirection={'row'}
					justifyContent={'space-between'}
					sx={{
						my: 1,
						[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
							flexDirection: 'row'
						}
					}}
				>
					<TextField
						select
						type="text"
						label="Protein"
						data-test="menu-new-protein-select"
						value={selectedMenuFilters.protein === undefined ? 'Any' : selectedMenuFilters.protein}
						placeholder="Select Protein"
						id="menu-new-protein-filters-select"
						sx={{
							width: '260px',
							mr: 2,
							[caloTheme.breakpoints.down(caloTheme.breakpoints.values.md)]: {
								mb: 1
							}
						}}
						onChange={(data: any) =>
							setSelectedMenuFilters({
								...selectedMenuFilters,
								protein: data.target.value === 'Any' ? undefined : data.target.value
							})
						}
						InputProps={{ inputProps: { style: { borderRadius: 8 } }, style: { borderRadius: 8 } }}
					>
						<MenuItem key={'Any'} value={'Any'}>
							{startCase('Any')}
						</MenuItem>
						{Object.values(ProteinFoodTags).map((protein) => (
							<MenuItem key={protein} value={protein}>
								{startCase(protein)}
							</MenuItem>
						))}
					</TextField>

					<TextField
						select
						type="text"
						label="Taste"
						data-test="menu-new-taste-select"
						value={selectedMenuFilters.taste === undefined ? 'Any' : selectedMenuFilters.taste}
						placeholder="Select Taste"
						id="menu-new-taste-filters-select"
						sx={{
							width: '260px',
							mr: 2,
							[caloTheme.breakpoints.down(caloTheme.breakpoints.values.md)]: {
								flexDirection: 'column',
								mb: 1
							}
						}}
						onChange={(data: any) =>
							setSelectedMenuFilters({
								...selectedMenuFilters,
								taste: data.target.value === 'Any' ? undefined : data.target.value
							})
						}
						InputProps={{ inputProps: { style: { borderRadius: 8 } }, style: { borderRadius: 8 } }}
					>
						<MenuItem key={'Any'} value={'Any'}>
							{startCase('Any')}
						</MenuItem>
						{Object.values(TasteFoodTags).map((taste) => (
							<MenuItem key={taste} value={taste}>
								{startCase(taste)}
							</MenuItem>
						))}
					</TextField>

					<TextField
						select
						type="text"
						label="Base"
						data-test="menu-new-base-select"
						value={selectedMenuFilters.base === undefined ? 'Any' : selectedMenuFilters.base}
						placeholder="Select Base"
						id="menu-new-base-filters-select"
						sx={{
							width: '260px',
							mr: 2,
							[caloTheme.breakpoints.down(caloTheme.breakpoints.values.md)]: {
								flexDirection: 'column',
								mb: 1
							}
						}}
						onChange={(data: any) =>
							setSelectedMenuFilters({
								...selectedMenuFilters,
								base: data.target.value === 'Any' ? undefined : data.target.value
							})
						}
						InputProps={{ inputProps: { style: { borderRadius: 8 } }, style: { borderRadius: 8 } }}
					>
						<MenuItem key={'Any'} value={'Any'}>
							{startCase('Any')}
						</MenuItem>
						{Object.values(BaseFoodTags).map((base) => (
							<MenuItem key={base} value={base}>
								{startCase(base)}
							</MenuItem>
						))}
					</TextField>

					<TextField
						select
						type="text"
						label="Sandwich"
						data-test="menu-new-sandwich-select"
						value={selectedMenuFilters.sandwich === undefined ? 'Any' : selectedMenuFilters.sandwich ? 'Yes' : 'No'}
						placeholder="Yes/No"
						id="menu-new-sandwich-filters-select"
						sx={{
							width: '260px',
							mr: 2,
							[caloTheme.breakpoints.down(caloTheme.breakpoints.values.md)]: {
								flexDirection: 'column',
								mb: 1
							}
						}}
						onChange={(data: any) => {
							setSelectedMenuFilters({
								...selectedMenuFilters,
								sandwich: data.target.value === 'Any' ? undefined : data.target.value === 'Yes' ? true : false
							});
						}}
						InputProps={{ inputProps: { style: { borderRadius: 8 } }, style: { borderRadius: 8 } }}
					>
						{[
							{ label: 'Any', value: 'Any' },
							{ label: 'Yes', value: 'Yes' },
							{ label: 'No', value: 'No' }
						].map((sandwich) => (
							<MenuItem key={sandwich.label} value={sandwich.value}>
								{startCase(sandwich.label)}
							</MenuItem>
						))}
					</TextField>
				</Stack>

				<Autocomplete
					options={['Any', ...Object.values(FoodCategory)]}
					getOptionLabel={(option) => (option === 'Any' ? 'Any' : startCase(option))}
					value={selectedMenuFilters.category || 'Any'}
					onChange={(event, newValue) => {
						const selectedCategory = newValue === 'Any' || newValue === null ? '' : (newValue as string);

						setSelectedMenuFilters({
							...selectedMenuFilters,
							category: selectedCategory
						});

						setSearchTerm(selectedCategory);
					}}
					renderInput={(params) => (
						<TextField
							{...params}
							label="Category"
							placeholder="Type to search..."
							sx={{
								width: '99%',
								mr: 2,
								marginTop: 1,
								mb: 1,
								[caloTheme.breakpoints.down(caloTheme.breakpoints.values.md)]: {
									mb: 1
								}
							}}
							InputProps={{
								...params.InputProps,
								style: { borderRadius: 8 }
							}}
						/>
					)}
				/>

				{searchTerm && (
					<Stack
						direction="row"
						alignItems="center"
						sx={{
							backgroundColor: caloTheme.palette.secondaryBlue100,
							mr: 1,
							textTransform: 'capitalize',
							color: caloTheme.palette.secondaryBlue700,
							borderRadius: '37px',
							padding: '4px 12px 4px 12px',
							fontWeight: 600,
							fontSize: '14px',
							lineHeight: '17px',
							gap: '8px',
							width: searchTerm.length * 10 + 60
						}}
					>
						<Typography>{searchTerm}</Typography>
						<MUIButton
							onClick={() => {
								setSelectedMenuFilters({ ...selectedMenuFilters, category: '' });
								setSearchTerm('');
							}}
							sx={{ paddingLeft: '0px' }}
						>
							<CloseIcon sx={{ color: caloTheme.palette.secondaryBlue700 }} />
						</MUIButton>
					</Stack>
				)}
			</Box>
			<InfiniteScroll
				dataLength={replaceFoodList.filter((food) => !foodIds?.includes(food.id)).length}
				next={fetchNextPage}
				hasMore={hasNextPage}
				loader={isFetchingNextPage || isLoading}
				scrollableTarget="scrollable"
			>
				{isLoading ? (
					<Box display={'flex'} flexDirection={'row'} my={3} justifyContent={'center'}>
						<Stack>
							<Typography display="flex" flexDirection={'column'} sx={{ width: '120px', height: '48px' }}>
								<Icon name="calo" size={12} className="w-64 -ml-24 " />
							</Typography>
							<LinearProgress
								color="inherit"
								value={80}
								sx={{ mt: 2 }}
								style={{ color: caloTheme.palette.primary500, backgroundColor: caloTheme.palette.primary50 }}
							/>
						</Stack>
					</Box>
				) : replaceFoodList && replaceFoodList.length > 0 ? (
					<Box
						display={'flex'}
						flexDirection={'column'}
						sx={{
							[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
								minWidth: '100%',
								maxHeight: '100%'
							},
							padding: 2,
							overflow: 'auto',
							minWidth: '800px',
							borderRadius: '8px',
							maxHeight: '480px'
						}}
					>
						{replaceFoodList
							.filter((food) => !foodIds?.includes(food.id))
							.map((food, index) => (
								<Box
									key={food.id}
									sx={{
										borderBottomWidth: 2,
										borderBottomColor: caloTheme.palette.neutral100,
										[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
											minWidth: '100%',
											maxHeight: '70vh'
										},
										width: '100%',
										display: 'flex',
										flexDirection: 'row',
										padding: 1,
										mb: 1,
										minHeight: '130px'
									}}
								>
									<Stack
										display={'flex'}
										flexDirection={'column'}
										width={'100%'}
										ref={
											index === replaceFoodList.filter((food) => !foodIds?.includes(food.id)).length - 1
												? lastFoodElementRef
												: null
										}
									>
										<Box
											display={'flex'}
											flexDirection={'row'}
											width={'100%'}
											sx={{
												marginTop: 1
											}}
										>
											<Stack sx={{ width: '100%', display: 'flex', flexDirection: 'row', justifyContent: 'space-between' }}>
												<Typography
													variant="h6"
													sx={{
														fontFamily: caloTheme.typography.fontFamily,
														fontWeight: 600,
														fontSize: '19px',
														lineHeight: '23px',
														textTransform: 'capitalize',
														width: '40%'
													}}
												>{`${food.name.en}`}</Typography>
												<Typography
													sx={{
														fontFamily: caloTheme.typography.fontFamily,
														fontWeight: 600,
														fontSize: '16px',
														lineHeight: '19px',
														color: handleCalculateMealCost(food) > 26 ? caloTheme.palette.red : caloTheme.palette.black,
														width: '15%'
													}}
													variant={'h6'}
												>
													{handleCalculateMealCost(food)}%
												</Typography>
												<Typography display={'flex'} flexDirection={'row'} sx={{ width: '15%' }}>
													<Icon name="star" size={4} />
													<Typography sx={{ ml: '6px', mt: '-2px' }}>
														{!!food.totalRating && !!food.numberOfRatings
															? (food.totalRating / food.numberOfRatings).toFixed(2)
															: 0}
														({food.numberOfRatings ? food.numberOfRatings : 0})
													</Typography>
												</Typography>
												<Typography
													variant="h6"
													sx={{
														width: '15%',
														fontFamily: caloTheme.typography.fontFamily,
														fontWeight: 400,
														fontSize: '14px',
														lineHeight: '17px',
														textTransform: 'capitalize'
													}}
												>
													{food.type.map((r) => r !== FoodType.dinner && (r.includes(FoodType.lunch) ? 'Lunch & Dinner' : r))}
												</Typography>
												<Typography
													variant="h1"
													sx={{
														justifyContent: 'end',
														width: '15%',
														fontFamily: caloTheme.typography.fontFamily,
														fontWeight: 400,
														fontSize: '14px',
														lineHeight: '23px',
														display: 'flex',
														lexDirection: 'column',
														mt: '-4px'
													}}
												>
													{food.tags.map((tag) => (
														<FoodDietTypeTags key={tag} tag={tag} />
													))}
												</Typography>
											</Stack>
										</Box>
										<Box display={'flex'} flexDirection={'row'} justifyContent={'space-between'} sx={{ mt: 4 }}>
											<Stack
												sx={{
													width: '90%',
													display: 'flex',
													flexDirection: 'row'
												}}
											>
												{food.foodTags?.map((tag) =>
													tag.value.map((tagOption) => (
														<Typography
															sx={{
																backgroundColor: caloTheme.palette.primary100,
																mr: 1,
																textTransform: 'capitalize',
																color: caloTheme.palette.primary700,
																borderRadius: '37px',
																padding: '8px 12px 8px 12px',
																fontWeight: 600,
																fontSize: '14px',
																lineHeight: '17px',
																gap: '8px'
															}}
														>
															{tagOption}
														</Typography>
													))
												)}
											</Stack>
											{food.usedOnMenu && food.usedOnMenu.length > 0 && (
												<Stack
													sx={{
														width: '20%',
														display: 'flex',
														flexDirection: 'row'
													}}
												>
													<Typography
														variant="h1"
														sx={{
															fontFamily: caloTheme.typography.fontFamily,
															fontWeight: 400,
															fontSize: '14px',
															lineHeight: '17px'
														}}
													>
														Last Used: {food.usedOnMenu[food.usedOnMenu.length - 1].date}
													</Typography>
												</Stack>
											)}
										</Box>
									</Stack>
									<Box sx={{ widht: '100%', marginY: 'auto' }}>
										<MUIButton
											variant="outlined"
											sx={{
												ml: 4,
												textTransform: 'capitalize',
												width: '92px',
												height: '48px',
												lineHeight: '21px',
												fontWeight: 400,
												fontSize: '18px',
												borderRadius: '8px',
												borderColor: caloTheme.palette.primary500,
												color: caloTheme.palette.primary500,
												'&:hover': {
													color: caloTheme.palette.primary600,
													borderColor: caloTheme.palette.primary600
												}
											}}
											disabled={isLoading}
											onClick={() => handleAction(food)}
										>
											{replaceFood.open ? 'Select' : 'Add'}
										</MUIButton>
									</Box>
								</Box>
							))}
					</Box>
				) : replaceFoodList.length === 0 && filtersOn ? (
					<Box display={'flex'} flexDirection={'row'} my={3} justifyContent={'center'}>
						<Typography
							variant="h5"
							sx={{
								fontFamily: caloTheme.typography.fontFamily,
								color: caloTheme.palette.neutral500,
								fontSize: '23px',
								fontWeight: 600,
								lineHeight: '28px',
								textAlign: 'center'
							}}
						>
							No Meals found for the selected filters
						</Typography>
					</Box>
				) : (
					<></>
				)}
			</InfiniteScroll>
			{
				<Box display={'flex'} flexDirection={'row'} m={2} justifyContent={'center'}>
					<MUIButton
						variant="contained"
						data-test="menu-new-modal-confirm-button"
						sx={{
							width: '262px',
							height: '51px',
							lineHeight: '17px',
							fontWeight: 600,
							fontSize: '14px',
							borderRadius: '8px',
							backgroundColor: caloTheme.palette.primary500,
							borderColor: caloTheme.palette.primary500,
							color: 'white',
							boxShadow: 'none',
							'&:hover': {
								boxShadow: 'none',
								backgroundColor: caloTheme.palette.primary600,
								borderColor: caloTheme.palette.primary600
							}
						}}
						disabled={
							isFetchingNextPage ||
							(!values.brand && !values.country && !values.day && !values.kitchen && selectedMenuFilters.type.length === 0)
						}
						onClick={() => (filtersOn ? handleClosePopup() : setFiltersOn(true))}
					>
						{filtersOn ? (isFetchingNextPage ? 'Loading...' : 'Done') : 'Filter Meals'}
					</MUIButton>
				</Box>
			}
			<Popup maxWidth="sm" title={'Confirm Changes'} ref={confirmationRef} onClose={() => handleClosePopup()} fullWidth>
				<ConfirmationPopup
					replaceFood={replaceFood}
					confirmationRef={confirmationRef}
					foodListFilters={foodListFilters}
					handleReplaceFood={handleReplaceFood}
					selectedFoodReplace={selectedFoodReplace}
				/>
			</Popup>
		</Box>
	);
};
export default AddMealsByFilters;
