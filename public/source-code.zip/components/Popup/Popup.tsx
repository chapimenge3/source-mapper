import { forwardRef, ReactNode, useImperativeHandle, useState } from 'react';

import { Breakpoint, Dialog, DialogContent, DialogTitle, Stack, Typography, useMediaQuery } from '@mui/material';

import { caloTheme } from 'assets/images/theme/calo';

interface PopupProps {
	title?: string;
	onClose?: () => void;
	children: ReactNode;
	divider?: boolean;
	fullWidth?: boolean;
	maxWidth?: Breakpoint;
	subTitle?: ReactNode;
	info?: any;
}

const Popup = forwardRef(({ info, fullWidth, subTitle, maxWidth, divider, title, children, onClose }: PopupProps, ref) => {
	const [openDialog, setOpenDialog] = useState(false);
	const fullScreen = useMediaQuery(caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg));

	useImperativeHandle(ref, () => ({
		open: () => {
			setOpenDialog(true);
		},
		close: () => {
			setOpenDialog(false);
		}
	}));

	const handleClose = () => {
		setOpenDialog(false);
		onClose && onClose();
	};

	return (
		<Dialog
			maxWidth={maxWidth}
			open={openDialog}
			fullWidth={fullWidth}
			onClose={handleClose}
			sx={{
				borderRadius: '8px'
			}}
		>
			{title && (
				<DialogTitle>
					<Stack display={'flex'} flexDirection={'row'} justifyContent={'space-between'}>
						<Typography component="div" sx={{ width: 'full', fontSize: '26px', lineHeight: '47px', fontWeight: 400 }}>
							{title}
						</Typography>
						{info && (
							<Typography component="div" sx={{ width: 'full', fontSize: '26px', lineHeight: '47px', fontWeight: 400 }}>
								{info}
							</Typography>
						)}
					</Stack>
					{subTitle && (
						<Typography component="div" sx={{ width: 'full', fontSize: '26px', lineHeight: '47px', fontWeight: 400 }}>
							{subTitle}
						</Typography>
					)}
				</DialogTitle>
			)}
			<DialogContent dividers={divider} sx={{ width: 'full', height: fullScreen ? '400px' : 'auto', overflow: 'auto' }}>
				<Stack sx={{ height: '100%' }}>{children}</Stack>
			</DialogContent>
		</Dialog>
	);
});
export default Popup;
