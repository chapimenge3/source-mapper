import { FoodPackageElementReq, Permission } from '@calo/dashboard-types';
import { Dictionary } from '@calo/types';
import { useUserRoles } from 'lib/hooks';
import { round, sumBy } from 'lodash-es';
import { Input, Select } from '..';

interface PackageElementsPickerProps {
	onChange: (rows: any[]) => void;
	value: any[];
	keyed: Dictionary<FoodPackageElementReq>;
	list: any[];
}

const PackageElementsPicker = ({ value, onChange, keyed, list }: PackageElementsPickerProps) => {
	const roles = useUserRoles();
	const handleChange = (id: string, quantity: number) => {
		const i = value.findIndex((r) => r.id === id);
		onChange([...value.slice(0, i), { ...value[i], quantity }, ...value.slice(i + 1)]);
	};

	const modifyFoodComponents = (data: any[]) => {
		let newList: any[] = [...value];
		const existing = newList.map((row) => row.id);
		const newValues = (data || []).map((row) => row.value);

		if (newValues.length > newList.length!) {
			// add
			newList.push(
				...data
					.filter((row) => !existing.includes(row.value))
					.map((row) => ({
						id: row.value,
						quantity: 1
					}))
			);
		} else {
			// remove
			newList = newList.filter((row) => newValues.includes(row.id));
		}
		onChange(newList);
	};

	return (
		<table className="table is-fullwidth is-striped is-hoverable is-sortable is-fullwidth">
			<thead>
				<tr>
					<th>Element</th>
					<th>Quantity</th>
					<th>Cost</th>
					<th>Size</th>
					<th>Total Cost</th>
				</tr>
			</thead>
			<tbody>
				{value.map((row) => (
					<tr key={row.id}>
						<td>{keyed[row.id]?.name}</td>
						<td>
							<Input
								type="number"
								value={row.quantity}
								onChange={(e) => handleChange(row.id, parseFloat(e.target.value))}
								min={0}
								step="any"
								disabled={!roles.includes(Permission.UPDATE_FOOD_PACKAGE)}
							/>
						</td>
						<td>{keyed[row.id]?.cost}</td>
						<td>{keyed[row.id]?.size}</td>
						<td>{round(keyed[row.id]?.cost * row.quantity, 6)}</td>
					</tr>
				))}
			</tbody>
			<tfoot>
				<tr>
					<th colSpan={4}>
						<Select
							isMulti
							onChange={modifyFoodComponents}
							options={list.map((fk) => ({
								value: fk.id,
								label: typeof fk.name === 'string' && fk.name
							}))}
							isDisabled={!roles.includes(Permission.UPDATE_FOOD_PACKAGE)}
							value={value.map((row) => row.id)}
						/>
					</th>
					<th>
						{round(
							sumBy(value, (fk) => keyed[fk.id]?.cost * fk.quantity),
							6
						)}
					</th>
				</tr>
			</tfoot>
		</table>
	);
};

export default PackageElementsPicker;
