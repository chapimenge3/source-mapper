import React, { useCallback, useEffect, useState } from 'react';

import { compact, uniq, uniqBy } from 'lodash-es';
import { useQuery } from 'react-query';

import { Brand, Country, FoodComponent, FoodComponentType, Kitchen } from '@calo/types';
import RemoveCircleOutlineIcon from '@mui/icons-material/RemoveCircleOutline';
import { Box, FormControl, FormControlLabel, Grid, Radio, RadioGroup, Stack, Typography } from '@mui/material';

import { getListWithParams } from 'actions';
import { caloTheme } from 'assets/images/theme/calo';
import CaloLoader from '../CaloLoader';
import styles from './styles';

interface CustomizeMealPopupProps {
	brand: Brand;
	kitchen: Kitchen;
	country: Country;
	components: FoodComponent[];
	customFoodComponents: FoodComponent[];
	selectedRemovedComponentIdList: string[];
	setCustomFoodComponents: (value: FoodComponent[]) => void;
	selectedSwappedComponent: { oldId: string; newId: string }[];
	setSelectedSwappedComponent: (value: { oldId: string; newId: string }[]) => void;
	setSelectedRemovedComponentIdList: (value: string[]) => void;
	isPreBuiltMeal: boolean;
	selectedComponent: FoodComponent | undefined;
	setSelectedComponent: (value: FoodComponent | undefined) => void;
	allCustomFoodComponents: FoodComponent[];
	caloKidsComponents: FoodComponent[];
}

const CustomizeMealPopup: React.FC<CustomizeMealPopupProps> = ({
	components,
	country,
	brand,
	kitchen,
	customFoodComponents,
	setCustomFoodComponents,
	setSelectedRemovedComponentIdList,
	selectedRemovedComponentIdList,
	selectedSwappedComponent,
	setSelectedSwappedComponent,
	isPreBuiltMeal,
	selectedComponent,
	setSelectedComponent,
	allCustomFoodComponents,
	caloKidsComponents
}) => {
	const [foodComponentsData, setFoodComponentsData] = useState<FoodComponent[] | undefined>(undefined);
	const [selectedComponentIndex, setSelectedComponentIndex] = useState<number>(0);
	const componentsIds = components.map((component) => component.id);

	const { data: foodCompData, isLoading } = useQuery<any, Error, { data: FoodComponent[] }>(
		[
			'food-components',
			{
				limit: components.length,
				filters: {
					withChildComponents: false,
					ids: componentsIds,
					country: country,
					brand: brand,
					kitchen: kitchen
				}
			}
		],
		getListWithParams,
		{
			retry: false,
			keepPreviousData: true,
			enabled: componentsIds.length > 0
		}
	);

	useEffect(() => {
		const updatedComponents = [...customFoodComponents];
		setCustomFoodComponents(uniqBy(updatedComponents, 'name.en'));
	}, [selectedSwappedComponent, selectedComponent, selectedRemovedComponentIdList]);

	useEffect(() => {
		if (!selectedSwappedComponent) return;
		const swappedComponentIds = selectedSwappedComponent.map((comp) => comp.oldId);
		const updatedComponents = foodCompData?.data?.map((item) => {
			if (swappedComponentIds.includes(item.id) && !selectedRemovedComponentIdList.includes(item.id)) {
				const swappedAction = selectedSwappedComponent.find((comp) => comp.oldId === item.id);
				const customComp =
					caloKidsComponents.length > 0
						? caloKidsComponents.find((comp) => comp.id === swappedAction?.newId)
						: allCustomFoodComponents.find((custom) => custom.id === swappedAction?.newId);
				return customComp;
			} else {
				return item;
			}
		});
		setFoodComponentsData(compact(updatedComponents));
	}, [selectedSwappedComponent, selectedRemovedComponentIdList, allCustomFoodComponents, caloKidsComponents]);

	const handleRemove = (componentId: string) => {
		if (selectedRemovedComponentIdList.includes(componentId)) {
			setSelectedRemovedComponentIdList(uniq(selectedRemovedComponentIdList.filter((id) => id !== componentId)));
		} else {
			setSelectedRemovedComponentIdList(uniq([...selectedRemovedComponentIdList, componentId]));
		}
	};

	const handleRemoveComponents = useCallback(
		(componentId: string) => {
			const originalComponents = foodCompData?.data.map((component) => component.id);
			const selectedComponent = foodCompData?.data[selectedComponentIndex];
			const swappedAction = selectedSwappedComponent.find(
				(com) => componentId === com.newId && com.oldId === selectedComponent?.id
			);

			if (selectedComponent?.id !== componentId && swappedAction) {
				const updatedSwappedComponents = selectedSwappedComponent.filter(
					(item) => item.newId !== swappedAction.newId && selectedComponent?.id === swappedAction.oldId
				);

				handleRemove(swappedAction.oldId);
				setSelectedSwappedComponent(updatedSwappedComponents);
				const customData = foodCompData?.data.find((component) => component.id === swappedAction.oldId);
				setSelectedComponent(customData);
			} else if (originalComponents?.includes(componentId) && selectedComponent?.id === componentId) {
				if (selectedSwappedComponent.some((component) => component.oldId === componentId)) {
					const updatedSwappedComponents = selectedSwappedComponent.filter((item) => item.oldId !== componentId);
					setSelectedSwappedComponent(updatedSwappedComponents);

					const customData = foodCompData?.data.find(
						(component, index) => component.id === componentId && index === selectedComponentIndex
					);
					setSelectedComponent(customData);
				}

				handleRemove(componentId);
			}
		},
		[selectedSwappedComponent, selectedComponentIndex, selectedRemovedComponentIdList]
	);

	const handleSwapComponent = useCallback(
		(oldId: string, newId: string, isCaloKids?: boolean) => {
			const currentComponentData = foodCompData?.data[selectedComponentIndex];
			const existingSwapped = selectedSwappedComponent.some(
				(swapped) => swapped.oldId === oldId && swapped.newId === newId && currentComponentData?.id === oldId
			);
			const undoSwap = selectedSwappedComponent.some(
				(swapped) => swapped.oldId === newId && swapped.newId === oldId && currentComponentData?.id === swapped.oldId
			);
			const swapSwapped = selectedSwappedComponent.some(
				(swapped) => swapped.newId === oldId && currentComponentData?.id !== newId
			);
			const swapOriginalDiff = selectedSwappedComponent.some(
				(swapped) => swapped.newId === oldId && currentComponentData?.id !== oldId
			);
			const originalRemoved = selectedRemovedComponentIdList.includes(oldId) && currentComponentData?.id === oldId;
			let updatedList = [...selectedSwappedComponent];
			let selectedSwapComponent = currentComponentData;

			if (!existingSwapped && !undoSwap && !swapSwapped && !originalRemoved) {
				updatedList.push({ oldId, newId });
				selectedSwapComponent = isCaloKids
					? caloKidsComponents.find((comp) => comp.id === newId)
					: allCustomFoodComponents.find((sauce) => sauce.id === newId)!;
			} else if (undoSwap && !swapSwapped) {
				updatedList = updatedList.filter((swapped) => swapped.oldId !== newId && swapped.newId !== oldId);
				selectedSwapComponent = foodCompData?.data.find((component) => component.id === newId)!;
			} else if (swapSwapped && !swapOriginalDiff && existingSwapped) {
				updatedList = updatedList.map((swapped) =>
					swapped.newId === oldId && swapped.oldId === currentComponentData?.id
						? { oldId: currentComponentData?.id, newId }
						: swapped
				);
				selectedSwapComponent = isCaloKids
					? caloKidsComponents.find((comp) => comp.id === newId)
					: allCustomFoodComponents.find((sauce) => sauce.id === newId)!;
			} else if (swapOriginalDiff) {
				updatedList = updatedList.map((swapped) =>
					swapped.newId === oldId && currentComponentData?.id !== newId && currentComponentData?.id === swapped.oldId
						? { oldId: currentComponentData?.id, newId }
						: swapped
				);
				selectedSwapComponent = isCaloKids
					? caloKidsComponents.find((comp) => comp.id === newId)
					: allCustomFoodComponents.find((component) => component.id === newId)!;
			} else {
				if (originalRemoved) {
					setSelectedRemovedComponentIdList(selectedRemovedComponentIdList.filter((id) => id !== oldId));
				}
				selectedSwapComponent = isCaloKids
					? caloKidsComponents.find((comp) => comp.id === newId)
					: allCustomFoodComponents.find((sauce) => sauce.id === newId)!;
				updatedList.push({ oldId, newId });
			}
			setSelectedSwappedComponent(updatedList);
			setSelectedComponent(selectedSwapComponent);
		},
		[selectedSwappedComponent, selectedComponent, selectedRemovedComponentIdList]
	);

	const handleOriginalComponent = (originalComponentId: string) => {
		if (selectedComponent?.id === originalComponentId && selectedRemovedComponentIdList.includes(originalComponentId)) {
			handleRemoveComponents(originalComponentId);
		} else if (selectedComponent?.id !== originalComponentId) {
			handleSwapComponent(selectedComponent!.id, originalComponentId);
		}
	};

	const componentCard = (component: FoodComponent, radioCheck: boolean) => (
		<Stack sx={{ ...styles.imageContainer }}>
			{radioCheck && (
				<>
					{foodCompData?.data[selectedComponentIndex].id === component.id && (
						<Stack
							sx={{
								...styles.originalBox
							}}
						>
							<Typography
								sx={{
									...styles.originalText
								}}
							>
								Original
							</Typography>
						</Stack>
					)}
					<FormControl sx={{ ...styles.formControlBox }}>
						<RadioGroup>
							<FormControlLabel
								label={''}
								control={
									<Radio
										color="default"
										onClick={() => null}
										sx={{
											...styles.radioButton,
											color: component.id === selectedComponent?.id ? caloTheme.palette.primary500 : caloTheme.palette.neutral500
										}}
									/>
								}
								checked={component.id === selectedComponent?.id && !selectedRemovedComponentIdList.includes(component.id)}
							/>
						</RadioGroup>
					</FormControl>
				</>
			)}
			<Stack sx={{ ...styles.imageBox }}>
				<figure className="image">
					<img
						alt={`${component.name?.en} Image`}
						className="object-cover rounded-s-md"
						onError={(e: any) => (e.target.src = 'https://via.placeholder.com/120')}
						src={`${process.env.REACT_APP_BUCKET_URL}/food-component/${component.id}/square@1x.jpg`}
					/>
				</figure>
			</Stack>
			<Typography sx={{ ...styles.componentNameText }}> {component?.name?.en || ''} </Typography>
		</Stack>
	);

	const renderComponentCard = (component: FoodComponent, index: number) => {
		const isRemoved = selectedRemovedComponentIdList.includes(component?.id) && foodCompData?.data[index]?.id === component.id;
		const isSwapped = foodCompData?.data[index]?.id !== component.id;
		const isSelected = selectedComponent?.id === component?.id && index === selectedComponentIndex;
		const borderColor =
			isSelected && !isRemoved
				? caloTheme.palette.primary500
				: isRemoved && isSelected
					? caloTheme.palette.red
					: caloTheme.palette.neutral100;
		return (
			<Grid item key={index}>
				<Box
					key={component.id}
					onClick={() => {
						setSelectedComponent(component);
						setSelectedComponentIndex(index);
					}}
					sx={{ ...styles.componentCard, borderColor }}
				>
					{isSwapped && !isRemoved && (
						<Stack sx={{ ...styles.removeComponentBox }}>
							<Typography sx={{ ...styles.swappedText }}>Swapped</Typography>
						</Stack>
					)}
					{selectedRemovedComponentIdList?.includes(component.id) && foodCompData?.data[index].id === component.id && (
						<Stack sx={{ ...styles.removeComponentBox }}>
							<Typography sx={{ ...styles.removedText }}>Removed</Typography>
						</Stack>
					)}
					{componentCard(component, false)}
				</Box>
			</Grid>
		);
	};

	return (
		<>
			{isLoading ? (
				<CaloLoader />
			) : (
				<>
					<Box sx={{ ...styles.mainContainer }}>
						<Grid container sx={{ ...styles.mainGrid }}>
							{(foodComponentsData ?? []).map((component, index) => renderComponentCard(component, index))}
						</Grid>
					</Box>
					{selectedComponent && (
						<Box sx={{ ...styles.customComponentContainer }}>
							<Stack>
								<Typography sx={{ ...styles.changeText }}>Change</Typography>
							</Stack>
							<Grid container sx={{ ...styles.mainGrid }}>
								<Grid item>
									<Stack onClick={() => handleRemoveComponents(selectedComponent.id)} style={{ width: 120 }}>
										<Stack style={{ width: 110, position: 'relative', ...styles.removeComponent }}>
											<RemoveCircleOutlineIcon
												sx={{
													...styles.removeIcon,
													color: selectedRemovedComponentIdList.includes(selectedComponent?.id)
														? caloTheme.palette.red
														: caloTheme.palette.neutral600
												}}
											/>
										</Stack>
										<Stack
											sx={{
												...styles.removeComponentStack
											}}
										>
											<Typography
												sx={{
													...styles.componentNameText
												}}
											>
												Remove Component
											</Typography>
										</Stack>
									</Stack>
								</Grid>
								{foodCompData && foodCompData.data && (
									<Grid item>
										<Stack
											onClick={() => handleOriginalComponent(foodCompData.data[selectedComponentIndex].id)}
											style={{ width: 120, marginTop: '-14px' }}
										>
											{componentCard(foodCompData.data[selectedComponentIndex], true)}
										</Stack>
									</Grid>
								)}
								{caloKidsComponents.length > 0 &&
									caloKidsComponents
										.filter((component) => component.name?.en !== foodCompData?.data[selectedComponentIndex].name?.en)
										.filter((component) =>
											component.tags?.some((tag) => foodCompData?.data[selectedComponentIndex].tags?.includes(tag))
										)
										.map((kidsComp, index) => {
											return (
												<Grid item key={index}>
													<Box
														key={kidsComp.id}
														onClick={() => handleSwapComponent(selectedComponent.id, kidsComp.id, true)}
														style={{
															marginTop: '-12px',
															...styles.componentCard
														}}
													>
														{componentCard(kidsComp, true)}
													</Box>
												</Grid>
											);
										})}
								{customFoodComponents &&
									selectedComponent &&
									(selectedComponent.tags?.includes(FoodComponentType.sauce) || isPreBuiltMeal) &&
									customFoodComponents
										?.filter((component) => component.name?.en !== foodCompData?.data[selectedComponentIndex].name?.en)
										.map((customComp, index) => (
											<Grid item key={index}>
												<Box
													key={customComp.id}
													onClick={() => handleSwapComponent(selectedComponent.id, customComp.id)}
													style={{
														marginTop: '-12px',
														...styles.componentCard
													}}
												>
													{componentCard(customComp, true)}
												</Box>
											</Grid>
										))}
							</Grid>
						</Box>
					)}
				</>
			)}
		</>
	);
};
export default CustomizeMealPopup;
