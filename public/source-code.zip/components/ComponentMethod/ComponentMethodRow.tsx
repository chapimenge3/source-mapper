import { CreateFoodComponentReq, UpdateFoodComponentReq } from '@calo/dashboard-types';
import { FoodComponentMethodStep } from '@calo/dashboard-types/dist/interfaces';
import { Editor } from '@tinymce/tinymce-react';
import { uploadImage } from 'actions';
import cx from 'classnames';
import { decodeHtmlSymbols, encodeHtmlSymbols } from 'lib/helpers';
import { flatten } from 'lodash';
import { useRef, useState } from 'react';
import { Draggable } from 'react-beautiful-dnd';
import { toast } from 'react-toastify';
import { Button, Icon, Modal } from '../';
import { ModalRef } from '../Modal/types';

interface ComponentMethodRowProps {
	index: number;
	image: string;
	isEdit: boolean;
	disabled: boolean;
	uploadImages: boolean;
	step: FoodComponentMethodStep;
	setSelected: (value: any) => void;
	setIsEdit: (value: boolean) => void;
	selected: FoodComponentMethodStep & { index: number };
	values: UpdateFoodComponentReq | CreateFoodComponentReq;
	modifyStep: (value: any, index: any, attachment: any) => void;
	setValues: (values: UpdateFoodComponentReq | CreateFoodComponentReq) => void;
	uploadLink: () => Promise<{ url: string; fields: Record<string, string | Blob> }>;
}

const ComponentMethodRow = ({
	setIsEdit,
	uploadLink,
	image,
	setValues,
	values,
	uploadImages,
	disabled,
	step,
	index,
	selected,
	setSelected,
	isEdit,
	modifyStep
}: ComponentMethodRowProps) => {
	const confirmModalRef = useRef<ModalRef>();
	const componentMethodImageRef = useRef<ModalRef>();

	const [progress, setProgress] = useState(0);

	const [displayImage, setDisplayImage] = useState<string>(image);

	const handleDeleteAction = (step: any) => {
		setSelected(step);
		confirmModalRef.current?.open();
	};

	const deleteStep = (mm: any) => {
		const tempData = [...values.method!];
		const tempFiltered = tempData.filter((e) => e !== mm);
		setValues({
			...values,
			method: tempFiltered
		});
		setSelected('');
		setIsEdit(false);
	};

	const handleRemoveImage = (stepDesc: any) => {
		const tempData = [...values.method!];
		tempData.splice(stepDesc.index, 1, { description: stepDesc.description });
		setValues({
			...values,
			method: tempData
		});
		componentMethodImageRef.current?.close();
	};

	const handleUploadImage = async (files: any) => {
		if (!files && !selected) {
			return;
		}
		if (files && !files.type.includes('image')) {
			toast('Image only', { type: 'error', autoClose: 2000 });
			return;
		}

		const { url, fields } = await uploadLink();
		const formData = new FormData();
		for (const key of Object.keys(fields)) {
			formData.append(key, fields[key]);
		}
		formData.append('file', files);
		setDisplayImage(URL.createObjectURL(files));

		const imageUpload = await uploadImage(url, formData, {
			onUploadProgress: (progressEvent) =>
				setProgress(Math.min(100, Math.round((progressEvent.loaded * 100) / progressEvent.total)))
		});

		if (imageUpload) {
			const tempData = [...values.method!];
			tempData.splice(selected.index, 1, { description: selected.description, attachment: displayImage });
			const methodData = tempData.map((data) => [{ description: data.description, attachment: data.attachment }]);
			setValues({
				...values,
				method: flatten(methodData)
			});
			setSelected({ description: selected.description, index: index, attachment: displayImage });
		}
	};

	return (
		<>
			<p className="label mt-2 ml-2"> Step {index + 1}</p>
			<Draggable key={step.description} draggableId={step.description} index={index}>
				{(provider) => (
					<tr key={index} {...provider.draggableProps} ref={provider.innerRef}>
						<td className="w-1" {...provider.dragHandleProps}>
							<Icon name="dragDropIcon" size={8} className="mt-5" />
						</td>
						<td>
							<Editor
								apiKey="ciycuxas5ypadx61zapqjpxaoyxqh9yxmjkjn1kqn4cwk0ot"
								initialValue={decodeHtmlSymbols(isEdit && index === selected.index ? selected.description : step.description)}
								init={{
									height: 200,
									menubar: false,
									plugins: 'table autoresize',
									// eslint-disable-next-line camelcase
									textcolor_rows: '4',
									toolbar:
										'table | tableprops tabledelete | ' +
										'tableinsertrowbefore tableinsertrowafter tabledeleterow | ' +
										'tableinsertcolbefore tableinsertcolafter tabledeletecol | ' +
										'tablecellprops tablemergecells tablesplitcells tablecellvalign ' +
										'tablecellborderwidth tablecellborderstyle tablecellbackgroundcolor tablecellbordercolor'
								}}
								disabled={disabled || (isEdit && selected.index !== index)}
								onBlur={(_content: any, editor: any) => {
									modifyStep(encodeHtmlSymbols(editor.getContent()), index, step.attachment && step.attachment);
								}}
							/>
						</td>
						{uploadImages && (
							<td
								className={cx('h-auto', {
									'w-1': !uploadImages,
									'w-1/4': uploadImages
								})}
							>
								{uploadImages && !!step.attachment && (
									<figure className="w-full">
										<img
											alt="placeholder"
											className={cx('object-cover rounded-md float-right', {
												'cursor-pointer': !disabled
											})}
											onError={(e: any) => (e.target.src = 'https://via.placeholder.com/120')}
											src={values.method![index].attachment}
											onClick={() => {
												setSelected({ description: step.description, attachment: step.attachment, index: index });
												componentMethodImageRef.current?.open();
											}}
										/>
									</figure>
								)}
								{!step.attachment && (
									<div className="file is-boxed is-fullwidth ">
										<div className="file-label">
											<input
												accept="image/*"
												type="file"
												size={2}
												className="file-input fas fa-paperclip mt-2 cursor-pointer float-right "
												onClick={() => {
													setSelected({
														description: step.description || selected.description,
														index: index,
														attachment: step.attachment
													});
												}}
												onChange={(e) => {
													if (e.target.files && e.target.files[0].size > 62914560) {
														toast('Image size is too big', { type: 'error', autoClose: 2000 });
													} else {
														const file = e.target.files && e.target.files[0];
														handleUploadImage(file);
													}
												}}
											/>
											<div className="flex-col float-right">
												<i className="fas fa-paperclip mt-2 cursor-pointer float-right" />
											</div>
										</div>
									</div>
								)}
								{progress > 0 && progress < 100 && (
									<>
										<br />
										<progress className="progress" value={progress} max="100">
											{progress}%
										</progress>
									</>
								)}
							</td>
						)}
						<td className="w-2">
							{!disabled && (
								<i className="mt-2 fas fa-times cursor-pointer float-right" onClick={() => handleDeleteAction(step)} />
							)}
						</td>
					</tr>
				)}
			</Draggable>
			<Modal
				ref={componentMethodImageRef}
				onClose={() => {
					componentMethodImageRef.current?.close();
				}}
			>
				<section className="section is-title-bar label -my-8 ">
					<div className="level -mb-4">
						<div className="level-left">
							<div className="level-item">
								<div className="file is-boxed is-fullwidth">
									<div className="file-label">
										<input
											className="file-input cursor-pointer fas fa-pen"
											accept="image/*"
											type="file"
											onClick={() =>
												setSelected({
													description: step.description,
													index: index,
													attachment: step.attachment && step.attachment
												})
											}
											onChange={(e) => {
												if (e.target.files && e.target.files[0].size > 62914560) {
													toast('Image size is too big', { type: 'error', autoClose: 2000 });
												} else {
													const file = e.target.files && e.target.files[0];
													handleUploadImage(file);
												}
											}}
										/>
										<Icon
											name="edit"
											size={8}
											className="cursor-pointer -mb-4"
											onClick={() =>
												setSelected({
													description: step.description || selected.description,
													index: index,
													attachment: step.attachment || selected.attachment
												})
											}
										/>
									</div>
								</div>
								<Icon
									name="trashCan"
									size={16}
									onClick={() => handleRemoveImage({ description: step.description, index: index })}
									className="-mb-12 cursor-pointer"
								/>
							</div>
						</div>
						<div className="level-right">
							<div className="level-right">
								<i
									className="fas fa-times ml-2 cursor-pointer float-right"
									onClick={() => {
										componentMethodImageRef.current?.close();
										setSelected('');
									}}
								/>
							</div>
						</div>
					</div>
				</section>
				<section className="mx-auto">
					<div className="-mb-4 mt-4">
						<figure className="-m-4">
							<img
								alt="placeholder"
								className="object-cover rounded-md"
								onError={(e: any) => (e.target.src = 'https://via.placeholder.com/120')}
								src={selected.attachment}
							/>
						</figure>
					</div>
					<div>
						{progress > 0 && progress < 100 && (
							<>
								<br />
								<progress className="progress" value={progress} max="100">
									{progress}%
								</progress>
							</>
						)}
					</div>
				</section>
			</Modal>

			<Modal
				ref={confirmModalRef}
				onClose={() => {
					confirmModalRef.current?.close();
					setSelected('');
				}}
			>
				<section className="section is-title-bar label -my-8 ">
					<p className="label uppercase text-center"> Are you sure you want to delete step</p>
				</section>
				<div className="ml-4">
					<label>Are you sure you want to delete the step as well as the image attached?</label>
				</div>
				<section>
					<div className="flex justify-between mx-auto -mb-6 mt-6 w-1/2">
						<Button
							content="Delete"
							primary
							onClick={() => {
								deleteStep(selected);
								confirmModalRef.current?.close();
							}}
						/>
						<Button
							content="Cancel"
							className="mr-2"
							onClick={() => {
								setSelected('');
								confirmModalRef.current?.close();
							}}
						/>
					</div>
				</section>
			</Modal>
		</>
	);
};
export default ComponentMethodRow;
