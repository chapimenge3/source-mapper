import { useState } from 'react';

import { flatten } from 'lodash';
import { DragDropContext, Droppable } from 'react-beautiful-dnd';
import { useParams } from 'react-router';

import { CreateFoodComponentReq, UpdateFoodComponentReq } from '@calo/dashboard-types';
import { FoodComponentMethodStep } from '@calo/dashboard-types/dist/interfaces';
import { Button } from '@mui/material';

import { getImageUploadLink } from 'actions';
import { caloTheme } from 'assets/images/theme/calo';
import ComponentMethodRow from './ComponentMethodRow';

interface ComponentMethodProps {
	values: UpdateFoodComponentReq | CreateFoodComponentReq;
	isEdit: boolean;
	disabled: boolean;
	uploadImages: boolean;
	setValues: (v: any) => void;
	setIsEdit: (value: boolean) => void;
	setFieldValue: (value: any) => void;
}

const ComponentMethod = ({
	isEdit,
	setIsEdit,
	setFieldValue,
	disabled,
	uploadImages,
	values,
	setValues
}: ComponentMethodProps) => {
	const { id } = useParams<{ id: string }>();
	const [selected, setSelected] = useState<any>({ description: '', attachment: '' });

	const handleChangeMethod = (data: FoodComponentMethodStep) => {
		setValues({
			...values,
			method: values.method
				? [...values.method, { description: data.description, attachment: data.attachment && data.attachment }]
				: [{ description: data.description, attachment: data.attachment && data.attachment }]
		});
	};

	const handleDragEnd = (e: any) => {
		if (!e.destination) return;
		const tempData = [...values.method!];
		const [sourceData] = tempData.splice(e.source.index, 1);
		tempData.splice(e.destination.index, 0, sourceData);
		const methodStepValues = tempData.map((f) => [{ description: f.description, attachment: f.attachment && f.attachment }]);
		setValues({
			...values,
			method: flatten(methodStepValues)
		});
		setFieldValue(flatten(methodStepValues));
	};

	const modifyStep = (step: string, index: number, attachment?: string) => {
		setIsEdit(true);
		setSelected({ description: step, index: index, attachment: attachment && attachment });
	};

	const handleEditMethod = (step: any) => {
		const tempData = [...values.method!];
		tempData.splice(step.index, 1, { description: step.description?.trim(), attachment: selected.attachment });
		setValues({
			...values,
			method: flatten(tempData)
		});
		setIsEdit(false);
	};

	return (
		<div className="card has-table">
			<div className="card-content">
				<DragDropContext onDragEnd={handleDragEnd}>
					<table className="table is-fullwidth is-striped is-hoverable is-sortable">
						<Droppable droppableId="droppable">
							{(provider) => (
								<tbody className="text-capitalize" ref={provider.innerRef} {...provider.droppableProps}>
									{values.method?.map((step: FoodComponentMethodStep, index) => (
										<ComponentMethodRow
											key={index}
											step={step}
											index={index}
											values={values}
											isEdit={isEdit}
											selected={selected}
											disabled={disabled}
											uploadImages={uploadImages}
											setIsEdit={(v) => setIsEdit(v)}
											setValues={(v: any) => setValues(v)}
											setSelected={(v) => setSelected(v)}
											modifyStep={(v, i, a) => modifyStep(v, i, a)}
											uploadLink={() => getImageUploadLink(`food-component/${id}/method/step/${index}`)}
											image={`${process.env.REACT_APP_BUCKET_URL}/food-component/${id}/method/step/${index}/square@1x.jpg`}
										/>
									))}
								</tbody>
							)}
						</Droppable>
					</table>
				</DragDropContext>
			</div>
			{!disabled && (
				<div className="mt-4 text-center">
					{isEdit ? (
						<Button
							variant="contained"
							sx={{
								marginBottom: 2,
								width: '120px',
								height: '51px',
								lineHeight: '17px',
								fontWeight: 600,
								fontSize: '14px',
								borderRadius: '8px',
								backgroundColor: caloTheme.palette.primary500,
								borderColor: caloTheme.palette.primary500,
								boxShadow: 'none',
								color: 'white',
								'&:hover': {
									boxShadow: 'none',
									backgroundColor: caloTheme.palette.primary600,
									borderColor: caloTheme.palette.primary600
								}
							}}
							onClick={() => handleEditMethod(selected)}
							disabled={selected?.description?.trim()?.length === 0}
						>
							{' '}
							Done
						</Button>
					) : (
						<Button
							variant="outlined"
							sx={{
								marginBottom: 2,
								lineHeight: '17px',
								fontWeight: 600,
								fontSize: '16px',
								borderRadius: '8px',
								textTransform: 'none',
								paddingY: '10px',
								paddingX: '16px'
							}}
							onClick={() => {
								setIsEdit(true);
								handleChangeMethod({ description: '', attachment: '' });
								setSelected({ description: '', attachment: '', index: values.method ? values.method.length : 0 });
							}}
						>
							{' '}
							Add Step
						</Button>
					)}
				</div>
			)}
		</div>
	);
};
export default ComponentMethod;
