import { Table, TableBody, TableCell, TableHead, TableRow } from '@mui/material';
import { tableCellClasses } from '@mui/material/TableCell';
import { styled } from '@mui/material/styles';
import { caloTheme } from 'assets/images/theme/calo';
import FeedbackRow from './FeedbackRow';

interface FeedbackTableProps {
	data: any;
}

const FeedbackTable = ({ data }: FeedbackTableProps) => {
	const StyledTableCell = styled(TableCell)(() => ({
		[`&.${tableCellClasses.head}`]: {
			border: 'none'
		},
		[`&.${tableCellClasses.body}`]: {
			border: 'none',
			justifyContent: 'space-between'
		}
	}));

	return (
		<Table
			sx={{
				marginY: '4px',
				minHeight: '120px',
				overflow: 'auto',
				width: '100%',
				[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
					flexDirection: 'column'
				}
			}}
		>
			<TableHead
				sx={{
					backgroundColor: caloTheme.palette.neutral50,
					color: 'black',
					flexWrap: 0,
					justifyContent: 'space-between',
					width: '100%',
					borderRadius: '8px'
				}}
			>
				<TableRow
					sx={{
						backgroundColor: caloTheme.palette.neutral50,
						color: 'black',
						width: '100%',
						flexWrap: 0,
						justifyContent: 'space-between'
					}}
				>
					<StyledTableCell>Meal</StyledTableCell>
					<StyledTableCell>Comment</StyledTableCell>
					<StyledTableCell>Country</StyledTableCell>
					<StyledTableCell>Customer</StyledTableCell>
					<StyledTableCell>Date</StyledTableCell>
					<StyledTableCell></StyledTableCell>
				</TableRow>
			</TableHead>
			{data && data.data.length === 0 ? (
				<span className="absolute w-11/12 text-2xl mt-6 text-center font-bold text-gray-400 ">NO FEEDBACKS</span>
			) : (
				<TableBody>{data?.data?.map((user: any) => <FeedbackRow key={user.user} user={user} />)}</TableBody>
			)}
		</Table>
	);
};

export default FeedbackTable;
