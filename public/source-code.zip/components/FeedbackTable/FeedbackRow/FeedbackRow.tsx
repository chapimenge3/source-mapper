import { Permission } from '@calo/dashboard-types';
import { Country } from '@calo/types';
import { TableCell, TableRow, Typography, tableCellClasses } from '@mui/material';
import { styled } from '@mui/material/styles';
import { selectedFoodData } from 'actions';
import { format, parseISO } from 'date-fns/fp';
import { Routes } from 'lib/enums';
import history from 'lib/history';
import { useUserRoles } from 'lib/hooks';
import { Icon } from '../..';

interface FeedbackRowProps {
	user: any;
}

const FeedbackRow = ({ user }: FeedbackRowProps) => {
	const roles = useUserRoles();

	const StyledTableCell = styled(TableCell)(() => ({
		[`&.${tableCellClasses.head}`]: {
			border: 'none'
		},
		[`&.${tableCellClasses.body}`]: {
			border: 'none',
			justifyContent: 'space-between'
		}
	}));

	const stars = (rate: number) => {
		const allStars = [];
		for (let i = 1; i <= rate; i++) {
			allStars.push(<Icon name="star" size={4} />);
		}
		for (let i = 5; i > rate; i--) {
			allStars.push(<Icon name="grayStar" size={4} />);
		}
		return allStars;
	};

	const handleChangeURL = async (foodID: string) => {
		const selectedFeedBackFood = await selectedFoodData(foodID);
		return history.replace(Routes.foodSlug.replace(':slug', selectedFeedBackFood.slug));
	};

	return (
		<TableRow hover>
			<StyledTableCell
				component="th"
				scope="row"
				sx={{
					textOverflow: 'ellipsis'
				}}
			>
				<div className="flex w-72">
					<div className="mt-2 w-14 h-14">
						<img
							className="object-cover h-full rounded"
							width={120}
							alt={user.food.name.en}
							onError={(e: any) => (e.target.src = 'https://via.placeholder.com/120')}
							src={`${process.env.REACT_APP_BUCKET_URL}/food/${user.food.id}/square@1x.jpg`}
						/>
					</div>
					<div className="ml-2 mt-4">
						{roles.includes(Permission.VIEW_FOOD_LIST_BY_SLUG) ? (
							<a onClick={() => handleChangeURL(user.food.id)}>{user.food.name.en}</a>
						) : (
							`${user.food.name.en}`
						)}
						<div>{stars(user.rating)}</div>
					</div>
				</div>
			</StyledTableCell>

			<StyledTableCell>
				<div className="text-gray-400 text-sm">{user.review}</div>
			</StyledTableCell>

			<StyledTableCell className="w-24">
				<Typography>{user.country || Country.BH}</Typography>
			</StyledTableCell>

			<StyledTableCell className="w-64">
				<Typography>{user.name}</Typography>
			</StyledTableCell>

			<StyledTableCell className="w-36">
				<Typography>
					<span className="flex">{user.createdAt && format('dd-MM-yyyy')(parseISO(user.createdAt))}</span>
					<span className="flex">{user.createdAt && format('hh:mm aa')(parseISO(user.createdAt))}</span>
				</Typography>
			</StyledTableCell>
			<StyledTableCell className="w-24">
				<Typography>
					<div className="flex flex-row w-24 justify-center capitalize">{user.portionSize}</div>
				</Typography>
			</StyledTableCell>
		</TableRow>
	);
};

export default FeedbackRow;
