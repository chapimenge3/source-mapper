import { createContext, Dispatch } from 'react';

export default createContext<Dispatch<SinglePolygonAction> | undefined>(undefined);
