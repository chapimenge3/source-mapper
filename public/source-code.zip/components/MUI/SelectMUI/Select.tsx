import { isArray } from 'lodash-es';
import RSelect, { Props } from 'react-select';

import { Box, InputLabel } from '@mui/material';

import { caloTheme } from 'assets/images/theme/calo';

interface SelectOption {
	label: string;
	value: string | number;
}

export interface SelectProps extends Omit<Props<SelectOption>, 'value'> {
	label?: string;
	placeholder?: string;
	value?: any;
	hidden?: boolean;
	error?: boolean;
	areDuplicatesAllowed?: boolean;
	isDisabled?: boolean;
	isMulti?: boolean;
}

const mapValueToSVal = (options: SelectOption[], value?: any) => {
	if (isArray(value)) {
		return options.filter((v) => value.includes(v.value));
	}

	return options.find((v) => v.value === value) || null;
};

const SelectMUI = ({
	error,
	label,
	placeholder,
	value,
	options,
	hidden,
	isMulti,
	customStyles,
	areDuplicatesAllowed,
	isDisabled = false,
	...rest
}: SelectProps) => (
	<Box sx={{ visibility: hidden ? 'hidden' : 'visible' }}>
		{label && (
			<InputLabel
				size="small"
				htmlFor={label}
				sx={{
					position: 'relative',
					top: '-7px',
					left: '12px',
					width: 'fit-content',
					zIndex: 1,
					fontSize: '12px',
					color: caloTheme.palette.neutral700,
					backgroundColor: isDisabled ? 'transparent' : caloTheme.palette.white,
					transition: 'top 0.1s, font-size 0.1s'
				}}
			>
				{label}
			</InputLabel>
		)}
		<RSelect
			id={label || Math.random().toString()}
			isDisabled={isDisabled}
			value={areDuplicatesAllowed ? value : mapValueToSVal(options, value)}
			options={options}
			isMulti={isMulti}
			blurInputOnSelect={false}
			menuPortalTarget={document.body}
			styles={{ ...customStyles, menuPortal: (base) => ({ ...base, zIndex: 9999 }) }}
			className={error ? 'border border-red-500' : undefined}
			placeholder={placeholder || 'Select...'}
			{...rest}
		/>
	</Box>
);

export default SelectMUI;
