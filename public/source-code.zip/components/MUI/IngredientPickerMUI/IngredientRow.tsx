import { round } from 'lodash-es';

import { Permission } from '@calo/dashboard-types';
import { IconButton, Stack, TableCell, Typography } from '@mui/material';

import { FoodComponentIngredientAction } from '@calo/types';
import { Routes } from 'lib/enums';
import { useHistory } from 'react-router';
import { InputMUI } from '../';

import { Icon as Iconify } from '@iconify/react';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import { caloTheme } from 'assets/images/theme/calo';
import { useUserRoles } from 'lib/hooks';
import { Ingredient } from 'lib/interfaces';

interface IngredientRowProps {
	isDisabled: boolean;
	row: Ingredient;
	index: number;
	handleChange: (id: string, index: number, quantity: number) => void;
	handleActionChange: (id: string, index: number, action: FoodComponentIngredientAction) => void;
	handleRemoveIngredient: (index: number, removedId: string) => void;
}

const IngredientRow = ({
	isDisabled,
	row,
	index,
	handleChange,
	handleActionChange,
	handleRemoveIngredient
}: IngredientRowProps) => {
	const roles = useUserRoles();
	const history = useHistory();

	const isDeleteButtonActive =
		(roles.includes(Permission.UPDATE_FOOD) || roles.includes(Permission.UPDATE_FOOD_COMPONENTS)) && !isDisabled;

	return (
		<>
			<TableCell sx={{ p: 0 }}>
				<Stack sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
					{!isDisabled && (
						<IconButton disabled={!isDeleteButtonActive} onClick={() => handleRemoveIngredient(index, row.id)}>
							<Iconify
								color={isDeleteButtonActive ? caloTheme.palette.neutral900 : caloTheme.palette.neutral600}
								width={24}
								icon="uil:trash"
							/>
						</IconButton>
					)}
					<Typography>
						{row.name.en}-(
						{row.internalName && row.internalName})
					</Typography>
				</Stack>
			</TableCell>
			<TableCell sx={{ width: '150px' }}>
				<InputMUI
					type="number"
					value={row.quantity}
					onChange={(e) => handleChange(row.id, index, parseFloat(e.target.value))}
					min={0}
					step="any"
					debounce
					disabled={!roles.includes(Permission.UPDATE_FOOD) || !roles.includes(Permission.UPDATE_FOOD_COMPONENTS) || isDisabled}
					inputProps={{ style: { borderRadius: 8 } }}
				/>
			</TableCell>

			<TableCell sx={{ fontSize: '16px' }}>{row.measurementUnit}</TableCell>
			<TableCell sx={{ fontSize: '16px' }}>{(row.quantity || 0) * (row.weight || 1)}</TableCell>
			<TableCell sx={{ fontSize: '16px' }}>
				{row.macros?.cal && row.quantity ? round(row.macros!.cal * row.quantity, 6) : 0}
			</TableCell>
			<TableCell sx={{ fontSize: '16px' }}>
				{row.macros?.protein && row.quantity ? round(row.macros!.protein * row.quantity, 6) : 0}
			</TableCell>
			<TableCell sx={{ fontSize: '16px' }}>
				{row.macros?.carbs && row.quantity ? round(row.macros!.carbs * row.quantity, 6) : 0}
			</TableCell>
			<TableCell sx={{ fontSize: '16px' }}>
				{row.macros?.fat && row.quantity ? round(row.macros!.fat * row.quantity, 6) : 0}
			</TableCell>
			<TableCell sx={{ fontSize: '16px' }}>
				{row.macros?.fiber && row.quantity ? round(row.macros!.fiber || 0 * row.quantity, 6) : 0}
			</TableCell>
			<TableCell sx={{ fontSize: '16px' }}>{row.cost?.toFixed(5)}</TableCell>
			<TableCell sx={{ fontSize: '16px' }}>
				{row.cost && row.quantity && row.wastage ? round(row.cost! * row.quantity * row.wastage!, 6) : 0}
			</TableCell>
			<TableCell sx={{ p: 0 }}>
				<IconButton
					disabled={!roles.includes(Permission.VIEW_INGREDIENT)}
					onClick={() => history.push(Routes.ingredient.replace(':id', row.id))}
					sx={{ color: '#343434' }}
				>
					<ArrowForwardIcon color="inherit" />
				</IconButton>
			</TableCell>
		</>
	);
};

export default IngredientRow;
