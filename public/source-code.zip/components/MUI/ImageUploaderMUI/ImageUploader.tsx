import { useCallback, useState } from 'react';

import { useDropzone } from 'react-dropzone';
import { toast } from 'react-toastify';

import { ImageUpdateLogReq, Permission } from '@calo/dashboard-types';
import { LinearProgress } from '@mui/material';
import Button from '@mui/material/Button';
import Card from '@mui/material/Card';
import CardMedia from '@mui/material/CardMedia';

import { uploadImage } from 'actions';
import { caloTheme } from 'assets/images/theme/calo';
import client from 'lib/client';
import { useUserRoles } from 'lib/hooks';

interface ImageUploaderProps {
	uploadLink: () => Promise<{ url: string; fields: Record<string, string | Blob> }>;
	image: string;
	disabled: boolean;
	values?: ImageUpdateLogReq;
	width?: number;
	maxHeight?: number;
}

const ImageUploader = ({ image, uploadLink, disabled, values, width = 240, maxHeight = 240 }: ImageUploaderProps) => {
	const [progress, setProgress] = useState(0);
	const [displayImage, setDisplayImage] = useState<string>(image);

	const roles = useUserRoles();

	const onDrop = useCallback(
		async (files) => {
			if (!files) {
				return;
			}
			if (files && files[0].size > 62914560) {
				toast('Image size is too big', { type: 'error', autoClose: 2000 });
				return;
			}

			if (files && !files[0].type.includes('image')) {
				toast('Image only', { type: 'error', autoClose: 2000 });
				return;
			}

			const file = files[0];

			const { url, fields } = await uploadLink();

			const formData = new FormData();

			for (const key of Object.keys(fields)) {
				formData.append(key, fields[key]);
			}

			formData.append('file', file);

			setDisplayImage(URL.createObjectURL(file));

			const imageUpload = await uploadImage(url, formData, {
				onUploadProgress: (progressEvent) =>
					setProgress(Math.min(100, Math.round((progressEvent.loaded * 100) / progressEvent.total)))
			});

			if (imageUpload && values && roles.includes(Permission.CREATE_LOGS_ON_UPDATE_IMAGE)) {
				await client.post('image-change-log', values);
			}
		},
		[uploadLink]
	);

	const { getRootProps, getInputProps } = useDropzone({ onDrop });

	return (
		<Card sx={{ boxShadow: 'none' }}>
			<CardMedia
				component="img"
				image={displayImage}
				alt="placeholder"
				sx={{ width, maxHeight, objectFit: 'cover', borderRadius: '8px' }}
				onError={(e: any) => (e.target.src = 'https://via.placeholder.com/120')}
			/>
			<LinearProgress
				variant="determinate"
				value={progress}
				sx={{ mt: 1, visibility: progress > 0 && progress < 100 ? 'visible' : 'hidden' }}
			/>
			{disabled && (
				<div style={{ display: 'flex', justifyContent: 'center', margin: '10px' }}>
					<Button
						variant="text"
						sx={{
							color: caloTheme.palette.neutral900,
							textTransform: 'capitalize',
							fontSize: '16px',
							fontWeight: 600,
							lineHeight: '20px',
							'&:hover': {
								color: caloTheme.palette.white,
								backgroundColor: caloTheme.palette.neutral900
							}
						}}
						{...getRootProps()}
					>
						<input {...getInputProps()} accept="image/*" />
						Update Image
					</Button>
				</div>
			)}
		</Card>
	);
};

export default ImageUploader;
