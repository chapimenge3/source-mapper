import { round } from 'lodash-es';
import { useHistory } from 'react-router-dom';

import { MeasurementUnit, MenuFoodComponent, Permission } from '@calo/dashboard-types';
import { Dictionary, Nutrition } from '@calo/types';
import { Icon as Iconify } from '@iconify/react';
import { IconButton, TableCell } from '@mui/material';

import { caloTheme } from 'assets/images/theme/calo';
import { Routes } from 'lib/enums';
import { quantitiesCupsCalculator } from 'lib/helpers';
import { useUserRoles } from 'lib/hooks';
import { FoodComponent } from 'lib/interfaces';
import { InputMUI } from '../';

interface FoodComponentPickerProps {
	childComp: boolean;
	isDisabled: boolean;
	value: MenuFoodComponent[];
	allComponents: Dictionary<FoodComponent>;
	onChange: (rows: MenuFoodComponent[]) => void;
	component: MenuFoodComponent;
	isPreBuildCustom?: boolean;
}
const FoodComponentRow = ({
	isDisabled,
	childComp,
	value,
	onChange,
	allComponents,
	component,
	isPreBuildCustom
}: FoodComponentPickerProps) => {
	const roles = useUserRoles();
	const history = useHistory();
	const componentWeight =
		allComponents[component.id]?.measurementUnit === MeasurementUnit.cup
			? quantitiesCupsCalculator([component.quantity], allComponents[component.id]?.cups!)
			: round((allComponents[component.id]?.weight || 1) * component.quantity, 6);
	const handleChange = (id: string, quantity: number) => {
		const i = value.findIndex((r) => r.id === id);
		onChange([...value.slice(0, i), { ...value[i], quantity }, ...value.slice(i + 1)]);
	};
	const handleRemoveFood = (removedId: string) => {
		const newList: MenuFoodComponent[] = [...value];
		const food = newList.filter((r) => r.id !== removedId);
		onChange(food);
	};
	const handleMacrosData = (allComponents: Dictionary<FoodComponent>, macrosType: Nutrition, rowId: string, weight: number) => {
		return childComp
			? round(((allComponents[rowId]?.macros[macrosType] || 0) / (allComponents[rowId]?.weight || 1)) * weight, 6)
			: round((allComponents[rowId]?.macros[macrosType] || 0) * weight, 6);
	};
	const isDeleteButtonActive =
		(roles.includes(Permission.UPDATE_FOOD) || roles.includes(Permission.UPDATE_FOOD_COMPONENTS)) && !isDisabled;

	return (
		<>
			<TableCell sx={{ p: 0, width: '50px' }}>
				<IconButton disabled={!isDeleteButtonActive} onClick={() => handleRemoveFood(component.id)}>
					<Iconify
						color={isDeleteButtonActive ? caloTheme.palette.neutral900 : caloTheme.palette.neutral600}
						width={24}
						icon="uil:trash"
					/>
				</IconButton>
			</TableCell>
			<TableCell sx={{ pl: 0, fontSize: '16px' }}>
				{allComponents[component.id]?.name.en && allComponents[component.id]?.name.en}
			</TableCell>
			{isPreBuildCustom ? (
				<>
					<TableCell>
						<InputMUI
							type="number"
							value={round(component.quantity / (allComponents[component.id]?.defaultWeight || 1), 2)}
							onChange={(e) =>
								handleChange(component.id, parseFloat(e.target.value) * (allComponents[component.id].defaultWeight || 1))
							}
							min={0.1}
							step="any"
							debounce
							error={round(component.quantity / (allComponents[component.id]?.defaultWeight || 1), 2) === 0}
							disabled={
								!roles.includes(Permission.UPDATE_FOOD) || !roles.includes(Permission.UPDATE_FOOD_COMPONENTS) || isDisabled
							}
							inputProps={{ style: { borderRadius: 8 } }}
						/>
					</TableCell>
					<TableCell sx={{ fontSize: '16px' }}>{component.quantity}</TableCell>
				</>
			) : (
				<TableCell>
					<InputMUI
						type="number"
						value={component.quantity}
						onChange={(e) => handleChange(component.id, parseFloat(e.target.value))}
						min={0.1}
						step="any"
						debounce
						error={component.quantity === 0}
						disabled={!roles.includes(Permission.UPDATE_FOOD) || !roles.includes(Permission.UPDATE_FOOD_COMPONENTS) || isDisabled}
						inputProps={{ style: { borderRadius: 8 } }}
					/>
				</TableCell>
			)}
			<TableCell sx={{ fontSize: '16px' }}>
				{childComp ? MeasurementUnit.g : allComponents[component.id]?.measurementUnit}
			</TableCell>
			<TableCell sx={{ fontSize: '16px' }}>{componentWeight}</TableCell>
			<TableCell sx={{ fontSize: '16px' }}>
				{handleMacrosData(allComponents, 'cal' as any, component.id, componentWeight)}
			</TableCell>
			<TableCell sx={{ fontSize: '16px' }}>
				{handleMacrosData(allComponents, Nutrition.protein, component.id, componentWeight)}
			</TableCell>
			<TableCell sx={{ fontSize: '16px' }}>
				{handleMacrosData(allComponents, Nutrition.carbs, component.id, componentWeight)}
			</TableCell>
			<TableCell sx={{ fontSize: '16px' }}>
				{handleMacrosData(allComponents, Nutrition.fat, component.id, componentWeight)}
			</TableCell>
			<TableCell sx={{ fontSize: '16px' }}>
				{handleMacrosData(allComponents, Nutrition.fiber, component.id, componentWeight)}
			</TableCell>
			<TableCell sx={{ fontSize: '16px' }}>{allComponents[component.id]?.cost}</TableCell>
			<TableCell sx={{ fontSize: '16px' }}>{round(allComponents[component.id]?.cost * component.quantity, 6)}</TableCell>
			<TableCell sx={{ p: 0 }}>
				<IconButton
					disabled={!roles.includes(Permission.VIEW_FOOD_COMPONENTS)}
					onClick={() => history.push(Routes.foodComponent.replace(':id', component.id))}
				>
					<Iconify
						color={isDeleteButtonActive ? caloTheme.palette.neutral900 : caloTheme.palette.neutral600}
						width={24}
						icon="ph:arrow-right"
					/>
				</IconButton>
			</TableCell>
		</>
	);
};
export default FoodComponentRow;
