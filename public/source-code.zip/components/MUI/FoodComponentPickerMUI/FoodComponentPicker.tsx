import { useMemo } from 'react';

import { round, sortBy, sumBy } from 'lodash-es';
import { DragDropContext, Draggable, Droppable } from 'react-beautiful-dnd';
import { useParams } from 'react-router';
import { ActionMeta } from 'react-select';

import { LinkedComponent, MeasurementUnit, Permission } from '@calo/dashboard-types';
import { Dictionary, Nutrition } from '@calo/types';
import { Paper, Table, TableBody, TableCell, TableContainer, TableFooter, TableHead, TableRow } from '@mui/material';

import { caloTheme } from 'assets/images/theme/calo';
import { foodInformationFormSingleSelectCustomStyles } from 'lib/componentStyles';
import { MacrosOffset } from 'lib/enums';
import { handleSearch, quantitiesCupsCalculator } from 'lib/helpers';
import { useUserRoles } from 'lib/hooks';
import { FoodComponent } from 'lib/interfaces';
import SelectMUI from '../SelectMUI';
import FoodComponentRow from './FoodComponentRow';

interface FoodComponentPickerProps {
	name: string;
	childComp: boolean;
	isLoading: boolean;
	isDisabled: boolean;
	list: FoodComponent[];
	value: LinkedComponent[];
	allComponents: Dictionary<FoodComponent>;
	setName: (value: string) => void;
	onChange: (rows: LinkedComponent[]) => void;
	setFieldValue: (field: string, value: any) => void;
	isPreBuildCustom?: boolean;
}

const FoodComponentPickerMUI = (props: FoodComponentPickerProps) => {
	const {
		isLoading,
		isDisabled,
		childComp,
		value,
		allComponents,
		list,
		name,
		setFieldValue,
		setName,
		onChange,
		isPreBuildCustom
	} = props;

	const roles = useUserRoles();
	const { id } = useParams<{ id: string }>();

	const checkExistence = (id: string) => value.find((existcomponent) => existcomponent.id === id);
	const components = list.filter((fc) => !checkExistence(fc.id));
	const filteredChild = childComp
		? components.filter((fc) => (!fc.childComponents || fc.childComponents.length === 0) && fc.id !== id)
		: components;
	const options = useMemo(
		() =>
			sortBy(filteredChild, (f) => `${f.name.en}`).map((food) => ({
				value: food.id,
				label: food.name.en
			})),
		[components]
	);

	const modifyFoodComponents = (data: any, { action }: ActionMeta<any>) => {
		let newList: LinkedComponent[] = [...value];
		const existing = newList.map((row) => row.id);
		const newValues = data.value;
		if (action === 'select-option') {
			// add
			!existing.includes(data.value) &&
				newList.push({
					id: data.value,
					quantity: isPreBuildCustom ? allComponents[data.value]?.defaultWeight || 1 : 1
				});
		} else {
			// remove
			newList = newList.filter((row) => newValues.includes(row.id));
		}
		onChange(newList);
	};

	const handleDragEnd = (e: any) => {
		if (!e.destination) return;
		const tempData = [...value];
		const [sourceData] = tempData.splice(e.source.index, 1);
		tempData.splice(e.destination.index, 0, sourceData);
		setFieldValue('components', tempData);
	};

	const handleSumMacrosData = (allComponents: Dictionary<FoodComponent>, macrosType: Nutrition) => {
		return round(
			sumBy(value, (fc) => {
				const component = allComponents[fc.id];
				const componentWeight =
					component?.measurementUnit === MeasurementUnit.cup
						? quantitiesCupsCalculator([fc.quantity], component?.cups!)
						: round((component?.weight || 1) * fc.quantity, 6);
				return childComp
					? ((component?.macros[macrosType] || 0) / (component?.weight || 1)) * componentWeight
					: (component?.macros[macrosType] || 0) * componentWeight;
			}),
			6
		);
	};

	const calculateMacrosPercentage = (totalWeight: number, totalCalories: number, offset: number) => {
		return round(((totalWeight * offset) / totalCalories) * 100, 1);
	};

	const totalCalories = handleSumMacrosData(allComponents, 'cal' as any);
	const totalProteinWeight = handleSumMacrosData(allComponents, Nutrition.protein);
	const totalCarbsWeight = handleSumMacrosData(allComponents, Nutrition.carbs);
	const totalFatWeight = handleSumMacrosData(allComponents, Nutrition.fat);

	const proteinPercentage = calculateMacrosPercentage(totalProteinWeight, totalCalories, MacrosOffset.protein);
	const carbsPercentage = calculateMacrosPercentage(totalCarbsWeight, totalCalories, MacrosOffset.carbs);
	const fatPercentage = calculateMacrosPercentage(totalFatWeight, totalCalories, MacrosOffset.fat);

	return (
		<DragDropContext onDragEnd={handleDragEnd}>
			<Paper sx={{ width: '98%', m: 2, mt: 0, boxShadow: 'none' }}>
				<TableContainer>
					<Table sx={{ width: '100%' }}>
						<TableHead sx={{ backgroundColor: caloTheme.palette.neutral50, border: 0 }}>
							<TableRow>
								<TableCell
									colSpan={2}
									sx={{
										borderRadius: '8px 0 0 8px',
										border: 0,
										fontWeight: 600,
										lineHeight: '14px',
										fontSize: '12px',
										minWidth: '250px'
									}}
								>
									Component Name
								</TableCell>
								{isPreBuildCustom && (
									<TableCell sx={{ border: 0, fontWeight: 600, lineHeight: '14px', fontSize: '12px', minWidth: '150px' }}>
										Times Portioned
									</TableCell>
								)}
								<TableCell
									sx={{
										border: 0,
										fontWeight: 600,
										lineHeight: '14px',
										fontSize: '12px',
										minWidth: isPreBuildCustom ? '100px' : '150px'
									}}
								>
									Quantity
								</TableCell>
								<TableCell sx={{ border: 0, fontWeight: 600, lineHeight: '14px', fontSize: '12px', minWidth: '100px' }}>
									Unit
								</TableCell>
								<TableCell sx={{ border: 0, fontWeight: 600, lineHeight: '14px', fontSize: '12px', minWidth: '100px' }}>
									Weight
								</TableCell>
								<TableCell sx={{ border: 0, fontWeight: 600, lineHeight: '14px', fontSize: '12px', minWidth: '100px' }}>
									Calories
								</TableCell>
								<TableCell sx={{ border: 0, fontWeight: 600, lineHeight: '14px', fontSize: '12px', minWidth: '100px' }}>
									Proteins
								</TableCell>
								<TableCell sx={{ border: 0, fontWeight: 600, lineHeight: '14px', fontSize: '12px', minWidth: '100px' }}>
									Carbs
								</TableCell>
								<TableCell sx={{ border: 0, fontWeight: 600, lineHeight: '14px', fontSize: '12px', minWidth: '100px' }}>
									Fats
								</TableCell>
								<TableCell sx={{ border: 0, fontWeight: 600, lineHeight: '14px', fontSize: '12px', minWidth: '100px' }}>
									Fibers
								</TableCell>
								<TableCell sx={{ border: 0, fontWeight: 600, lineHeight: '14px', fontSize: '12px', minWidth: '120px' }}>
									Cost per Unit
								</TableCell>
								<TableCell sx={{ border: 0, fontWeight: 600, lineHeight: '14px', fontSize: '12px', minWidth: '100px' }}>
									Total Cost
								</TableCell>
								<TableCell
									sx={{
										border: 0,
										fontWeight: 600,
										lineHeight: '14px',
										fontSize: '12px',
										minWidth: '50px',
										borderRadius: '0 8px 8px 0'
									}}
								></TableCell>
							</TableRow>
						</TableHead>
						<Droppable droppableId="droppable">
							{(provider) => (
								<TableBody ref={provider.innerRef} {...provider.droppableProps}>
									{value.map((row, index) => (
										<Draggable
											key={row.id}
											draggableId={row.id}
											index={index}
											isDragDisabled={true}
										>
											{(provider) => (
												<TableRow key={row.id} {...provider.draggableProps} ref={provider.innerRef} {...provider.dragHandleProps}>
													<FoodComponentRow
														isDisabled={isDisabled}
														childComp={childComp}
														value={value}
														onChange={onChange}
														allComponents={allComponents}
														component={row}
														isPreBuildCustom={isPreBuildCustom}
													/>
												</TableRow>
											)}
										</Draggable>
									))}
								</TableBody>
							)}
						</Droppable>
						<TableFooter>
							<TableRow>
								<TableCell
									colSpan={isPreBuildCustom ? 6 : 5}
									sx={{ borderBottom: 0, pb: 1, borderTop: '1px solid ' + caloTheme.palette.neutral100 }}
								>
									<SelectMUI
										placeholder="Select Component"
										options={options}
										InputValue={name}
										isLoading={isLoading}
										onChange={(data: any, action: any) => modifyFoodComponents(data, action)}
										onInputChange={(data: any, action: any) => handleSearch({ text: data, action, name: setName })}
										isDisabled={
											!roles.includes(Permission.UPDATE_FOOD) || !roles.includes(Permission.UPDATE_FOOD_COMPONENTS) || isDisabled
										}
										customStyles={foodInformationFormSingleSelectCustomStyles}
									/>
								</TableCell>
								<TableCell
									sx={{
										borderBottom: 0,
										pb: 1,
										fontSize: '16px',
										borderTop: '1px solid ' + caloTheme.palette.neutral100,
										color: caloTheme.palette.black
									}}
								>
									{totalCalories}
								</TableCell>
								<TableCell
									sx={{
										borderBottom: 0,
										pb: 1,
										fontSize: '16px',
										borderTop: '1px solid ' + caloTheme.palette.neutral100,
										color: caloTheme.palette.black
									}}
								>
									{totalProteinWeight}
									{!childComp && Boolean(proteinPercentage) && `(${proteinPercentage}%)`}
								</TableCell>
								<TableCell
									sx={{
										borderBottom: 0,
										pb: 1,
										fontSize: '16px',
										borderTop: '1px solid ' + caloTheme.palette.neutral100,
										color: caloTheme.palette.black
									}}
								>
									{totalCarbsWeight}
									{!childComp && Boolean(carbsPercentage) && `(${carbsPercentage}%)`}
								</TableCell>
								<TableCell
									sx={{
										borderBottom: 0,
										pb: 1,
										fontSize: '16px',
										borderTop: '1px solid ' + caloTheme.palette.neutral100,
										color: caloTheme.palette.black
									}}
								>
									{totalFatWeight}
									{!childComp && Boolean(fatPercentage) && `(${fatPercentage}%)`}
								</TableCell>
								<TableCell
									sx={{
										borderBottom: 0,
										pb: 1,
										fontSize: '16px',
										borderTop: '1px solid ' + caloTheme.palette.neutral100,
										color: caloTheme.palette.black
									}}
								>
									{handleSumMacrosData(allComponents, Nutrition.fiber)}
								</TableCell>
								<TableCell
									sx={{
										borderBottom: 0,
										pb: 1,
										fontSize: '16px',
										borderTop: '1px solid ' + caloTheme.palette.neutral100,
										color: caloTheme.palette.black
									}}
								>
									{round(
										sumBy(value, (fk) => allComponents[fk.id]?.cost),
										6
									)}
								</TableCell>
								<TableCell
									sx={{
										borderBottom: 0,
										pb: 1,
										fontSize: '16px',
										borderTop: '1px solid ' + caloTheme.palette.neutral100,
										color: caloTheme.palette.black
									}}
								>
									{round(
										sumBy(value, (fk) => allComponents[fk.id]?.cost * fk.quantity),
										6
									)}
								</TableCell>
								<TableCell
									sx={{
										borderBottom: 0,
										pb: 1,
										fontSize: '16px',
										borderTop: '1px solid ' + caloTheme.palette.neutral100,
										color: caloTheme.palette.black
									}}
								></TableCell>
							</TableRow>
						</TableFooter>
					</Table>
				</TableContainer>
			</Paper>
		</DragDropContext>
	);
};

export default FoodComponentPickerMUI;
