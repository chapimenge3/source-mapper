import React, { useEffect, useState } from 'react';

import { FormikErrors } from 'formik';
import { compact, lowerCase, startCase } from 'lodash-es';
import { useHistory } from 'react-router';

import {
	BaseFoodTags,
	CreateFoodReq,
	FoodCategory,
	FoodTagsKeys,
	Permission,
	ProteinFoodTags,
	RatedFoodTags,
	SnackTypeTags,
	TasteFoodTags,
	UpdateFoodReq
} from '@calo/dashboard-types';
import { AddonCategory, Brand, Country, Currency, FoodDietType, FoodType, HeatingInstruction } from '@calo/types';
import { Box, Stack, TextField } from '@mui/material';

import { caloTheme } from 'assets/images/theme/calo';
import { foodInformationFormMultiSelectCustomStyles, foodInformationFormSingleSelectCustomStyles } from 'lib/componentStyles';
import { Routes } from 'lib/enums';
import { getAvailableMealSizes, getFoodTypeColor, getTagColor, resolveHeatingInstruction } from 'lib/helpers';
import { BaseOmit, Food } from 'lib/interfaces';
import SelectMUI from '../SelectMUI';

interface FoodInformationFormProps {
	isDisabled: boolean;
	values: Omit<CreateFoodReq, 'id'> | Omit<UpdateFoodReq, BaseOmit>;
	setFieldValue: any;
	roles: any;
	allSizesFood?: Food[];
	handleBlur: (e: React.ChangeEvent<any>) => void;
	formType: 'create' | 'update';
	country?: Country;
	brand?: Brand;
	errors: FormikErrors<Omit<CreateFoodReq | UpdateFoodReq, 'id'>>;
	isPreBuildCustom: boolean;
	isNewFood?: boolean;
}

const FoodInformationForm = ({
	isDisabled,
	errors,
	values,
	setFieldValue,
	allSizesFood,
	handleBlur,
	formType,
	country,
	roles,
	brand,
	isPreBuildCustom,
	isNewFood
}: FoodInformationFormProps) => {
	const [inputSize, setInputSize] = useState('');
	const [proteinTags, setProteinTags] = useState<ProteinFoodTags[] | undefined>([]);
	const [baseTags, setBaseTags] = useState<BaseFoodTags[] | undefined>([]);
	const [snackTags, setSnackTags] = useState<SnackTypeTags[] | undefined>([]);
	const [ratingTags, setRatingTags] = useState<RatedFoodTags | undefined>();
	const [tasteTags, setTasteTags] = useState<TasteFoodTags | undefined>();
	const [categoryTags, setCategoryTags] = useState<FoodCategory[] | undefined>();
	const [addonCategoryTags, setAddonCategoryTags] = useState<AddonCategory | undefined>();
	const history = useHistory();

	const handlePositiveNumbers = (field: string, value: number) => {
		if (value >= 0) {
			setFieldValue(field, value);
		}
	};

	useEffect(() => {
		if (values.foodTags) {
			(values.foodTags as any).map((r: any) => {
				switch (r.key) {
					case FoodTagsKeys.protein:
						return setProteinTags(r.value);
					case FoodTagsKeys.base:
						return setBaseTags(r.value);
					case FoodTagsKeys.rating:
						return setRatingTags(r.value);
					case FoodTagsKeys.taste:
						return setTasteTags(r.value);
					case FoodTagsKeys.snacktype:
						return setSnackTags(r.value);
					case FoodTagsKeys.category:
						return setCategoryTags(r.value);
					case FoodTagsKeys.addonCategory:
						return setAddonCategoryTags(r.value);
				}
			});
		}
	}, []);

	useEffect(() => {
		if (!values.type?.includes(FoodType.snack)) {
			setFieldValue(
				'foodTags',
				compact([...((values.foodTags as any) || [])?.filter((k: any) => k.key !== FoodTagsKeys.snacktype), undefined])
			);
			setSnackTags([]);
		}
	}, [values.type]);

	const handleTagsChange = (data: any[]) => {
		const newTags = data.map((row) => row.value);
		if (isNewFood && isPreBuildCustom && !newTags.includes(FoodDietType.preBuiltCustom)) {
			history.replace(Routes.newFood.replace(':type', 'regular'));
		} else if (isNewFood && !isPreBuildCustom && newTags.includes(FoodDietType.preBuiltCustom)) {
			history.replace(Routes.newFood.replace(':type', 'custom'));
		}
		if (!isNewFood && isPreBuildCustom && values.type?.length === 0) {
			setFieldValue('type', FoodType.lunch);
		}
		setFieldValue(
			'tags',
			data.map((row) => row.value)
		);
	};

	const handleCategoryTagSelect = (data: any[]) => {
		const categoryValues = data.map((r) => r.value);
		setCategoryTags(categoryValues);

		const newTag = data.length > 0 ? { key: FoodTagsKeys.category, value: categoryValues } : undefined;

		const filteredTags = ((values.foodTags as { key: FoodTagsKeys; value: any[] | string[] | AddonCategory[] }[]) || []).filter(
			(foodTag: { key: FoodTagsKeys; value: any[] | string[] | AddonCategory[] }) => foodTag.key !== FoodTagsKeys.category
		);

		const updatedTags = newTag ? [...filteredTags, newTag] : filteredTags;

		setFieldValue('foodTags', compact(updatedTags));
	};

	return (
		<Stack
			direction="column"
			justifyContent="space-between"
			alignItems="stretch"
			sx={{
				width: '98%',
				m: 2,
				mt: 0,
				pb: 2,
				borderBottom: '1px solid ' + caloTheme.palette.neutral100
			}}
		>
			<Stack direction="row" justifyContent="space-evenly" alignItems="baseline" spacing={2}>
				<Box sx={{ width: '20%' }}>
					<SelectMUI
						label={formType === 'update' ? 'Size' : 'Size*'}
						value={values.size.toUpperCase()}
						data-test="exact-meal-size"
						onInputChange={(d: any) => {
							if (d) {
								setInputSize(d.toUpperCase());
							}
						}}
						onChange={(data: any) => setFieldValue('size', data.value)}
						options={getAvailableMealSizes(['XS', 'S', 'M', 'L', 'XL', inputSize], allSizesFood).map((type) => ({
							value: type,
							label: type
						}))}
						error={!!errors.size}
						isDisabled={isDisabled || (formType === 'update' && !roles.includes(Permission.UPDATE_FOOD)) || brand === Brand.MEALO}
						customStyles={foodInformationFormSingleSelectCustomStyles}
					/>
				</Box>
				<Box sx={{ width: '20%' }}>
					<SelectMUI
						label="Heating Instruction"
						value={values.heatingInstruction}
						data-test="exact-meal-heating_instruction"
						onChange={(data: any) => setFieldValue('heatingInstruction', data.value)}
						options={Object.values(HeatingInstruction).map((instruction) => ({
							value: instruction,
							label: resolveHeatingInstruction(instruction)
						}))}
						error={!!errors.heatingInstruction}
						isDisabled={isDisabled || (formType === 'update' && !roles.includes(Permission.UPDATE_FOOD)) || brand === Brand.MEALO}
						customStyles={foodInformationFormSingleSelectCustomStyles}
					/>
				</Box>
				<Box sx={{ width: '20%' }}>
					<SelectMUI
						label="Type*"
						value={values.type}
						isMulti
						data-test="exact-meal-type"
						customStyles={foodInformationFormMultiSelectCustomStyles(
							(data: any) => `${getFoodTypeColor(data)}1A`,
							getFoodTypeColor
						)}
						onChange={(data: any[]) =>
							setFieldValue(
								'type',
								(data as any[]).map((row) => row.value)
							)
						}
						options={[
							FoodType.breakfast,
							FoodType.lunch,
							FoodType.dinner,
							FoodType.snack,
							FoodType.dessert,
							FoodType.caloKids,
							FoodType.coffee,
							FoodType.juice,
							FoodType.salad
						].map((type) => ({
							value: type,
							label: type
						}))}
						error={!!errors.type}
						isDisabled={isDisabled || (formType === 'update' && !roles.includes(Permission.UPDATE_FOOD))}
					/>
				</Box>
				<Box sx={{ width: '20%' }}>
					<SelectMUI
						label="Meal Plan*"
						value={values.tags}
						data-test="exact-meal-tags"
						isMulti
						onChange={(data: any[]) => handleTagsChange(data)}
						customStyles={foodInformationFormMultiSelectCustomStyles(getTagColor, () => 'white')}
						options={Object.values(FoodDietType).map((tag) => ({
							value: tag,
							label: tag === FoodDietType.preBuiltCustom ? 'Pre-Built Custom' : startCase(tag)
						}))}
						error={!!errors.tags}
						isDisabled={isDisabled || (formType === 'update' && !roles.includes(Permission.UPDATE_FOOD))}
					/>
				</Box>
				<Box sx={{ width: '20%' }}>
					<Stack direction="row" justifyContent="space-between" alignItems="center" spacing={2}>
						<Box sx={{ width: '50%' }}>
							<SelectMUI
								label="Currency"
								value={values.currency}
								data-test="exact-meal-currency"
								onChange={(data: any) => setFieldValue('currency', data.value)}
								options={Object.values(Currency).map((curr) => ({
									value: curr,
									label: Currency[curr]
								}))}
								isDisabled={isDisabled || !!country || formType === 'update'}
								customStyles={foodInformationFormSingleSelectCustomStyles}
							/>
						</Box>
						<Stack direction="column" justifyContent="flex-start" alignItems="flex-start" sx={{ width: '50%', pt: 2 }}>
							<TextField
								label="Price"
								value={values.price}
								name="price"
								type="number"
								inputProps={{ min: 0 }}
								sx={{ width: '100%' }}
								onChange={(price) => handlePositiveNumbers('price', +price.target.value)}
								onBlur={handleBlur}
								disabled={isDisabled || (formType === 'update' && !roles.includes(Permission.UPDATE_FOOD))}
								InputProps={{ style: { borderRadius: 8 } }}
							/>
						</Stack>
					</Stack>
				</Box>
			</Stack>
			<Stack direction="row" justifyContent="space-evenly" alignItems="baseline" spacing={2}>
				<Box sx={{ width: '20%' }}>
					<SelectMUI
						isMulti
						label="Protein"
						value={proteinTags}
						data-test="exact-meal-foodTags.protein"
						onChange={(data: any[]) => {
							setProteinTags(data.map((r) => r.value));
							setFieldValue(
								'foodTags',
								compact(
									((values.foodTags as any) || [])
										?.filter((k: any) => k?.key !== FoodTagsKeys.protein)
										.concat(
											data.length > 0
												? {
														key: FoodTagsKeys.protein,
														value: data.map((d) => d.value)
													}
												: undefined
										)
								)
							);
						}}
						options={Object.values(ProteinFoodTags).map((protein) => ({
							value: protein,
							label: ProteinFoodTags[protein]
						}))}
						isDisabled={isDisabled || (formType === 'update' && !roles.includes(Permission.UPDATE_FOOD))}
						customStyles={foodInformationFormMultiSelectCustomStyles()}
					/>
				</Box>
				<Box sx={{ width: '20%' }}>
					<SelectMUI
						isMulti
						label="Base"
						value={baseTags}
						data-test="exact-meal-foodTags-base"
						onChange={(data: any[]) => {
							setBaseTags(data.map((r) => r.value));
							setFieldValue(
								'foodTags',
								compact(
									((values.foodTags as any) || [])
										?.filter((k: any) => k.key !== FoodTagsKeys.base)
										.concat(
											data.length > 0
												? {
														key: FoodTagsKeys.base,
														value: data.map((d) => d.value)
													}
												: undefined
										)
								)
							);
						}}
						options={Object.values(BaseFoodTags).map((base) => ({
							value: base,
							label: startCase(base)
						}))}
						isDisabled={isDisabled || (formType === 'update' && !roles.includes(Permission.UPDATE_FOOD))}
						customStyles={foodInformationFormMultiSelectCustomStyles()}
					/>
				</Box>
				<Box sx={{ width: '20%' }}>
					<SelectMUI
						label="Label as"
						value={ratingTags}
						data-test="exact-meal-foodTags-rating"
						onChange={(data: any) => {
							setRatingTags(data.value);
							setFieldValue(
								'foodTags',
								compact(
									((values.foodTags as any) || [])
										?.filter((k: any) => k.key !== FoodTagsKeys.rating)
										.concat(data.value === undefined ? undefined : { key: FoodTagsKeys.rating, value: data.value })
								)
							);
						}}
						options={[
							{
								label: 'None',
								value: undefined
							},
							...Object.values(RatedFoodTags).map((rate) => ({
								value: rate,
								label: startCase(RatedFoodTags[rate])
							}))
						]}
						isDisabled={isDisabled || (formType === 'update' && !roles.includes(Permission.UPDATE_FOOD))}
						customStyles={foodInformationFormSingleSelectCustomStyles}
					/>
				</Box>
				<Box sx={{ width: '20%' }}>
					<SelectMUI
						label="Taste"
						value={tasteTags}
						data-test="exact-meal-foodTags-taste"
						onChange={(data: any) => {
							setTasteTags(data.value);
							setFieldValue(
								'foodTags',
								compact(
									((values.foodTags as any) || [])
										?.filter((k: any) => k.key !== FoodTagsKeys.taste)
										.concat(data.value === undefined ? undefined : { key: FoodTagsKeys.taste, value: data.value })
								)
							);
						}}
						options={[
							{
								label: 'None',
								value: undefined
							},
							...Object.values(TasteFoodTags).map((taste) => ({
								value: taste,
								label: startCase(taste)
							}))
						]}
						isDisabled={isDisabled || (formType === 'update' && !roles.includes(Permission.UPDATE_FOOD))}
						customStyles={foodInformationFormSingleSelectCustomStyles}
					/>
				</Box>
				{values.type?.includes(FoodType.snack) && (
					<Box sx={{ width: '20%' }}>
						<SelectMUI
							isMulti
							label="Snack"
							value={snackTags}
							data-test="exact-meal-foodTags-snack"
							onChange={(data: any[]) => {
								setSnackTags(data.map((r) => r.value));
								setFieldValue(
									'foodTags',
									compact(
										((values.foodTags as any) || [])
											?.filter((k: any) => k.key !== FoodTagsKeys.snacktype)
											.concat(
												data.length > 0
													? {
															key: FoodTagsKeys.snacktype,
															value: data.map((d) => d.value)
														}
													: undefined
											)
									)
								);
							}}
							options={Object.values(SnackTypeTags).map((snack) => ({
								value: snack,
								label: startCase(snack)
							}))}
							isDisabled={isDisabled || (formType === 'update' && !roles.includes(Permission.UPDATE_FOOD))}
							customStyles={foodInformationFormMultiSelectCustomStyles()}
						/>
					</Box>
				)}
				<Box sx={{ width: '20%' }}>
					<SelectMUI
						label="Addon Category"
						value={addonCategoryTags}
						data-test="exact-meal-foodTags-addon-category"
						onChange={(data: any) => {
							setAddonCategoryTags(data.value);
							setFieldValue(
								'foodTags',
								compact(
									((values.foodTags as any) || [])
										?.filter((k: any) => k.key !== FoodTagsKeys.addonCategory)
										.concat(data.value === undefined ? undefined : { key: FoodTagsKeys.addonCategory, value: data.value })
								)
							);
						}}
						options={[
							{
								label: 'None',
								value: undefined
							},
							...Object.values(AddonCategory).map((addonCategory) => ({
								value: addonCategory,
								label: startCase(lowerCase(addonCategory))
							}))
						]}
						isDisabled={isDisabled || (formType === 'update' && !roles.includes(Permission.UPDATE_FOOD))}
						customStyles={foodInformationFormSingleSelectCustomStyles}
					/>
				</Box>
			</Stack>
			<Box sx={{ width: '100%' }}>
				<SelectMUI
					isMulti
					label="Tags"
					value={categoryTags}
					data-test="exact-meal-foodTags-category"
					onChange={handleCategoryTagSelect}
					options={Object.values(FoodCategory).map((category) => ({
						value: category,
						label: startCase(category)
					}))}
					isDisabled={isDisabled || (formType === 'update' && !roles.includes(Permission.UPDATE_FOOD))}
					customStyles={foodInformationFormMultiSelectCustomStyles()}
				/>
			</Box>
		</Stack>
	);
};

export default FoodInformationForm;
