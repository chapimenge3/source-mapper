import { FoodTagsKeys } from '@calo/dashboard-types';
import { Brand, FoodType } from '@calo/types';
import { Box, Button, Stack, Typography } from '@mui/material';

import { caloTheme } from 'assets/images/theme/calo';
import Icon from '../Icon';
import MenuFoodDietTags from '../MenuFoodDietTags';
import { ModalRef } from '../Modal';

export interface MenuMealInfoProps {
	brand: Brand;
	selectedMeal: any;
	setSelectedMeal: React.Dispatch<any>;
	handleCalculateLastTime: (food: any) => JSX.Element;
	handleFoodSizes: (foodName: string) => JSX.Element[];
	infoMealRef: React.MutableRefObject<ModalRef | undefined>;
}
const MenuMealInfo = ({
	selectedMeal,
	handleFoodSizes,
	brand,
	infoMealRef,
	setSelectedMeal,
	handleCalculateLastTime
}: MenuMealInfoProps) => (
	<Box display={'flex'} flexDirection={'column'} sx={{ minWidth: '832px' }}>
		<Stack display={'flex'} flexDirection={'row'} justifyContent={'space-between'}>
			<Typography
				variant="h6"
				sx={{
					fontFamily: caloTheme.typography.fontFamily,
					fontWeight: 600,
					fontSize: '16px',
					lineHeight: '19px',
					color: '#000000',
					textTransform: 'capitalize',
					mt: '2px'
				}}
			>{`${selectedMeal?.name.en}`}</Typography>
			<Typography display={'flex'} flexDirection={'row'} justifyContent={'space-evenly'}>
				{handleFoodSizes(selectedMeal?.name.en)}
			</Typography>
			<Stack display={'flex'} flexDirection={'row'} justifyContent={'space-evenly'}>
				<Typography display={'flex'} flexDirection={'row'} sx={{ mt: '1px', mr: 2 }}>
					<Icon name="star" size={5} />
					<Typography sx={{ ml: '6px' }}>
						{!!selectedMeal?.totalRating && !!selectedMeal?.numberOfRatings
							? (selectedMeal?.totalRating / selectedMeal?.numberOfRatings).toFixed(2)
							: 0}
						({selectedMeal?.numberOfRatings ? selectedMeal?.numberOfRatings : 0})
					</Typography>
				</Typography>
				{selectedMeal &&
					selectedMeal?.lastUsedOnMenu &&
					selectedMeal?.lastUsedOnMenu[brand]?.lastTime &&
					handleCalculateLastTime(selectedMeal)}
			</Stack>
		</Stack>
		<Stack display={'flex'} flexDirection={'row'} justifyContent={'space-between'} sx={{ my: 3 }}>
			<Typography
				variant="h6"
				sx={{
					fontFamily: caloTheme.typography.fontFamily,
					fontWeight: 600,
					fontSize: '19px',
					lineHeight: '23px',
					textTransform: 'capitalize'
				}}
			>
				{selectedMeal?.type.map((r: FoodType) => r !== FoodType.dinner && (r.includes(FoodType.lunch) ? 'Lunch & Dinner' : r))}
			</Typography>
			<Typography
				variant="h1"
				sx={{
					mt: '2px',
					fontFamily: caloTheme.typography.fontFamily,
					fontWeight: 400,
					fontSize: '14px',
					lineHeight: '23px',
					textTransform: 'capitalize'
				}}
			>
				Protein:{' '}
				{selectedMeal?.foodTags
					? selectedMeal?.foodTags
							.find((tag: any) => tag.key === FoodTagsKeys.protein)
							?.value.map((tagValue: any) => ` ${tagValue}`)
							?.toString()
							.split('')
					: '--'}
			</Typography>
			<Typography
				variant="h1"
				sx={{
					mt: '2px',
					fontFamily: caloTheme.typography.fontFamily,
					fontWeight: 400,
					fontSize: '14px',
					lineHeight: '23px',
					textTransform: 'capitalize'
				}}
			>
				Taste: {selectedMeal?.foodTags ? selectedMeal?.foodTags.find((tag: any) => tag.key === FoodTagsKeys.taste)?.value : '--'}
			</Typography>
			<Typography
				variant="h1"
				sx={{
					mt: '2px',
					fontFamily: caloTheme.typography.fontFamily,
					fontWeight: 400,
					fontSize: '14px',
					lineHeight: '23px',
					textTransform: 'capitalize'
				}}
			>
				Base: {selectedMeal?.foodTags ? selectedMeal?.foodTags.find((tag: any) => tag.key === FoodTagsKeys.base)?.value : '--'}
			</Typography>
			<Typography
				variant="h1"
				sx={{
					mt: '2px',
					fontFamily: caloTheme.typography.fontFamily,
					fontWeight: 400,
					fontSize: '14px',
					lineHeight: '23px',
					textTransform: 'capitalize'
				}}
			>
				Sandwich: {selectedMeal?.assemblyRequired ? 'Yes' : 'No'}{' '}
			</Typography>
			<Typography display={'flex'} flexDirection={'row'} justifyContent={'space-evenly'}>
				{selectedMeal?.tags?.map((r: any) => <MenuFoodDietTags key={r} tag={r} />)}
			</Typography>
		</Stack>
		<Stack display={'flex'} flexDirection={'row'} m={2} justifyContent={'center'}>
			<Button
				variant="contained"
				data-test="menu-new-modal-confirm-button"
				sx={{
					width: '123px',
					height: '51px',
					lineHeight: '17px',
					fontWeight: 600,
					fontSize: '14px',
					borderRadius: '8px',
					backgroundColor: caloTheme.palette.primary500,
					borderColor: caloTheme.palette.primary500,
					color: 'white',
					boxShadow: 'none',
					'&:hover': {
						backgroundColor: caloTheme.palette.primary500,
						borderColor: caloTheme.palette.primary600,
						boxShadow: 'none'
					}
				}}
				onClick={() => {
					infoMealRef.current?.close();
					setSelectedMeal(undefined);
				}}
			>
				Done
			</Button>
		</Stack>
	</Box>
);
export default MenuMealInfo;
