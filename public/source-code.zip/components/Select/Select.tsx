import { isArray } from 'lodash-es';
import RSelect, { Props } from 'react-select';

interface SelectOption {
	label: string;
	value: string | number;
}

export interface SelectProps extends Omit<Props<SelectOption>, 'value'> {
	label?: string;
	value?: any;
	hidden?: boolean;
	error?: boolean;
	areDuplicatesAllowed?: boolean;
	isDisabled?: boolean;
	isMulti?: boolean;
}

const mapValueToSVal = (options: SelectOption[], value?: any) => {
	if (isArray(value)) {
		return options.filter((v) => value.includes(v.value));
	}

	return options.find((v) => v.value === value) || null;
};

const Select = ({
	error,
	label,
	value,
	options,
	hidden,
	isMulti,
	customStyles,
	areDuplicatesAllowed,
	isDisabled = false,
	...rest
}: SelectProps) => (
	<div className="field" hidden={hidden}>
		{label && <label className="label">{label}</label>}
		<div className="control is-clearfix">
			<RSelect
				{...rest}
				isDisabled={isDisabled}
				value={areDuplicatesAllowed ? value : mapValueToSVal(options, value)}
				options={options}
				isMulti={isMulti}
				blurInputOnSelect={false}
				styles={customStyles}
				className={error ? 'border border-red-500' : undefined}
			/>
		</div>
	</div>
);

export default Select;
