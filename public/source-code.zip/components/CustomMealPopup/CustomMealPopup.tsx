import { Brand, Delivery, FoodComponentType, Kitchen, Localized } from '@calo/types';
import { Icon as Iconify } from '@iconify/react';
import { Box, Button, Grid, MenuItem, Stack, TextField, Typography } from '@mui/material';
import { getListWithParams } from 'actions';
import { caloTheme } from 'assets/images/theme/calo';
import { MenuFood } from 'lib/interfaces';
import { sortBy, startCase } from 'lodash-es';
import { useEffect, useMemo, useState } from 'react';
import { useQuery } from 'react-query';
import CaloLoader from '../CaloLoader';

interface CustomMealPopupProps {
	customFood: any;
	selectedDelivery: Delivery;
	customFoodModalRef: any;
	customMealAction: string;
	handleUpdateCustomFood: (value: MenuFood, customName: Localized) => void;
}

const CustomMealPopup = ({
	handleUpdateCustomFood,
	selectedDelivery,
	customMealAction,
	customFood,
	customFoodModalRef
}: CustomMealPopupProps) => {
	const [customFoodComponents, setCustomFoodComponents] = useState<any>({
		base: [],
		protein: [],
		topping: [],
		sauce: [],
		side: []
	});

	const [customFoodComponent, setCustomFoodComponent] = useState<MenuFood[]>([]);
	const { data: customFoodCom, isLoading } = useQuery<any, Error, { data: any[] }>(
		[
			'food-components/custom-food',
			{
				filters: {
					kitchen: selectedDelivery.kitchen ? selectedDelivery.kitchen : Kitchen.BH1,
					brand: Brand.CALO
				}
			}
		],
		getListWithParams,
		{
			onSuccess: (data) => {
				setCustomFoodComponent(data.data);
			}
		}
	);

	useEffect(() => {
		if (customFoodCom) setCustomFoodComponent(customFoodCom?.data);
	}, [customFoodCom]);

	const [selectedCustomComp, setSelectedCustomComp] = useState<{
		value: string;
		label: string;
		type: FoodComponentType;
	}>();
	const [customFoodName, setCustomFoodName] = useState<Localized>({ en: '', ar: '' });

	const sidesComponents = customFoodComponent
		?.filter((f: any) => f.tags.includes(FoodComponentType.side))
		.map((r: any) => ({ value: r.id, label: typeof r.name === 'string' ? r.name : r.name.en }));

	const options = useMemo(
		() =>
			sortBy(sidesComponents, (f) => `${f.label}`).map((sides: any) => ({
				value: sides.value,
				label: sides.label
			})),
		[sidesComponents]
	);

	const handleCount = (type: FoodComponentType) => {
		if (type === FoodComponentType.side) {
			try {
				const sidesCount = customFoodComponents?.side.length;
				return sidesCount;
			} catch {
				return 0;
			}
		} else {
			let counts = 0;
			if (customFoodComponents[type][0]) {
				counts = customFoodComponents[type]?.length;
			}
			return counts;
		}
	};

	const handleRemoveSides = (sideId: any) => {
		const i = customFoodComponents.side.indexOf(sideId);
		customFoodComponents.side.splice(i, 1);
		setCustomFoodComponents({ ...customFoodComponents, side: customFoodComponents.side });
	};

	const handleSideComponent = (comp: any) => {
		const count = customFood?.components.find((r: any) => r.id === comp.value);
		for (let i = 1; i <= count.count; i++) {
			customFoodComponents['side'].push({ value: comp.value, label: comp.label });
		}
		return customFoodComponents['side'];
	};

	const getComponents = () => {
		const fC = customFoodComponent
			?.filter((cus: any) => customFood?.components?.find((r: any) => r.id === cus.id))
			.map((k: any) => ({ value: k.id, label: typeof k.name === 'string' ? k.name : k.name.en, tags: k.tags }));
		fC?.map((k: any) =>
			k.tags[0] === FoodComponentType.side
				? handleSideComponent(k)
				: customFoodComponents[k.tags[0]].push({ value: k.value, label: k.label })
		);
	};

	useEffect(() => {
		getComponents();
	}, [customFood, customFoodComponent]);

	useEffect(() => {
		if (customFood?.name) {
			setCustomFoodName({ en: customFood.name.en, ar: customFood.name.en });
		}
	}, []);

	const handleNameChange = (data: string) => {
		const customName = data;
		if (customName.length <= 32) {
			setCustomFoodName({ en: data, ar: data });
		}
	};

	useEffect(() => {
		if (selectedCustomComp && selectedCustomComp.value.length > 0) {
			if (selectedCustomComp?.type === FoodComponentType.side) {
				setCustomFoodComponents({
					...customFoodComponents,
					side: [
						...customFoodComponents.side,
						(customFoodComponents.side[handleCount(FoodComponentType.side) - 1] = {
							value: selectedCustomComp!.value,
							label: selectedCustomComp!.label
						})
					]
				});
			} else {
				setCustomFoodComponents({
					...customFoodComponents,
					[selectedCustomComp?.type]: [{ value: selectedCustomComp!.value, label: selectedCustomComp!.label }]
				});
			}
		}
	}, [selectedCustomComp]);

	return (
		<>
			{isLoading ? (
				<Stack>
					<CaloLoader />
				</Stack>
			) : (
				<>
					<Box sx={{ paddingVertical: 1 }}>
						<Stack sx={{ width: '100%', flexDirection: 'column', justifyContent: 'space-between', marginTop: '8px' }}>
							<TextField
								required
								id="new-custom-meal-name"
								label="Custom Meal Name"
								placeholder="Custom Meal Name"
								value={customFoodName.en}
								style={{ margin: '4px' }}
								name="name"
								onChange={(data: any) => handleNameChange(data.target.value)}
								InputProps={{ inputProps: { style: { borderRadius: 8 } }, style: { borderRadius: 8 } }}
							/>
						</Stack>
						<Stack sx={{ width: '100%', flexDirection: 'column', justifyContent: 'space-between', marginTop: '12px' }}>
							<Typography
								sx={{
									fontSize: '16px',
									lineHeight: '20px',
									fontWeight: 600
								}}
							>
								Components
							</Typography>
							<Stack sx={{ width: '100%', flexDirection: 'row', justifyContent: 'space-between', marginTop: '14px' }}>
								<TextField
									select
									id="new-custom-meal-component-base"
									label={`Base (${handleCount(FoodComponentType.base)}/1)`}
									placeholder="Select Base"
									name="base"
									SelectProps={{
										multiple: false,
										value: customFoodComponents[FoodComponentType.base][0]?.value || [],
										placeholder: 'Select Base'
									}}
									style={{ width: '50%', marginRight: '8px', marginLeft: '8px' }}
									InputProps={{ inputProps: { style: { borderRadius: 8 } }, style: { borderRadius: 8 } }}
								>
									{customFoodComponent
										?.filter((f: any) => f.tags.includes(FoodComponentType.base))
										.map((r: any) => ({
											label: typeof r.name === 'string' ? r.name : r.name.en,
											value: r.id
										}))
										.map((selected) => (
											<MenuItem
												key={selected.value}
												value={selected.value}
												onClick={() =>
													setSelectedCustomComp({
														value: selected.value,
														label: selected.label,
														type: FoodComponentType.base
													})
												}
											>
												{startCase(selected.label)}
											</MenuItem>
										))}
								</TextField>
								<TextField
									select
									id="new-custom-meal-component-protein"
									label={`Protein (${handleCount(FoodComponentType.protein)}/1)`}
									placeholder="Select Protein"
									value={customFoodComponents[FoodComponentType.protein][0]?.value}
									name="protein"
									SelectProps={{
										multiple: false,
										value: customFoodComponents[FoodComponentType.protein][0]?.value || [],
										placeholder: 'Select Protein'
									}}
									style={{ width: '50%', marginRight: '8px', marginLeft: '8px' }}
									InputProps={{ inputProps: { style: { borderRadius: 8 } }, style: { borderRadius: 8 } }}
								>
									{customFoodComponent
										?.filter((f: any) => f.tags.includes(FoodComponentType.protein))
										.map((r: any) => ({
											label: typeof r.name === 'string' ? r.name : r.name.en,
											value: r.id
										}))
										.map((selected) => (
											<MenuItem
												key={selected.value}
												value={selected.value}
												onClick={() =>
													setSelectedCustomComp({
														value: selected.value,
														label: selected.label,
														type: FoodComponentType.protein
													})
												}
											>
												{startCase(selected.label)}
											</MenuItem>
										))}
								</TextField>
							</Stack>
							<Stack sx={{ width: '100%', flexDirection: 'row', justifyContent: 'space-between', marginTop: '12px' }}>
								<TextField
									select
									id="new-custom-meal-component-side"
									label={`Sides (${handleCount(FoodComponentType.side)}/3)`}
									placeholder="Select Sides"
									value={customFoodComponents[FoodComponentType.side]?.map((side: any) => side.value)}
									SelectProps={{
										multiple: true,
										value: customFoodComponents[FoodComponentType.side]?.map((side: any) => side.value),
										placeholder: 'Select Sides'
									}}
									name="side"
									disabled={handleCount(FoodComponentType.side) >= 3}
									style={{ width: '50%', marginRight: '8px', marginLeft: '8px' }}
									InputProps={{ inputProps: { style: { borderRadius: 8 } }, style: { borderRadius: 8 } }}
								>
									{options.map((r: any, index) => (
										<MenuItem
											value={r.value}
											key={`${r.value}-${index}`}
											onClick={() => setSelectedCustomComp({ label: r.label, value: r.value, type: FoodComponentType.side })}
										>
											{startCase(r.label)}
										</MenuItem>
									))}
								</TextField>
								<TextField
									select
									id="new-custom-meal-component-sauce"
									label={`Sauce (${handleCount(FoodComponentType.sauce)}/1)`}
									placeholder="Select Sauce"
									name="sauce"
									SelectProps={{
										multiple: false,
										value: customFoodComponents[FoodComponentType.sauce][0]?.value || [],
										placeholder: 'Select Sauce'
									}}
									style={{ width: '50%', marginRight: '8px', marginLeft: '8px' }}
									InputProps={{ inputProps: { style: { borderRadius: 8 } }, style: { borderRadius: 8 } }}
								>
									{customFoodComponent
										?.filter((f: any) => f.tags.includes(FoodComponentType.sauce))
										.map((r: any) => ({
											label: typeof r.name === 'string' ? r.name : r.name.en,
											value: r.id
										}))
										.map((selected) => (
											<MenuItem
												key={selected.value}
												value={selected.value}
												onClick={() =>
													setSelectedCustomComp({
														value: selected.value,
														label: selected.label,
														type: FoodComponentType.sauce
													})
												}
											>
												{startCase(selected.label)}
											</MenuItem>
										))}
								</TextField>
							</Stack>
							<Stack sx={{ width: '100%', flexDirection: 'row', justifyContent: 'space-between', marginTop: '12px' }}>
								<TextField
									select
									id="new-custom-meal-component-toppings"
									label={`Toppings (${handleCount(FoodComponentType.topping)}/1)`}
									placeholder="Select Toppings"
									value={customFoodComponents[FoodComponentType.topping][0]?.value}
									name="topping"
									SelectProps={{
										multiple: false,
										value: customFoodComponents[FoodComponentType.topping][0]?.value || [],
										placeholder: 'Select Toppings'
									}}
									style={{ width: '100%', marginRight: '8px', marginLeft: '8px' }}
									InputProps={{ inputProps: { style: { borderRadius: 8 } }, style: { borderRadius: 8 } }}
								>
									{customFoodComponent
										?.filter((f: any) => f.tags.includes(FoodComponentType.topping))
										.map((r: any) => ({
											label: typeof r.name === 'string' ? r.name : r.name.en,
											value: r.id
										}))
										.map((selected) => (
											<MenuItem
												key={selected.value}
												value={selected.value}
												onClick={() =>
													setSelectedCustomComp({
														value: selected.value,
														label: selected.label,
														type: FoodComponentType.topping
													})
												}
											>
												{startCase(selected.label)}
											</MenuItem>
										))}
								</TextField>
							</Stack>
						</Stack>
						<Box sx={{ marginY: 2 }}>
							<Stack sx={{ display: 'flex', flexDirection: 'row', flexWrap: 'wrap', gap: 1 }}>
								{Object.values(FoodComponentType).map((type) =>
									type === FoodComponentType.side
										? customFoodComponents[type]?.map(
												(r: any, index: number) =>
													customFoodComponents[type][index]?.label && (
														<Box
															key={index}
															sx={{
																margin: '4px',
																flexDirection: 'row',
																borderRadius: '37px',
																flexWrap: 'wrap',
																background: caloTheme.palette.primary100,
																color: caloTheme.palette.primary700,
																padding: ' 8px 12px'
															}}
														>
															<Grid key={index}>
																<Typography sx={{ display: 'flex', flexDirection: 'row', mr: '2px' }}>
																	<Typography
																		sx={{
																			fontSize: '14px',
																			fontWeight: 600,
																			lineHeight: '18px',
																			marginX: 1
																		}}
																	>
																		{startCase(r.label)}
																	</Typography>
																	<Iconify
																		icon="ph:x-bold"
																		color={caloTheme.palette.primary700}
																		style={{ cursor: 'pointer', margin: 'auto', marginRight: 2 }}
																		onClick={() => handleRemoveSides(r)}
																	/>
																</Typography>
															</Grid>
														</Box>
													)
											)
										: customFoodComponents[type][0]?.label && (
												<Box
													sx={{
														margin: '3px',
														flexDirection: 'row',
														borderRadius: '37px',
														flexWrap: 'wrap',
														background: caloTheme.palette.primary100,
														color: caloTheme.palette.primary700,
														padding: ' 8px 12px'
													}}
												>
													<Grid>
														<Typography sx={{ display: 'flex', flexDirection: 'row', mr: '2px' }}>
															<Typography
																sx={{
																	fontSize: '14px',
																	fontWeight: 600,
																	lineHeight: '18px',
																	marginX: 1
																}}
															>
																{startCase(customFoodComponents[type][0].label)}
															</Typography>
															<Iconify
																icon="ph:x-bold"
																color={caloTheme.palette.primary700}
																style={{ cursor: 'pointer', margin: 'auto', marginRight: 2 }}
																onClick={() => setCustomFoodComponents({ ...customFoodComponents, [type]: [] })}
															/>
														</Typography>
													</Grid>
												</Box>
											)
								)}
							</Stack>
						</Box>
						<Stack
							sx={{
								textAlign: 'center',
								display: 'flex',
								flexDirection: 'row',
								justifyContent: 'center',
								marginTop: '21px'
							}}
						>
							<Button
								variant="text"
								sx={{
									height: '45px',
									lineHeight: '17px',
									fontWeight: 600,
									fontSize: '14px',
									boxShadow: 'none',
									borderRadius: '8px',
									padding: '14px 20px 14px 20px',
									color: caloTheme.palette.neutral500,
									'&:hover': {
										boxShadow: 'none',
										color: caloTheme.palette.neutral900
									},
									[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
										justifyItems: 'center',
										margin: 'auto',
										width: 'auto'
									}
								}}
								onClick={() => customFoodModalRef.current.close()}
							>
								Cancel
							</Button>
							<Button
								variant="contained"
								sx={{
									height: '45px',
									backgroundColor: caloTheme.palette.primary500,
									color: 'white',
									lineHeight: '17px',
									fontWeight: 600,
									fontSize: '14px',
									boxShadow: 'none',
									borderRadius: '8px',
									padding: '14px 20px 14px 20px',
									'&:hover': {
										boxShadow: 'none',
										backgroundColor: caloTheme.palette.primary600,
										color: 'white'
									},
									[caloTheme.breakpoints.down(caloTheme.breakpoints.values.lg)]: {
										justifyItems: 'center',
										margin: 'auto',
										width: 'auto'
									}
								}}
								onClick={() => {
									handleUpdateCustomFood(customFoodComponents, customFoodName);
								}}
							>
								{customMealAction === 'create' ? 'Create' : 'Update'}
							</Button>
						</Stack>
					</Box>
				</>
			)}
		</>
	);
};
export default CustomMealPopup;
