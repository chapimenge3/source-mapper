import { FormControl, MenuItem, Stack, TextField, Typography } from '@mui/material';
import { getRecord } from 'actions';
import { AppState } from 'lib/interfaces';
import { capitalize } from 'lodash-es';
import { useQuery } from 'react-query';
import { useSelector } from 'react-redux';

interface DriverFormProps {
	value: string;
	selectedDay: string;
	onChange: (id: string) => any;
}

const DriverForm = ({ value, onChange, selectedDay }: DriverFormProps) => {
	const users = useSelector((state: AppState) => state.user.keyedList);
	useQuery([`/drivers/${value}`], getRecord, {
		enabled: Boolean(users && !users[value]),
		retry: false
	});

	return (
		<Stack sx={{ mx: '1px' }}>
			<FormControl fullWidth sx={{ mt: 2 }}>
				<TextField
					select
					label={`Driver for ${capitalize(selectedDay.toLowerCase())}`}
					sx={{
						width: '100%',
						'& .MuiInputBase-input': {
							borderRadius: '8px',
							padding: '12px 14px'
						},
						'& .MuiOutlinedInput-root': {
							borderRadius: '8px'
						}
					}}
					value={value}
					onChange={(e) => onChange(e.target.value as string)}
					SelectProps={{
						displayEmpty: true,
						renderValue: (selected) => {
							if (selected === '') {
								return <Typography>Select Driver</Typography>;
							}
							if (users) {
								return `${users[selected as any]?.name || '--'} (${users[selected as any]?.phoneNumber || '--'})`;
							}
							return '';
						}
					}}
					InputLabelProps={{
						shrink: true
					}}
				>
					{Object.values(users || {}).map((user: any) => (
						<MenuItem key={user.id} value={user.id}>
							{`${user.name} (${user.phoneNumber})`}
						</MenuItem>
					))}
				</TextField>
			</FormControl>
		</Stack>
	);
};

export default DriverForm;
