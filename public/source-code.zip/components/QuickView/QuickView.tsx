import React, { useState, ReactNode, ReactElement, cloneElement, useEffect, useRef } from 'react';
import cx from 'classnames';

interface QuickViewProps {
	trigger?: ReactElement;
	children: ReactNode;
	visible?: boolean;
	onClose?: () => void;
	className?: string;
}

const QuickView = ({ trigger, children, visible, onClose, className }: QuickViewProps) => {
	const [localVisible, setLocalVisible] = useState(false);
	const ref = useRef<HTMLTableElement>(null);

	const handleLocalClose = async () => {
		if (localVisible) {
			setLocalVisible(false);
		}
		if (onClose) {
			onClose();
		}
	};

	useEffect(() => {
		const handleClickOutside = (event: any) => {
			if (ref.current && !ref.current.contains(event.target) && !(event.target.id === 'filter') && visible && onClose) {
				onClose();
			}
		};
		document.addEventListener('mousedown', handleClickOutside);
		return () => {
			document.removeEventListener('mousedown', handleClickOutside);
		};
	}, [ref, visible]);

	return (
		<>
			{trigger &&
				cloneElement(trigger, {
					onClick: () => setLocalVisible(true)
				})}
			<div
				className={cx(
					'quickview',
					{
						'is-active': visible || localVisible
					},
					className
				)}
				ref={ref}
			>
				<header className="quickview-header">
					{/* <p className="title">Quickview title</p> */}
					<span className="delete" onClick={handleLocalClose}></span>
				</header>

				<div className="quickview-body">
					<div className="quickview-block">{children}</div>
				</div>

				{/* <footer className="quickview-footer">

      </footer> */}
			</div>
		</>
	);
};

export default QuickView;
