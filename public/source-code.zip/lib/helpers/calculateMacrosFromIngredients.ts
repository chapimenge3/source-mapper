import { LinkedComponent, MeasurementUnit } from '@calo/dashboard-types';
import { Dictionary, Macros, Micronutrients } from '@calo/types';
import { round, sum } from 'lodash-es';
import { toast } from 'react-toastify';
import { quantitiesCupsCalculator } from '.';
import { FoodComponent, Ingredient } from '../interfaces';

export const calculateMacrosFromIngredients = (
	ingredients: Ingredient[],
	childComponents: LinkedComponent[],
	allComponents: Dictionary<FoodComponent>,
	cookedRawFactor: number
) => {
	let totalIngredientsWeight = 0;
	let totalChildComponentsWeight = 0;
	let totalMacros: Macros = { cal: 0, carbs: 0, fat: 0, protein: 0, fiber: 0 };
	let totalMicronutrients: Micronutrients = {
		addedSugar: 0,
		cholesterol: 0,
		saturatedFats: 0,
		sodium: 0,
		totalSugar: 0,
		transFats: 0
	};
	for (const ing of ingredients) {
		if (!ing.macros) {
			toast(`Ingredient ${ing.name.en} is missing macros`, {
				type: 'error',
				autoClose: 2000
			});
			return;
		}
		totalIngredientsWeight += ing.quantity || 0;
		totalMacros = addMacrosOrMicros(ing.macros, totalMacros, ing.quantity);
		totalMicronutrients = addMacrosOrMicros(ing.micronutrients || {}, totalMicronutrients, ing.quantity);
	}
	for (const child of childComponents || []) {
		const comp = allComponents[child.id];
		if (!comp) {
			toast(`Component not found`, { type: 'error', autoClose: 2000 });
			return;
		}
		if (!comp.macros) {
			toast(`Component ${comp.name.en} is missing macros`, {
				type: 'error',
				autoClose: 2000
			});
			return;
		}
		const component = allComponents[comp.id];
		const componentWeight =
			component?.measurementUnit === MeasurementUnit.cup
				? quantitiesCupsCalculator([child.quantity], component?.cups!)
				: round((component?.weight || 1) * child.quantity, 6);

		totalChildComponentsWeight += componentWeight;
		totalMacros = addMacrosOrMicros(comp.macros, totalMacros, child.quantity);
		totalMicronutrients = addMacrosOrMicros(comp.micronutrients || {}, totalMicronutrients, child.quantity);
	}
	const totalQuantity = sum([totalIngredientsWeight, totalChildComponentsWeight]);

	let calculatedMacros = calculateMacros(totalMacros, totalQuantity, cookedRawFactor);
	const calculatedMicronutrients = calculateMacros(totalMicronutrients, totalQuantity, cookedRawFactor);
	calculatedMacros = {
		...calculatedMacros,
		cal: (calculatedMacros?.fat || 0) * 9 + (calculatedMacros?.carbs || 0) * 4 + (calculatedMacros?.protein || 0) * 4
	};
	return {
		macros: roundMacrosToFourDecimals(calculatedMacros),
		micronutrients: roundMacrosToFourDecimals(calculatedMicronutrients)
	};
};

const addMacrosOrMicros = (valuesToAdd: Macros | Micronutrients, oldValues: Macros | Micronutrients, weight = 1) => {
	const newValues: any = { ...oldValues };
	for (const [key, value] of Object.entries(valuesToAdd)) {
		newValues[key] = (newValues[key] || 0) + (value || 0) * weight;
	}
	return newValues;
};

const calculateMacros = (totalMacrosOrMicros: Macros | Micronutrients, totalQuantity: number, cookedRawFactor: number) => {
	const newValues: any = {};
	for (const [key, value] of Object.entries(totalMacrosOrMicros)) {
		newValues[key] = ((value || 0) / (totalQuantity || 1)) * (cookedRawFactor || 1);
	}
	return newValues;
};

const roundMacrosToFourDecimals = (oldValue: Macros | Micronutrients) => {
	const newValue: any = {};
	for (const [key, value] of Object.entries(oldValue)) {
		newValue[key] = Math.round(value * 10000) / 10000;
	}
	return newValue;
};
