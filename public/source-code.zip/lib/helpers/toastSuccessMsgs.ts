import { toast } from 'react-toastify';

interface ToastSuccessMsgsProps {
	action: string;
	status: number;
}
export const ToastSuccessMsgs = ({ status, action }: ToastSuccessMsgsProps) => {
	if (status >= 200 && status <= 299) {
		toast(action, { type: 'success', autoClose: 2000 });
	}
};
