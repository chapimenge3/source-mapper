import { Country } from '@calo/types';

export const setCountryToLocalStorage = (country: Country): void => localStorage.setItem('Country', country);

export const getCountryFromLocalStorage = () => localStorage.getItem('Country') || Country.BH;
