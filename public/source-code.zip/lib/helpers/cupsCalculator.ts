import { CupSizes } from '@calo/dashboard-types';

export const quantityCupsCalculator = (quantity: number, cups: CupSizes[]) => {
	const cupSizes = cups?.map((cup) => cup.size);
	const orderedCupSizes = cupSizes?.sort().reverse();
	const orderedCups: CupSizes[] = [];
	for (let i = 0; i < cups?.length; i++) {
		const index = orderedCupSizes?.indexOf(cups[i].size);
		orderedCups[index] = cups[i];
	}
	let remainingQuantity = quantity;
	let cupsQuantity = 0;
	for (const cup of orderedCups) {
		const quotient = Math.floor(remainingQuantity / cup.size);
		remainingQuantity -= quotient * cup.size;
		cupsQuantity += quotient * cup.value;
	}

	return cupsQuantity;
};

export const quantitiesCupsCalculator = (quantities: number[], cups: CupSizes[]) => {
	const calculatedQuantities: Record<number, number> = {};
	let result = 0;

	for (const quantity of quantities) {
		if (!calculatedQuantities[quantity]) {
			calculatedQuantities[quantity] = quantityCupsCalculator(quantity, cups);
		}
		result += calculatedQuantities[quantity];
	}
	return result;
};
