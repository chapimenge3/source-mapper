import { MeasurementUnit } from '@calo/dashboard-types';

export const resolveMeasurementUnit = (measurementUnit: MeasurementUnit) => {
	switch (measurementUnit) {
		case MeasurementUnit.cup:
			return 'Cup';
		case MeasurementUnit.g:
			return 'Gram';
		case MeasurementUnit.ml:
			return 'Milliliter';
		case MeasurementUnit.piece:
			return 'Piece';
		case MeasurementUnit.pinch:
			return 'Pinch';
		case MeasurementUnit.teaspoon:
			return 'Teaspoon';
		case MeasurementUnit.wedge:
			return 'Wedge';
		default:
			return '';
	}
};
