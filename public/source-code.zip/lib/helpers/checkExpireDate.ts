import { parseISO } from 'date-fns';
import { format } from 'date-fns/fp';

export const checkExpireDate = (time: string) => {
	const smTime = format('yyyy-MM-dd hh:mm a')(parseISO(time));
	const result = format('yyyy-MM-dd hh:mm a')(Date.now()).toString();
	return smTime > result;
};
