import { format } from 'date-fns/fp';
import { flatMap, max, range, sum, sumBy } from 'lodash-es';
import { FoodComponent, Ingredient } from '../interfaces';

export const handlePurchasingCost = (ingredient: Ingredient) => {
	return (ingredient?.cost || 0) * (ingredient?.quantity || 0) * (ingredient?.wastage || 0);
};

export const calculatePurchasingCost = (
	ingredients: Ingredient[],
	childComponentIngredients: Ingredient[],
	cookedRawFactor: number
) => {
	const allIngredients = ingredients.concat(childComponentIngredients);
	if (allIngredients) {
		const cost = allIngredients.map((ingredient) => ({
			...ingredient,
			ingredientsWithPurchasingCost: handlePurchasingCost(ingredient)
		}));
		const totalCostPreCooking = sumBy(cost, 'ingredientsWithPurchasingCost');
		const ingredientQuantities = sumBy(cost, 'quantity');
		const totalCostPreCookingPerGram = +totalCostPreCooking / +ingredientQuantities;
		const purchasingCost = totalCostPreCookingPerGram * cookedRawFactor;
		return purchasingCost;
	} else {
		return 0;
	}
};

export const calculateFoodPurchasingCost = (components: any[]) => {
	return sum(
		components.map((comp) => {
			const replicatedChildComponents = flatMap(range(comp.quantity), () => comp.childComponents || []);

			return calculatePurchasingCost(comp.ingredients || [], replicatedChildComponents, comp.cookedRawFactor) * comp.quantity;
		})
	);
};

export const getLastUpdatedPurchasingCostDate = (foodComponent: FoodComponent[]) =>
	max(
		foodComponent.map((c) =>
			max(c.ingredients.map((i) => (i.costLastUpdated ? format('dd-MM-yyyy')(new Date(i.costLastUpdated)) : '---')))
		)
	);
