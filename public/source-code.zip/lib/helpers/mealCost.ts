import { FoodService } from '@calo/services';
import { getCaloFoodTypePrice } from '@calo/services/dist/constants';
import { Kitchen, SubscriptionTier } from '@calo/types';
import { sumBy } from 'lodash-es';
import { MenuFood } from '../interfaces';
import { checkCountryCurrency, resolveCountryFromKitchen } from './countryUtils';

export const formatNumber = (num: number) => {
	const roundedNumber = num % 1 === 0 ? num.toFixed(0) : num.toFixed(2).replace(/\.?0*$/, '');
	return roundedNumber;
};

enum KitchenWeighted {
	BH1 = 'BH1',
	SA1 = 'SA1',
	SA2 = 'SA2',
	AE1 = 'AE1',
	KW1 = 'KW1'
}

const weightedAverages: {
	[key in KitchenWeighted]: { [size: string]: number };
} = {
	[KitchenWeighted.BH1]: { L: 0.32, M: 0.48, S: 0.2 },
	[KitchenWeighted.SA1]: { L: 0.16, M: 0.49, S: 0.34 },
	[KitchenWeighted.SA2]: { L: 0.17, M: 0.52, S: 0.32 },
	[KitchenWeighted.AE1]: { L: 0.22, M: 0.5, S: 0.28 },
	[KitchenWeighted.KW1]: { L: 0.21, M: 0.45, S: 0.33 }
};

export const getWeightedAverage = (kitchen: Kitchen | KitchenWeighted, size: string): number => {
	const kitchenKey = (Object.values(KitchenWeighted) as string[]).includes(kitchen as string)
		? (kitchen as KitchenWeighted)
		: KitchenWeighted.BH1;
	const kitchenAverages = weightedAverages[kitchenKey];

	return kitchenAverages && kitchenAverages[size] ? kitchenAverages[size] : 0;
};

export const calculateTotalCost = (meal: any): number => {
	let totalCost = 0;
	if (meal.components) {
		for (const component of meal.components) {
			const { quantity, cost } = component;
			const componentCost = cost || 0;
			totalCost += componentCost * quantity;
		}

		return totalCost;
	}

	return 0;
};

export const handleMealCost = (mealName: string, sortedList: MenuFood[], kitchen: Kitchen) => {
	const mealSizes = ['L', 'M', 'S'];
	const singleMealSizeVariants = sortedList
		.filter((food) => food.name.en === mealName && mealSizes.includes(food.size))
		.map((f) => ({ ...f, kitchen }));

	if (singleMealSizeVariants.length === 0) {
		return 0;
	}

	const weightedAverageCost =
		singleMealSizeVariants.length < 3
			? sumBy(singleMealSizeVariants, calculateTotalCost) / singleMealSizeVariants.length
			: sumBy(singleMealSizeVariants, (meal) => calculateTotalCost(meal) * getWeightedAverage(kitchen || Kitchen.BH1, meal.size));

	const selectedDietType = FoodService.getDiet(singleMealSizeVariants[0] as any);
	const sellingPrice = getCaloFoodTypePrice({
		tier: SubscriptionTier.personalized,
		currency: checkCountryCurrency(resolveCountryFromKitchen(kitchen || Kitchen.BH1)),
		dietType: selectedDietType,
		foodType: singleMealSizeVariants[0].type[0]
	});
	const percentageCost = +formatNumber((weightedAverageCost * 100) / +sellingPrice);

	return percentageCost;
};
