import { StatsFoodComponent } from '../../views/Kitchen/KitchenFoodStats/KitchenComponetStats';

export const groupedAllFoodComponents = (selectedStatsData: StatsFoodComponent[]) => {
	const groupedData: any = {};
	for (const item of selectedStatsData) {
		if (groupedData[item.id]) {
			groupedData[item.id] = {
				...item,
				stats: {
					...item.stats,
					quantity: groupedData[item.id].stats.quantity + item.stats.quantity,
					cookedWeight: groupedData[item.id].stats.cookedWeight + item.stats.cookedWeight,
					rawWeight: groupedData[item.id].stats.rawWeight + item.stats.rawWeight,
					childQuantity: groupedData[item.id].stats.childQuantity + item.stats.childQuantity,
					childWeight: groupedData[item.id].stats.childWeight + item.stats.childWeight,
					removedQuantity: groupedData[item.id].stats.removedQuantity + item.stats.removedQuantity,
					removedCookedWeight: groupedData[item.id].stats.removedCookedWeight + item.stats.removedCookedWeight,
					removedRawWeight: groupedData[item.id].stats.removedRawWeight + item.stats.removedRawWeight
				}
			};
		} else {
			groupedData[item.id] = item;
		}
	}

	return groupedData;
};

export const groupedAllMeals = (selectedStatsData: any[]) => {
	const groupedData: any = {};
	for (const item of selectedStatsData) {
		if (groupedData[item.key]) {
			groupedData[item.key] = {
				...item,
				quantity: groupedData[item.key].quantity + item.quantity
			};
		} else {
			groupedData[item.key] = item;
		}
	}
	return groupedData;
};
