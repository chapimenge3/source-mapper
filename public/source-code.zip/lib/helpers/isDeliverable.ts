import { Delivery, DeliveryStatus } from '@calo/types';

export const isDeliverable = (delivery: Delivery) =>
	[DeliveryStatus.upcoming, DeliveryStatus.paymentRequired].includes(delivery.status) && !delivery.skipped;
