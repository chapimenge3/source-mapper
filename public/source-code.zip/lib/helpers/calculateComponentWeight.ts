import { MeasurementUnit } from '@calo/dashboard-types';
import { quantityCupsCalculator } from '.';
import { FoodComponent } from '../interfaces';

export const calculateComponentWeight = (comp: any, componentQuantity: number) => {
	if (comp?.measurementUnit === MeasurementUnit.cup && comp?.cups) {
		return Math.ceil(quantityCupsCalculator(componentQuantity, comp.cups));
	}
	return Math.ceil((comp?.weight || 1) * componentQuantity);
};

export const calculateTotalWeight = (fc: FoodComponent) => {
	let totalWeight = 0;
	for (const ing of fc.ingredients || []) {
		totalWeight += ing.quantity || 0;
	}
	for (const comp of fc.childComponents || []) {
		totalWeight += calculateComponentWeight(comp, comp.quantity || 1);
	}
	return totalWeight;
};

export const calculateFractionWeight = (fc: any, quantity: number, newCookedWeight: number) => {
	const totalWeight = calculateTotalWeight(fc) || 1;
	const fraction = quantity / totalWeight;
	const ingQuantity = newCookedWeight * fc.cookedRawFactor * fraction;
	return ingQuantity;
};

export const roundToDecimalPlaces = (num: number, decimalPlaces: number): number => {
	const multiplier = Math.pow(10, decimalPlaces);

	return Math.round(num * multiplier) / multiplier;
};
