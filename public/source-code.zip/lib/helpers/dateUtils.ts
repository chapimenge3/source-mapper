import { addWeeks, endOfWeek as endOfWeekfns, startOfWeek as startOfWeekfns } from 'date-fns';
import { endOfWeek, format, startOfWeek } from 'date-fns/fp';
interface DateOfWeekProps {
	week: number;
	year: number;
}

export const dateOfWeek = ({ week, year }: DateOfWeekProps) => {
	const date = new Date(year, 0, 1 + week * 7);
	const weekDate = date;
	weekDate.setDate(date.getDate() - 7);
	return `${format('yyyy-MM-dd')(startOfWeek(weekDate))} - ${format('yyyy-MM-dd')(endOfWeek(weekDate))}`;
};

export const handleWeekFormat = (week: number) => {
	const weekNumber = week.toString().split('#');
	const date = new Date(+weekNumber[0], 0, 1 + +weekNumber[1] * 7);
	const weekDate = date;
	weekDate.setDate(date.getDate() - 7);
	return `${format('eee dd/MM/yyyy')(startOfWeek(weekDate))} - ${format('eee dd/MM/yyyy')(endOfWeek(weekDate))}`;
};

export const findStartAndEndDateForWeek = (weekNumber: number) => {
	const currentYear = new Date().getFullYear();
	const startDate = startOfWeekfns(new Date(currentYear, 0, 1), { weekStartsOn: 0 });
	const targetDate = addWeeks(startDate, weekNumber - 1);
	const startOfWeekDate = startOfWeekfns(targetDate, { weekStartsOn: 0 });
	const endOfWeekDate = endOfWeekfns(targetDate, { weekStartsOn: 0 });
	return { startOfWeekDate, endOfWeekDate };
};
