import { applyMiddleware } from 'redux';
import thunk from 'redux-thunk';

import uiMiddleware from './uiMiddleware';

export default applyMiddleware(thunk, uiMiddleware);
